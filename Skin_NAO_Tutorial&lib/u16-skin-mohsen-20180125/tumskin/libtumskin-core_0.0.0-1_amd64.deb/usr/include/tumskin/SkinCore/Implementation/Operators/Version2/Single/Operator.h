/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINCORE_OPERATORSV2_SINGLE_OPERATOR_H
#define SKINCORE_OPERATORSV2_SINGLE_OPERATOR_H

#include <SkinCore/Implementation/Operators/Version2/Base/Operator.h>

namespace Skin{
namespace Implementation{
namespace Operators{
namespace Version2{
namespace Single{

class Operator : public Skin::Implementation::Operators::Version2::Base::Operator
{
    Q_OBJECT

public:

private:

public:
    Operator(QObject* parent = 0,
             Interface* interface = 0);

    ~Operator();

private:
    using Skin::Implementation::Operators::Version2::Base::Operator::handleError;
    using Skin::Implementation::Operators::Version2::Base::Operator::errorToString;

public:

private:

public slots:

private slots:

};


}}}}}

#endif // SKINCORE_OPERATORSV2_SINGLE_OPERATOR_H
