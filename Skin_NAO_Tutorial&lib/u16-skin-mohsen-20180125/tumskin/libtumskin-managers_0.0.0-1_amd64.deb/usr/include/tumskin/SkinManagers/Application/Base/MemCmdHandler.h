#ifndef SKINMANAGERS_APPLICATION_BASE_MEMCMDHANDLER_H
#define SKINMANAGERS_APPLICATION_BASE_MEMCMDHANDLER_H

#include <SkinManagers/Application/ConsoleCmdHandler.h>
#include <SkinManagers/Application/Base/Application.h>

namespace Skin {
namespace Managers{
namespace Application{
namespace Base{


class MemCmdHandler : public ConsoleCmdHandler
{
private:
    Skin::Managers::Application::Base::Application* m_app;
public:
    MemCmdHandler(Skin::Managers::Application::Base::Application* app);
    virtual bool handleMessage(const QString &s);
    virtual QString cmdDescription() const;
};


}}}}

#endif // SKINMANAGERS_APPLICATION_BASE_MEMCMDHANDLER_H
