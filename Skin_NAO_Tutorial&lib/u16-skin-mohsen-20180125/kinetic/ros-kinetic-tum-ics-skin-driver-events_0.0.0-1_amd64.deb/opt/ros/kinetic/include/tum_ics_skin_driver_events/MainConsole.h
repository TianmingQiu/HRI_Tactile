#ifndef TUM_ICS_SKIN_DRIVER_EVENTS_MAIN_CONSOLE_H
#define TUM_ICS_SKIN_DRIVER_EVENTS_MAIN_CONSOLE_H

#include <QObject>
#include <QVector>

#include <Common/ConsoleReader.h>

#include <SkinManagers/Application/Standard/Application.h>
#include <SkinManagers/Recon/Recon.h>

#include <SkinAdditions/UpdateRate/UpdateRate.h>
#include <SkinAdditions/ColorFeedback/ColorFeedback.h>
#include <SkinAdditions/NeighborTest/NeighborTest.h>

#include <SkinEvents/Managers/Events/Manager.h>

namespace tum_ics_skin_driver_events{

class MainConsole : public QObject
{
    Q_OBJECT

private:
    typedef bool (MainConsole::*cmd_handler_func)(const QString& s);

    Tum::Tools::Common::ConsoleReader m_console;
    bool m_quit;

    Skin::Managers::Application::Standard::Application*    m_app;
    Skin::Additions::UpdateRate*                m_updateRate;
    Skin::Additions::ColorFeedback*             m_colorFeedback;
    Skin::Additions::NeighborTest*              m_neighborTest;
    Skin::Managers::Events::Manager*            m_events;

    QVector<cmd_handler_func> m_cmdHandlers;

    QMutex m_cmdMutex;

public:
    MainConsole(Skin::Managers::Application::Standard::Application* app,
                Skin::Additions::UpdateRate* updateRate,
                Skin::Additions::ColorFeedback* colorFeedback,
                Skin::Additions::NeighborTest* neighborTest,
                Skin::Managers::Events::Manager* events,
                QObject *parent = 0);
   ~MainConsole();

public:
    bool setCommand(const QString& s);

private:
    bool handleHelpCommand(const QString& s);

private slots:
    void message(QString s);

public slots:
    void quit();

signals:
    void finished();

};

}

#endif // TUM_ICS_SKIN_DRIVER_EVENTS_MAIN_CONSOLE_H
