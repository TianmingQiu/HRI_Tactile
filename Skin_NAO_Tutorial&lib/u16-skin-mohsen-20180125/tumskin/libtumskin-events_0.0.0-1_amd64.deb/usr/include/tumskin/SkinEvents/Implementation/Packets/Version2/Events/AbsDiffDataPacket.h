/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINEVENTS_PACKETSV2_EVENTS_ABSDIFFDATAPACKET_H
#define SKINEVENTS_PACKETSV2_EVENTS_ABSDIFFDATAPACKET_H

#include <SkinCore/Implementation/Packet.h>
#include <SkinCore/Cell/Events/Thresholds.h>
#include <SkinEvents/Implementation/Packets/Version2/Events/AbsDiffData.h>
#include <SkinEvents/Implementation/Packets/Version2/Events/RawAbsDiffData.h>

namespace Skin{
namespace Implementation{
namespace Packets {
namespace Version2{
namespace Events{

class AbsDiffDataPacket : public Packet
{

public:
    static const int PKT_SIZE = 20;

    static bool check(const Packet& p);

    static void setRawAbsDiffData(Packet& p, const RawAbsDiffData& t);
    static void setAbsDiffData(Packet& p, const AbsDiffData& t);
    static void setThresholds(Packet& p, const Skin::Cell::Events::Thresholds& t);

    // thresholds are always positive!
    static RawAbsDiffData getRawAbsDiffData(const Packet& p);
    static AbsDiffData getAbsDiffData(const Packet& p);
    static Skin::Cell::Events::Thresholds getThresholds(const Packet& p);

private:
    static unsigned int getTemperature(const Packet& p, int index);
    static unsigned int getAcceleration(const Packet& p, int index);
    static unsigned int getProximity(const Packet& p, int index);
    static unsigned int getForce(const Packet& p, int index);

    static int int8_to_int(unsigned int val_int8);
    static int int10_to_int(unsigned int val_int10);
    static int int14_to_int(unsigned int val_int14);

private:

public:
    AbsDiffDataPacket(const RawAbsDiffData& t,
                    const QVector<Endpoint>& dest=QVector<Endpoint>());

    AbsDiffDataPacket(const AbsDiffData& t,
                    const QVector<Endpoint>& dest=QVector<Endpoint>());

    AbsDiffDataPacket(const Skin::Cell::Events::Thresholds& t,
                    const QVector<Endpoint>& dest=QVector<Endpoint>());

    void setRawAbsDiffData(const RawAbsDiffData& t);
    void setAbsDiffData(const AbsDiffData& t);
    void setThresholds(const Skin::Cell::Events::Thresholds& t);

private:
    void init();
};

}}}}}

#endif // SKINEVENTS_PACKETSV2_EVENTS_ABSDIFFDATAPACKET_H
