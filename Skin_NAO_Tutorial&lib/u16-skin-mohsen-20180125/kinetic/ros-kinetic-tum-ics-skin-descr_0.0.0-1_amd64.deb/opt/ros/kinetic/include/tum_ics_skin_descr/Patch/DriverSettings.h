#ifndef TUM_ICS_SKIN_DESCR_PATCH_DRIVER_SETTINGS_H
#define TUM_ICS_SKIN_DESCR_PATCH_DRIVER_SETTINGS_H

#include <Eigen/Eigen>
#include <QVector>
#include <QMetaType>
#include <QTextStream>

namespace tum_ics_skin_descr{
namespace Patch{

class DriverSettings
{
public:
    static DriverSettings Undefined(); // default constr.

private:
    int m_patchId;
    QString m_prefix;       // namespace/prefix to skin driver

public:
    DriverSettings(int patchId=-1, const QString& prefix="");

    DriverSettings(const DriverSettings& ds);
    ~DriverSettings();

    // comparisons only for id
    bool operator== (const DriverSettings& other) const;
    bool operator!= (const DriverSettings& other) const;
    bool operator< (const DriverSettings& other) const;


    void setPatchId(int patchId);
    void setPrefix(const QString& prefix);

    // undefined if patch id == -1
    bool isUndefined() const;
    int patchId() const;

    const QString& prefix() const;
    QString toString() const;
};

}}

#endif // TUM_ICS_SKIN_DESCR_PATCH_DRIVER_SETTINGS_H
