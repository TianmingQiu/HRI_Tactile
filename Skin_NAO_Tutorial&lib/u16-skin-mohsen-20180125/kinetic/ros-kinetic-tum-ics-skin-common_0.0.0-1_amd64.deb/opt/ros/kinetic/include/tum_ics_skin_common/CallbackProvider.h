#ifndef TUM_ICS_SKIN_CALLBACK_PROVIDER_H
#define TUM_ICS_SKIN_CALLBACK_PROVIDER_H

#include <QVector>
#include <tum_ics_skin_common/Cell/Data.h>

namespace tum_ics_skin_common{

template<class D>
class CallbackProvider
{
public:
    virtual void callback(const D&) = 0;
    ~CallbackProvider(){}
};

}

#endif // TUM_ICS_SKIN_CALLBACK_PROVIDER_H
