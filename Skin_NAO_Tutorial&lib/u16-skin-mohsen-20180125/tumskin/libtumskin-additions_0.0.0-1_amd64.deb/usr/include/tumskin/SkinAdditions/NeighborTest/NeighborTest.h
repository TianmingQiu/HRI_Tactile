#ifndef SKINADDITIONS_NEIGHBORTEST_H
#define SKINADDITIONS_NEIGHBORTEST_H


#include <QObject>
#include <QTimer>
#include <QThread>
#include <QMutex>
#include <QElapsedTimer>
#include <QFile>

#include <SkinCore/Cell/MasterPort.h>
#include <SkinCore/Cell/Neighbors.h>
#include <SkinManagers/Application/Base/Application.h>
#include <SkinCore/Implementation/Packets/Version2/PacketDefinitions.h>

namespace Skin {
namespace Additions{

class NeighborTest : public QObject
{
    Q_OBJECT

public:

private:

public:

private:
    typedef bool (NeighborTest::*cmd_handler_func)(const QString& s);
    QVector<cmd_handler_func> m_cmdHandlers;
    QString             m_consoleCmdDescription;

    Skin::Managers::Application::Base::Application* m_app;


    QVector<Skin::Cell::Neighbors>  m_neighs;

    QTimer              m_timer;
    bool                m_started;
    int                 m_currInd;
    int                 m_trail;
    QMutex              m_colorMutex;

    QVector<QThread*>    m_threads;

public:
    explicit NeighborTest(Skin::Managers::Application::Base::Application* app,
                        QObject *parent = 0);

    const QString& consoleCmdDescription() const;
    bool handleConsoleCmd(QString);

private:
    bool handleNeighborTestCommands(const QString&);

private slots:
    void handleTimer();
    void newNeighborList(QVector<Skin::Cell::Neighbors>);

public slots:
    void start();

signals:

};

}}




#endif // SKINADDITIONS_NEIGHBORTEST_H
