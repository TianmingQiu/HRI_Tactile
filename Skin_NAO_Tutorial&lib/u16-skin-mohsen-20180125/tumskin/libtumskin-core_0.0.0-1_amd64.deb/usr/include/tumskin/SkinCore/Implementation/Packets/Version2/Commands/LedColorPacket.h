/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINIMPLPKTS_LEDCOLORPACKETV2_H
#define SKINIMPLPKTS_LEDCOLORPACKETV2_H

#include <SkinCore/Implementation/Packet.h>
#include <SkinCore/Cell/LedColor.h>
#include <SkinCore/Implementation/Packets/Version2/PacketDefinitions.h>

namespace Skin{
namespace Implementation{
namespace Packets {
namespace Version2{
namespace Commands{

using namespace Skin::Cell;

class LedColorPacket : public Packet
{

public:
    static const int PKT_SIZE = 20;
    static Packet& setId(Packet& p, int id);
    static Packet& setColor(Packet& p, const LedColor& color);

public:
    LedColorPacket();
    LedColorPacket(const LedColor& color=LedColor::Black,
                   int id=ID_ALL,
                   const QVector<Endpoint>& dest=QVector<Endpoint>());

    void setId(int id);
    void setColor(const LedColor& color);

private:
    void init(int id=0, const LedColor& color=LedColor::Black);

};

}}}}}

#endif // SKINIMPLPKTS_LEDCOLORPACKETV2_H
