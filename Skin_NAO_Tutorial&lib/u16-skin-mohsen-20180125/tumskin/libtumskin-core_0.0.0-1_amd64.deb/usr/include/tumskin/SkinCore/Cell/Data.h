/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKIN_CELL_DATA_H
#define SKIN_CELL_DATA_H

#include <QVector>
#include <QMetaType>
#include <QTextStream>

#include "AccCalib.h"

namespace Skin{
namespace Cell{

/*!
 * \brief A type class which contains the full set of sensor values for one skin cell
 *         which we call skin cell data.
 *
 * This class stores the sensor values of a skin cell. The cell id, patch id and
 * timestamp fields add additional information which is essential to efficiently
 * work with the sensor data of a skin cell.
 */
class Data
{

public:
    /*!
     * \brief The 64 bit time stamp of the skin cell data in ms since the start of
     *        the low level interface and its connection with the skin network.
     */
    qint64 ts;

    /*!
     * \brief The skin cell id which identifies the skin cell to which the data of
     *        this type class belongs to.
     *
     * Valid skin cell ids are always postive and start at 1 (\f$ id \in 1, 2, \dots \f$).
     */
    int cellId;

    /*!
     * \brief The skin patch id which identifies the patch to which the skin cell
     *        belongs to.
     *
     * Valid skin patch ids are always postive and start at 1. If the patch is not
     * specified the patch id stays 0.
     */
    int patchId;


    QVector<double> prox;   //!< Contains values of the proximity sensors of a skin cell.
    QVector<double> force;  //!< Contains values of the force sensors of a skin cell.
    QVector<double> acc;    //!< Contains values of the acceleration sensors of a skin cell.
    QVector<double> temp;   //!< Contains values of the temperature sensors of a skin cell.

    /*!
     * \brief The different versions of skin cell data.
     *
     * For now only version 2 is defined.
     */
    enum Versions
    {
        Version1 = 0,       //!< NOT DEFINED: Initializes zero size arrays for sensor values
        Version2            //!< Initializes the sensor value arrays to the correct size
    };

public:

    /*!
     * \brief Default constructor for the type class which contains the skin cell sensor values.
     * \param v is the version of the skin cell. Defines which sensors in which count a skin cell has.
     */
    Data(Data::Versions v = Version2);

    /*!
     * \brief Copy constructor. Copyies all the data fields of the type class
     */
    Data(const Data& d);
    ~Data();


    /*!
     * \brief Access operator to the ordered list of sensor values.
     *
     * Handle this operator with care. Accesses out of the list will result
     * in segmentation faults. The ordered list is:
     *
     *  Index | Version 2
     *  ----- | ------------
     *  0     | proximity 1
     *  1     | force 1
     *  2     | force 2
     *  3     | force 3
     *  4     | acc x
     *  5     | acc y
     *  6     | acc z
     *  7     | temp 1
     *  8     | temp 2
     * \param ind is the index in the ordered list.
     * \return The indexed sensor value.
     */
    double& operator[](int ind);

    /*!
     * \brief The substraction operator for skin cell data.
     *
     * Substracts the skin cell sensor values of the given type class
     * from this type class. The substraction is ignored when the
     * array sized don't match
     * \param other the given type class. The sensor values of the
     * given type class are substracted from this type class.
     * \return This type class with the resulting sensor values.
     */
    Data& operator -=(const Data& other);

    /*!
     * \brief Resizes the sensor value arrays according to the skin cell version
     * \param v is the version of the skin cell
     */
    void resize(Data::Versions v=Version2);

    /*!
     * \brief Sets all the fields to zero and clears the sensor value arrays.
     */
    void clear();

    /*!
     * \brief Calibrates the accelerometer values for given acceleration calibration
     *        parameters
     * \param ac is a class which contains the acceleration calibration parameters
     */
    void calibrate(const AccCalib& ac);

    /*!
     * \brief Get all the values of the skin cell sensors in an ordered way.
     * \return The skin cell sensor values in an ordered way:
     *  Index | Version 2
     *  ----- | ------------
     *  0     | proximity 1
     *  1     | force 1
     *  2     | force 2
     *  3     | force 3
     *  4     | acc x
     *  5     | acc y
     *  6     | acc z
     *  7     | temp 1
     *  8     | temp 2
     */
    const QVector<double> values() const;

    /*!
     * \brief Creates a formated human readable string for displaying the information
     *        of this type class.
     * \return The formated string which describes this type class.
     */
    QString toString() const;

};

}
}

/*!
 * \file
 *  Contains the declaration of the Skin Cell Data class and its
 *  global support functions.
 */

/*!
 * \brief Shift operator for converting the type class to a text stream.
 * \param s is the input text stream to which the type class is appened.
 * \param d is the type class which is appended to the text stream.
 * \return The given text stream.
 */
QTextStream& operator << (QTextStream& s, const Skin::Cell::Data& d);

/*!
 * \brief Shift operator for extracting the type class of the given text stream.
 * \param s is the input text stream of which the type class is extracted.
 * \param d is the type class which is extracted.
 * \return The given text stream.
 */
QTextStream& operator >> (QTextStream& s, Skin::Cell::Data& d);

Q_DECLARE_METATYPE(Skin::Cell::Data)
Q_DECLARE_METATYPE(QVector<Skin::Cell::Data>)

#endif // SKIN_CELL_DATA_H
