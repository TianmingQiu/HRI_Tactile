#!/bin/bash

ind=0
driverList[$((ind++))]="70p1"
driverList[$((ind++))]="70p2"
driverList[$((ind++))]="70p3"
driverList[$((ind++))]="70p4"

driverList[$((ind++))]="71p1"
driverList[$((ind++))]="71p2"
driverList[$((ind++))]="71p3"
driverList[$((ind++))]="71p4"

driverList[$((ind++))]="72p1"
driverList[$((ind++))]="72p2"
driverList[$((ind++))]="72p3"
driverList[$((ind++))]="72p4"

len=${#driverList[@]}
for (( i=0; i<len; i++ ))
do
    driver=${driverList[${i}]}

    # kill screen
    screen -X -S "$driver" quit
done

screen -ls


