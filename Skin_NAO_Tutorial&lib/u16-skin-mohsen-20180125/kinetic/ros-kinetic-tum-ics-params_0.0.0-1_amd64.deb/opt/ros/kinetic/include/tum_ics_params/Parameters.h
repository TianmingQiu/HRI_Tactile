#ifndef TUM_ICS_PARAMS_PARAMETERS_H
#define TUM_ICS_PARAMS_PARAMETERS_H

#include <QString>
#include <QVector>

namespace tum_ics_params
{
class Parameters
{
public:
    static bool has(const QString& param);

    static bool getBool(bool& val, const QString& param);
    static bool getInt(int& val, const QString& param);
    static bool getDouble(double& val, const QString& param);
    static bool getString(QString& str, const QString& param);


    static bool getIntArray(QVector<int>& array, const QString& param);
    static bool getDoubleArray(QVector<double>& array, const QString& param);
    static bool getStringArray(QVector<QString>& array, const QString& param);

private:
    Parameters();

};


}

#endif  // TUM_ICS_PARAMS_PARAMETERS_H
