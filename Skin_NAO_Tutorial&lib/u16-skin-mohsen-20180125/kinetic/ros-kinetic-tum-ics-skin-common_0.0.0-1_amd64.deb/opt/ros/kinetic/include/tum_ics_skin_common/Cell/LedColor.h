#ifndef TUM_ICS_SKIN_CELL_LED_COLOR_H
#define TUM_ICS_SKIN_CELL_LED_COLOR_H

#include <ros/ros.h>
#include <tum_ics_skin_msgs/SkinCellLedColor.h>

#include <SkinCore/Cell/LedColor.h>

#include <QString>
#include <QVector>

namespace tum_ics_skin_common{
namespace Cell{

class LedColor :
        public ::Skin::Cell::LedColor
{
private:
    typedef tum_ics_skin_msgs::SkinCellLedColor LedColorMsg;

public:
     // from: "SkinCore/Implementation/Packets/Version2/PacketDefinitions.h"
    static const int BroadcastId;

    static LedColor fromMsg(const LedColorMsg& m);

    static LedColorMsg toMsg(const LedColor& c);
    static LedColorMsg& toMsg(LedColorMsg& m, const LedColor& c);


    static LedColorMsg toMsg(const ::Skin::Cell::LedColor& c,
                             int cellId = BroadcastId);

    static LedColorMsg& toMsg(LedColorMsg& m,
                              const ::Skin::Cell::LedColor& c,
                              int cellId = BroadcastId);

private:
    int m_cellId;

public:
    LedColor(int cellId = BroadcastId);
    LedColor(unsigned char r, unsigned char g, unsigned char b,
             int cellId = BroadcastId);

    LedColor(const unsigned char rgb[3], int cellId = BroadcastId);
    LedColor(const ::Skin::Cell::LedColor& c, int cellId = BroadcastId);
    LedColor(const LedColorMsg& m);

    LedColor(const LedColor& color);
    ~LedColor();

    void setCellId(int cellId);
    int cellId() const;

    operator LedColorMsg() const;

    LedColorMsg msg() const;
    LedColorMsg& msg(LedColorMsg&) const;

};


}}

#endif // TUM_ICS_SKIN_CELL_LED_COLOR_H
