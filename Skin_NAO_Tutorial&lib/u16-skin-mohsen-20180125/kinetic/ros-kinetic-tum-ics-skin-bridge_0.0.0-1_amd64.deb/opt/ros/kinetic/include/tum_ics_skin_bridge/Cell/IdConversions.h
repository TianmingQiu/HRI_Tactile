#ifndef TUM_ICS_SKIN_BRIDGE_CELL_ID_CONVERSIONS_H
#define TUM_ICS_SKIN_BRIDGE_CELL_ID_CONVERSIONS_H

#include <QString>

namespace tum_ics_skin_bridge{
namespace Cell{


class IdConversions
{
public:

    /*!
     * \brief Convert to patch id and cell id to global cell id.
     *
     * Global cell id: cell id + patch id * 1000.
     */
    static int toGlobalCellId(int cellId, int patchId);

    static int toPatchId(int globalCellId);
    static int toCellId(int globalCellId);

private:
    IdConversions();
};

}}

#endif // TUM_ICS_SKIN_BRIDGE_CELL_ID_CONVERSIONS_H
