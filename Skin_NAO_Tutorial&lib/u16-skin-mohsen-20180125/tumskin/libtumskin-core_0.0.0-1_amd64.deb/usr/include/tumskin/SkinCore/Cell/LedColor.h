/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINCELLLEDCOLOR_H
#define SKINCELLLEDCOLOR_H

#include <QVector>
#include <QMetaType>

namespace Skin{
namespace Cell{

/*!
 * \brief A type class for the definition of led colors of skin cells.
 *
 * This class defines led colors for skin cells and includes support
 * functions for defining colors by color code or by 8 bit RGB values.
 */
class LedColor
{

public:
    static const LedColor Black;    //!< Black LED color; rgb = (0,0,0)
    static const LedColor Red;      //!< Red LED color; rgb = (255,0,0)
    static const LedColor Green;    //!< Green LED color; rgb = (0,255,0)
    static const LedColor Blue;     //!< Blue LED color; rgb = (0,0,255)
    static const LedColor White;    //!< White LED color; rgb = (255,255,255)
    static const LedColor Yellow;   //!< Yellow LED color; rgb = (255,255,0)
    static const LedColor Cyan;     //!< Cyan LED color; rgb = (0,255,255)
    static const LedColor Magenta;  //!< Magenta LED color; rgb = (255,0,255)

public:

    /*!
     * \brief The different color codes
     */
    enum ColorCode
    {
        CodeUndefined       = -1,   //!< UNDEFINED color code
        CodeBlack           = 0,    //!< Red LED color code; rgb = (255,0,0)
        CodeRed             = 1,    //!< Green LED color code; rgb = (0,255,0)
        CodeGreen           = 2,    //!< Green LED color code; rgb = (0,255,0)
        CodeBlue            = 3,    //!< Blue LED color code; rgb = (0,0,255)
        CodeWhite           = 4,    //!< White LED color code; rgb = (255,255,255)
        CodeYellow          = 5,    //!< Yellow LED color code; rgb = (255,255,0)
        CodeCyan            = 6,    //!< Cyan LED color code; rgb = (0,255,255)
        CodeMagenta         = 7,    //!< Magenta LED color code; rgb = (255,0,255)
    };

    static const int ColorListSize;             //!< The size of the LED color list
    static const LedColor* ColorList[];         //!< The ordered list of pointers to LED colors
    static const ColorCode ColorCodeList[];     //!< The ordered list of LED color codes
    static const QString ColorNameList[];       //!< The ordered list of LED color names

private:
    unsigned char m_rgb[3];                     //!< The interal representation of LED colors in rgb

public:
    /*!
     * \brief Default constructor: The LED color black.
     */
    LedColor();
    ~LedColor();

    /*!
     * \brief Copy constructor.
     */
    LedColor(const LedColor& color);

    /*!
     * \brief RGB LED color constructor
     * \param r is the 8 bit value for the red color (0, ..., 255)
     * \param g is the 8 bit value for the green color (0, ..., 255)
     * \param b is the 8 bit value for the blue color (0, ..., 255)
     */
    LedColor(unsigned char r, unsigned char g, unsigned char b);

    /*!
     * \brief RGB LED color constructor
     * \param rgb is the 3 times 8 bit array for RGB color values
     */
    LedColor(const unsigned char rgb[3]);

    /*!
     * \brief Equality operator. Checks if all RGB values are equal
     */
    bool operator== (const LedColor& other) const;

    /*!
     * \brief Inequality operator. Negative Equality operator.
     */
    bool operator!= (const LedColor& other) const;

    /*!
     * \brief Gets the color code. Returns undefined if LED color is not defined as
     *        color code.
     * \return The color code.
     */
    ColorCode colorCode() const;

    unsigned char r() const; //!< The 8 bit value for the red color
    unsigned char g() const; //!< The 8 bit value for the green color
    unsigned char b() const; //!< The 8 bit value for the blue color

    const unsigned char* rgb() const; //!< The the 3 times 8 bit array for RGB color values

    /*!
     * \brief Creates a formated human readable string for displaying the information
     *        of this type class.
     * \return The formated string which describes this type class.
     */
    QString toString() const;

private:
//    LedColor(ColorCode code);
//    void toRGB(char* rgb, ColorCode code);

};


}
}

Q_DECLARE_METATYPE(Skin::Cell::LedColor)

#endif // SKINCELLLEDCOLOR_H
