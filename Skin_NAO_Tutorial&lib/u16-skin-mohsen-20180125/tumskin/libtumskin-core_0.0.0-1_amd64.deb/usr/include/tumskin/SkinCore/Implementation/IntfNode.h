/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINIMPL_INTFNODE_H
#define SKINIMPL_INTFNODE_H

#include <QMetaType>
#include <QVector>

#include <SkinCore/Implementation/TsuNode.h>
#include <SkinCore/Implementation/FtdiNode.h>

namespace Skin{
namespace Implementation{

class IntfNode
{
public:
    enum Type
    {
        UndefinedType   = 0,
        FtdiType        = 1,
        TsuType         = 2,
    };

    static const IntfNode Undefined;
//    static IntfNode Undefined();

    static QVector<IntfNode> fromTsuNodes(const QVector<TsuNode>& nodes);
    static QVector<IntfNode> fromFtdiNodes(const QVector<FtdiNode>& nodes);

private:
    TsuNode m_tsu;
    FtdiNode m_ftdi;

    Type m_type;

public:
    IntfNode();
    IntfNode(const IntfNode& n);
    IntfNode(const TsuNode& n);
    IntfNode(const FtdiNode& n);

    operator const TsuNode&() const;
    operator const FtdiNode&() const;

    bool operator== (const IntfNode& other) const;
    bool operator!= (const IntfNode& other) const;

    ~IntfNode();

    bool isDefined() const;
    IntfNode::Type type() const;

    QString toString() const;

};


}
}


#endif // SKINIMPL_INTFNODE_H
