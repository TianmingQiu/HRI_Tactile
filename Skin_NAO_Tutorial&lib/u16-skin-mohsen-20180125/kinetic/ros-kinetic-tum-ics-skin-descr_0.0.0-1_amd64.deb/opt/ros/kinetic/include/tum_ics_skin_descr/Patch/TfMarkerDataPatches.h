#ifndef TUM_ICS_SKIN_DESCR_PATCH_TF_MARKER_DATA_PATCHES_H
#define TUM_ICS_SKIN_DESCR_PATCH_TF_MARKER_DATA_PATCHES_H

#include <tum_ics_skin_descr/Patch/TfMarkerDataPatch.h>

namespace tum_ics_skin_descr{
namespace Patch{

/*!
 * \brief A functional class which simplifies loading and handling several skin patches
 *  at the same time.
 *
 * This class contains a vector of pointers to skin patches, which is filled by
 * loading skin patches by specifing file paths to their config .xml files. The
 * file paths can either be specified directly or by using a ROS parameter.
 */
class TfMarkerDataPatches
{
public:

protected:
    ros::NodeHandle m_node;
    ros::Publisher m_pub;

private:
    typedef tum_ics_skin_bridge::Cell::ActiveCellConfig ActiveCellConfig;

    QVector<TfMarkerDataPatch*> m_patches;
    QVector<int> m_patchIds;
    QMap<int,int> m_patchMap;    // map: patch id -> patch ind

    QVector<int> m_cellIds;

    QString m_markerNameSpace;
    QString m_cellTfNameBase;

    bool m_pubForceSignals;
    bool m_pubProxSignal;
    bool m_pubAccSignals;
    bool m_pubTempSignal;

public:
    /*!
     * \brief Default constructor.
     * \param markerNameSpace is the namespace for skin cell visualization markers in ROS.
     * \param cellTfNameBase is the name base for cell tfs in ROS.
     */
    TfMarkerDataPatches(const QString& markerNameSpace = "SkinCellMarkers",
              const QString& cellTfNameBase = "/sensor_");

    ~TfMarkerDataPatches();

    /*!
     * \brief Set the active cell config to use.
     */
    void setConfig(const ActiveCellConfig& config);

    /*!
     * \brief Loads the patch configuration from the specified patch configuration .xml
     *        files.
     *
     * NOTE: This function continues even if one load failed. Existing patches are overloaded
     * so be careful, because the pointers to the previous patches become invalid.
     * \param filePaths are the paths to the patch configuration .xml files to load.
     * \return True on success, False on error.
     */
    bool load(const QVector<QString>& filePaths);

    /*!
     * \brief Loades the patch configurations from the specified patch configuration
     *  .xml files names given by a ROS parameter.
     *
     * NOTE: This function continues even if one load failed. Existing patches are overloaded
     * so be careful, because the pointers to the previous patches become invalid.
     * \param path is the path to a folder containing patch configuration .xml files.
     * \param param is the ROS parameter which contains the patch configuration .xml
     *        file names.
     * \return True on success, False on error.
     */
    bool loadFromParam(const QString& path, const QString& param="~patch_list");

    /*!
     * \brief Creates data connections to the skin driver using the settings from
     *        the skin patch configuration files.
     * \param shared defines, whether the connection shares a skin data topic or not.
     *        If shared, then the topic is only subscribed to and NOT created in the
     *        skin driver.
     * \return True on success, False on error.
     */
    bool createDataConnections(bool shared=false);

    /*!
     * \brief Enables the data connections to the skin driver.
     *
     * NOTE: The data connections to the skin driver have to be created first, before
     * you can enable them. The call of this function has no effect if the connections are
     * not owned by this patch but shared.
     */
    void enableDataConnctions();

    /*!
     * \brief Disable the data connections to the skin driver.
     */
    void disableDataConnections();

    /*!
     * \brief Enables the automatic update of skin cell visualization markers.
     *
     * If enabled, then the skin cell visualization markers of this patch are updated
     * when new skin data is available.
     *
     * NOTE: By default the automatic update of markers is ENABLED.
     */
    void enableAutoUpdateMarkers();

    /*!
     * \brief Disables the automatic update of skin cell visualization markers.
     *
     * NOTE: For performance reasons disable the auto update for markers
     * when markers are not used.
     */
    void disableAutoUpdateMarkers();

    /*!
     * \brief Publish the ROS tfs and markers to visualize the skin patches in rviz.
     * \param dur is the duration for displaying a marker until the marker is
     *        updated. The default value means infinite duration. Specify a
     *        finite value if you want the markers to disappear after you stop
     *        publishing.
     */
    void publish(const ros::Duration& dur=ros::Duration());


    /*!
     * \brief Get the i-th patch from the patch pointer array.
     * \param i is the index of the patch pointer you want to get from the patch
     *        pointer array.
     * \return A pointer to the requested patch.
     */
    TfMarkerDataPatch* patch(int i) const;

    /*!
     * \brief Get the patch for the given patch index from the patch pointer array.
     * \param ind is the index of the patch pointer you want to get from the patch
     *        pointer array.
     * \return A pointer to the requested patch.
     */
    TfMarkerDataPatch* patchOfInd(int ind) const;

    /*!
     * \brief Get the patch for the given patch id from the patch pointer array.
     * \param id is the patch id of the patch you want to get from the patch
     *        pointer array.
     * \return A pointer to the requested patch.
     */
    TfMarkerDataPatch* patchOfPatchId(int id) const;

    /*!
     * \brief Get the patch for the given global cell id from the patch pointer array.
     * \param id is the global cell id of a cell in the patch you want to get from the patch
     *        pointer array.
     * \return A pointer to the requested patch.
     */
    TfMarkerDataPatch* patchOfGlobalCellId(int id) const;

    /*!
     * \brief Get an array of pointers to all the loaded patches.
     * \return An array of pointers to skin patches.
     */
    const QVector<TfMarkerDataPatch*>& patches() const;


    /*!
     * \brief Get the number of loaded skin patches.
     */
    int numberOfPatches() const;

    /*!
     * \brief Get the array index for the given patch id.
     *
     * NOTE: Indices always start at 0, are consecutive and positive. Ids start at 1,
     * are not necessarily consecutive but always positive.
     *
     * \param id is the skin patch id.
     * \return The array index for the given patch id. The index is -1 on error.
     */
    int index(int id) const;

    /*!
     * \brief Get the array index for the given patch id.
     *
     * NOTE: Indices always start at 0, are consecutive and positive. Ids start at 1,
     * are not necessarily consecutive but always positive.
     *
     * \param id is the skin patch id.
     * \return The array index for the given patch id. The index is -1 on error.
     */
    int indexOfPatchId(int patchId) const;

    /*!
     * \brief Get the array of skin patch ids.
     *
     * The array is ordered in such a way that a skin patch index
     * refers to an array element which belongs to that skin patch.
     * \return An ordered array of skin patch ids of all skin patches.
     */
    const QVector<int>& patchIds() const;



    /*!
     * \brief Get the number of loaded skin patches.
     */
    int numberOfCells() const;

    /*!
     * \brief Get the array of global skin cell ids.
     * \return An ordered array of global skin cell ids of all skin cells.
     */
    const QVector<int>& cellIds() const;



    /*!
     * \brief Sets the LED color of all the skin cells to a desired color.
     *
     * NOTE: The skin driver can only handle 1 color change every 2 ms. Faster calls
     * result in queued commands.
     *
     * \param c is the desired LED color of the skin cells.
     * \return A flag which is true on success and false on error.
     */
    bool setLedColor(const ::Skin::Cell::LedColor& c);

    /*!
     * \brief Sets the LED color of a specified skin cell to a desired color.
     *
     * NOTE: The skin driver can only handle 1 color change every 2 ms. Faster calls
     * result in queued commands.
     *
     * \param c is the desired LED color of the skin cell.
     * \param id is the global id of the skin cell which needs to change color.
     * \return A flag which is true on success and false on error.
     */
    bool setLedColor(const ::Skin::Cell::LedColor& c, int id);

    /*!
     * \brief Sets the LED color of specified skin cells to a desired color.
     *
     * NOTE: The skin driver can only handle 1 color change every 2 ms. Faster calls
     * result in queued commands.
     * \param c is the desired LED color of the skin cells.
     * \param id is the global id of the skin cells which need to change color.
     * \return A flag which is true on success and false on error.
     */
    bool setLedColor(const ::Skin::Cell::LedColor& c, const QVector<int>& ids);


private:
    void cleanup();

};

}}



#endif // TTUM_ICS_SKIN_DESCR_PATCH_TF_MARKER_DATA_PATCHES_H
