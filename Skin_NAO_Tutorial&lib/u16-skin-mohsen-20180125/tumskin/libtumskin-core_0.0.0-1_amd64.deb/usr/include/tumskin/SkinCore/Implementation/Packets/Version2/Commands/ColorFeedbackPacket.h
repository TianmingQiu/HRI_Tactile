/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINIMPLPKTS_COLORFEEDBACKPACKETV2_H
#define SKINIMPLPKTS_COLORFEEDBACKPACKETV2_H

#include <SkinCore/Implementation/Packet.h>
#include <SkinCore/Implementation/Packets/Version2/PacketDefinitions.h>

#include <SkinCore/Cell/LedColor.h>

namespace Skin{
namespace Implementation{
namespace Packets {
namespace Version2{
namespace Commands{

using namespace Skin::Cell;

class ColorFeedbackPacket : public Packet
{

public:
    enum Instruction
    {
        OffMode     = 0,
        StdMode     = 1,
        SetSettings = 2,
    };

    typedef struct
    {
        int proxThresh;         // 16 bit, raw
        int forceThresh;        // 10 bit, raw
        int delayCnts;          // 7 bit, 1 cnt = 1 ms
        LedColor::ColorCode idleColor;     // only color codes are supported
        LedColor::ColorCode proxColor;     // only color codes are supported
        LedColor::ColorCode forceColor;    // only color codes are supported
    } Settings;

    // default settings
    //      proxThresh  = 10000
    //      forceThresh = 100
    //      delayCounts = 100       400 ms
    //      idleColor   = 2         green
    //      proxColor   = 1         red
    //      forceColor  = 3         blue

    static const Settings defaultSettings;

    static const int PKT_SIZE = 20;
    static Packet& setId(Packet& p, int id);
    static void setInstr(Packet& p, Instruction instr);
    static void setSettings(Packet& p, const Settings& s);


public:
    ColorFeedbackPacket(Instruction instr,
                        int id=ID_ALL,
                        const QVector<Endpoint>& dest=QVector<Endpoint>());

    ColorFeedbackPacket(const Settings& s = defaultSettings,
                        int id=ID_ALL,
                        const QVector<Endpoint>& dest=QVector<Endpoint>());

    void setId(int id);
    void setInstr(Instruction instr);

    void setSettings(const Settings& s);

private:
    void init();

};

}}}}}

#endif // SKINIMPLPKTS_COLORFEEDBACKPACKETV2_H
