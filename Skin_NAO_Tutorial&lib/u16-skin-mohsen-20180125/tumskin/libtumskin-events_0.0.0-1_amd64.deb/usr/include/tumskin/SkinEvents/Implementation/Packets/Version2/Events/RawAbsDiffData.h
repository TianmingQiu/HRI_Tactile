/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINEVENTS_PACKETSV2_EVENTS_RAWABSDIFFDATAV2_H
#define SKINEVENTS_PACKETSV2_EVENTS_RAWABSDIFFDATAV2_H

#include <SkinCore/Implementation/Packet.h>
#include <SkinEvents/Implementation/Packets/Version2/Events/AbsDiffData.h>


namespace Skin{
namespace Implementation{
namespace Packets {
namespace Version2{
namespace Events{

class AbsDiffData;

class RawAbsDiffData
{
public:
    static unsigned int convToRawProx(double prox);
    static unsigned int convToRawForce(double force);
    static unsigned int convToRawAcc(double acc);
    static unsigned int convToRawTemp1(double temp1);
    static unsigned int convToRawTemp2(double temp2);

    static Skin::Cell::Events::Thresholds& convToThresholds(
            Skin::Cell::Events::Thresholds& t,
            const RawAbsDiffData& rd);

    static RawAbsDiffData& convToRawAbsDiffData(RawAbsDiffData& rd, const Skin::Cell::Events::Thresholds& t);
    static RawAbsDiffData& convToRawAbsDiffData(RawAbsDiffData& rd, const AbsDiffData& d);

    unsigned int prox;
    unsigned int force[3];
    unsigned int acc[3];
    unsigned int temp[2];


private:


public:
    RawAbsDiffData(unsigned int prox = 0,
                   unsigned int force1 = 0,
                   unsigned int force2 = 0,
                   unsigned int force3 = 0,
                   unsigned int acc1 = 0,
                   unsigned int acc2 = 0,
                   unsigned int acc3 = 0,
                   unsigned int temp1 = 0,
                   unsigned int temp2 = 0);

    RawAbsDiffData(const RawAbsDiffData& d);
    RawAbsDiffData(const AbsDiffData& d);
    RawAbsDiffData(const Skin::Cell::Events::Thresholds& t);
    RawAbsDiffData(const Packet& p);

    Skin::Cell::Events::Thresholds toThresholds() const;
    void abs();

    QString toString() const;
};

}}}}}

#endif // SKINEVENTS_PACKETSV2_EVENTS_RAWABSDIFFDATAV2_H
