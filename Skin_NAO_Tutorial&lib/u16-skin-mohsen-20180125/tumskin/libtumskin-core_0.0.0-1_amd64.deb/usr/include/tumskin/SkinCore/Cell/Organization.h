/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINCELL_ORGANIZATION_H
#define SKINCELL_ORGANIZATION_H

#include <QVector>
#include <QMetaType>

#include <Eigen/Eigen>
#include "Neighbors.h"

namespace Skin{
namespace Cell{

class Organization
{
public:
    static const Organization Undefined;

    static Eigen::Affine3d convToTf(const Eigen::Matrix3d& rot,
                                    const Eigen::Vector3d& pos);

    static Eigen::Matrix3d getRot(const Eigen::Affine3d& tf);
    static Eigen::Vector3d getPos(const Eigen::Affine3d& tf);


private:
    int             m_id;           // skin cell id, start at 1
    int             m_segment;      // segment id, start at 1
    int             m_patch;        // patch id, start at 1
    int             m_rootId;       // id of the root cell
    Neighbors       m_n;            // neighbors of cell
    Eigen::Vector3d m_pos;          // relative position with respect to reference/root skin cell
    Eigen::Matrix3d m_rot;          // relative rotation/orientation with respect to reference/root skin cell

public:

    Organization(const Organization& info);

    Organization(int cellId = 0,
                 const Eigen::Vector3d& pos = Eigen::Vector3d::Zero(),
                 const Eigen::Matrix3d& rot = Eigen::Matrix3d::Identity());

    Organization(int cellId,
                 int patchId,
                 int segmentId,
                 int rootCellId,
                 const Neighbors& n,
                 const Eigen::Vector3d& pos = Eigen::Vector3d::Zero(),
                 const Eigen::Matrix3d& rot = Eigen::Matrix3d::Identity());

    ~Organization();


    bool operator== (const Organization& other) const;
    bool operator!= (const Organization& other) const;

    bool isUndefined() const;

    void setCellId(int id);
    void setNeighbors(const Neighbors& n = Neighbors());
    void setPatchId(int patchId = 1);
    void setRootCellId(int refCellId = 1);
    void setSegmentId(int segmentId = 1);
    void setPos(const Eigen::Vector3d& pos = Eigen::Vector3d::Zero());
    void setRot(const Eigen::Matrix3d& rot = Eigen::Matrix3d::Identity());

    void setPatch(int patchId = 1, int refCellId = 1);

    void setPose(const Eigen::Matrix3d& rot = Eigen::Matrix3d::Identity(),
                 const Eigen::Vector3d& pos = Eigen::Vector3d::Zero());

    void setPose(const Eigen::Affine3d& tf = Eigen::Affine3d::Identity());


    int segmentId() const;
    int patchId() const;
    int cellId() const;
    int rootCellId() const;
    const Neighbors& neighbors() const;

    const Eigen::Vector3d& pos() const;
    const Eigen::Matrix3d& rot() const;

    Eigen::Affine3d tf() const;

    QString toString() const;

private:
    QString matrixToString(const Eigen::MatrixXd& m) const;
};

}}

Q_DECLARE_METATYPE(Skin::Cell::Organization)
Q_DECLARE_METATYPE(QVector<Skin::Cell::Organization>)

#endif // SKINCELL_ORGANIZATION_H
