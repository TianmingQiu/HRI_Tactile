#ifndef TUM_ICS_SKIN_FULL_CONFIG_CALIB_DH_TF_WIDGET_H
#define TUM_ICS_SKIN_FULL_CONFIG_CALIB_DH_TF_WIDGET_H

#include <QWidget>
#include <QStatusBar>
#include <QComboBox>
#include <QPushButton>

//This definition is needed with libboost 1.58
#ifndef Q_MOC_RUN
#include <SkinCore/Config/Config.h>
#include <tum_ics_skin_descr/Patch/Extrinsics.h>

#include <tf/transform_listener.h>
#include <tum_ics_tfs/TfContainer.h>
#endif



namespace tum_ics_skin_full_config
{

namespace Ui {
class CalibDhTfWidget;
}

class CalibDhTfWidget : public QWidget
{
    Q_OBJECT


private:
    typedef tum_ics_skin_descr::Patch::Extrinsics PatchExtrinsics;
    typedef tum_ics_tfs::TfContainer TfContainer;

    enum State
    {
        UndefinedPatch,
        SelectDhFrame,
        DhTfStart,
        DhTfRunning,
        DhTfStop,
    };


    Ui::CalibDhTfWidget *ui;

    QStatusBar* m_sb;

    QComboBox* m_cbDhFrame;
    QPushButton* m_pbDhTf;
    QPushButton* m_pbSave;

    QVector<QString> m_dhFrames;
    QVector<int> m_dhIds;


    // current input patch
    Skin::Patch m_patch;
    QString m_prefix;
    tum_ics_skin_descr::Patch::Extrinsics m_patchExtrinsics;

    tf::TransformListener m_tfListener;

    Eigen::Affine3d m_tf_base_dh;

    State m_state;
    QString m_defaultPath;

public:
    explicit CalibDhTfWidget(QWidget *parent = 0);
    ~CalibDhTfWidget();

    bool init(QStatusBar* sb, const QString& defaultPath = ".");
    void setDefaultPath(const QString& path = ".");

    // call this function in the main while loop
    void update();

private:
    void updateGui();

    void status(const QString& msg);
    void warning(const QString& msg);
    void error(const QString& msg);

    int jointId() const;
    QString dhFrame() const;

    // name wrt base; on error returns identity tf with correct name and base
    TfContainer getTf(const QString& name, const QString& base, bool* ok=0) const;

public slots:
    void newSkinPatch(::Skin::Patch patch,
                      QString prefix,
                      tum_ics_skin_descr::Patch::Extrinsics pe);
private slots:
    void pbDhTfClicked();
    void pbSaveClicked();

signals:
    // lock other GUIs
    void lockGui(bool enable);
};

}

#endif // TUM_ICS_SKIN_FULL_CONFIG_CALIB_DH_TF_WIDGET_H
