/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINCORE_EVENTS_FLAGS_H
#define SKINCORE_EVENTS_FLAGS_H

#include <QString>
#include <QVector>

namespace Skin{
namespace Events{

class Flags
{
public:
    static const Flags AllFlags;
    static const Flags NoFlags;

    static bool check(const Flags& mask, const Flags& flags);
    static Flags& set(Flags& mask, const Flags& flags);
    static Flags& clear(Flags& mask, const Flags& flags);

private:
    int m_mask;

public:
    Flags(const Flags& flags = NoFlags);
    Flags(int mask);

    // only check cell id and type id
    bool operator== (const Flags& other) const;
    bool operator!= (const Flags& other) const;

    // for QMap
    bool operator< (const Flags& other) const;

    operator const int&() const;

    bool check(const Flags& f) const;
    bool check(int index) const;

    Flags& set(const Flags& f = AllFlags);
    Flags& clear(const Flags& f = AllFlags);

    int mask() const;

    QString toString() const;
};

}}

#endif // SKINCORE_EVENTS_FLAGS_H
