#ifndef TUM_ICS_SKIN_DESCR_PATCH_TF_PATCH_PUB_H
#define TUM_ICS_SKIN_DESCR_PATCH_TF_PATCH_PUB_H

#include <tf/transform_broadcaster.h>
#include <tum_ics_skin_descr/Patch/TfPatch.h>

namespace tum_ics_skin_descr{
namespace Patch{

// is a Tf Patch and provides facilities to broadcast TFs for rviz
class TfPatchPub : public TfPatch
{
private:
    typedef ::Skin::Cell::Organization Organization;
    typedef ::Skin::Cell::Data Data;
    typedef ::Skin::Patch Patch;

    tf::TransformBroadcaster m_tfPub;

public:

    // default: create data publisher in driver and connect to it
    // if dataTopic is specified, then subsribe to it
    TfPatchPub(const QString& markerNameSpace = "SkinCellMarkers",
               const QString& cellTfNameBase = "/sensor_");

    ~TfPatchPub();

    void publish();

private:


};

}}


#endif // TUM_ICS_SKIN_DESCR_PATCH_TF_PATCH_PUB_H
