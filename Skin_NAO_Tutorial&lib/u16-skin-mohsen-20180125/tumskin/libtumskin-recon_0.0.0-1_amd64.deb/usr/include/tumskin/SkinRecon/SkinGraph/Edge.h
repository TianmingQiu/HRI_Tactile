/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINRECON_SKINGRAPH_EDGE_H
#define SKINRECON_SKINGRAPH_EDGE_H


#include <Eigen/Eigen>

namespace Skin{
namespace Reconstruction{
namespace SkinGraph{


class Edge
{

private:
    int m_srcId;
    int m_destId;

public:
    Edge(int srcId=0, int destId=0);
    Edge(const Edge& p);
    ~Edge();

    Edge &operator=(const Edge &other);

    bool operator<(const Edge& other) const;
    bool operator==(const Edge& other) const;


    int src() const;
    int dest() const;

};


}
}
}



#endif // SKINRECON_EDGE_H
