#ifndef SKINMANAGERS_APPLICATION_BASE_INTFCMDHANDLER_H
#define SKINMANAGERS_APPLICATION_BASE_INTFCMDHANDLER_H

#include <SkinManagers/Application/ConsoleCmdHandler.h>
#include <SkinManagers/Application/Base/Application.h>

namespace Skin {
namespace Managers{
namespace Application{
namespace Base{


class IntfCmdHandler : public ConsoleCmdHandler
{
private:
    Skin::Managers::Application::Base::Application* m_app;
public:
    IntfCmdHandler(Skin::Managers::Application::Base::Application* app);
    virtual bool handleMessage(const QString &s);
    virtual QString cmdDescription() const;
};


}}}}

#endif // SKINMANAGERS_APPLICATION_BASE_INTFCMDHANDLER_H
