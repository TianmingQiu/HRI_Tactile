/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKIN_CELL_MASTERPORT_H
#define SKIN_CELL_MASTERPORT_H

#include <QVector>
#include <QMetaType>
#include <QTextStream>

#include "AccCalib.h"

namespace Skin{
namespace Cell{

class MasterPort
{

private:
    int m_id;   // cell id starts at one
    int m_mp;   // mp is {1,2,3,4}, one port on cell

public:
    MasterPort(int id=0, int mp=0);
    MasterPort(const MasterPort& mp);
    ~MasterPort();

    bool operator== (const MasterPort& other) const;
    bool operator!= (const MasterPort& other) const;

    // for QMap
    bool operator< (const MasterPort& other) const;

    int id() const;
    int mp() const;

    QString toString() const;

};

}
}

QTextStream& operator << (QTextStream& s, const Skin::Cell::MasterPort&);
QTextStream& operator >> (QTextStream& s, Skin::Cell::MasterPort&);

Q_DECLARE_METATYPE(Skin::Cell::MasterPort)
Q_DECLARE_METATYPE(QVector<Skin::Cell::MasterPort>)

#endif // SKIN_CELL_MASTERPORT_H
