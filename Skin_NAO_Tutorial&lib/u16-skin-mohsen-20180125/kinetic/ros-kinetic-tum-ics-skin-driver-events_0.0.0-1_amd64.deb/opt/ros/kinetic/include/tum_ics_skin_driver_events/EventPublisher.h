#ifndef TUM_ICS_SKIN_DRIVER_EVENTS_EVENT_PUBLISHER_H
#define TUM_ICS_SKIN_DRIVER_EVENTS_EVENT_PUBLISHER_H

#include <QVector>
#include <QMap>

//This definition is needed with libboost 1.58
#ifndef Q_MOC_RUN
#include <ros/ros.h>

#include <tum_ics_skin_common_events/Cell/Events/Event.h>
#include <tum_ics_skin_common_events/Cell/Events/EventsConfig.h>
#endif

namespace tum_ics_skin_driver_events{

class EventPublisher
{
private:
    typedef tum_ics_skin_common_events::Cell::Events::EventsConfig EventsConfig;

public:

private:
    ros::NodeHandle m_node;
    ros::Publisher  m_pub;

    QVector<EventsConfig> m_configs;
    QMap<int,int> m_cellIdMap;      // map: id -> ind

    QString m_name;
    bool m_enabled;

public:
    EventPublisher(const QString& name,
                   const QVector<EventsConfig>& c);

    ~EventPublisher();

    void enable();
    void disable();

    void setEnabled(bool enable);

    const QString& name() const;

    // publish data
    void publish(const QVector<Skin::Cell::Events::Event>&);

};

}

#endif // TUM_ICS_SKIN_DRIVER_EVENTS_EVENT_PUBLISHER_H
