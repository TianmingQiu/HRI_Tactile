#ifndef SKINMANAGERS_PROGRAMMER_H
#define SKINMANAGERS_PROGRAMMER_H


#include <QObject>
#include <QThread>
#include <SkinCore/Implementation/Programmers/Version2/StdProgrammer.h>

namespace Skin{
namespace Managers{
namespace Programmer{

namespace ProgsV2 = Skin::Implementation::Programmers::Version2;

class Programmer : public QObject
{
    Q_OBJECT

public:
    enum ProgrammerType
    {
        SingleIntfTsu    = 0,
        SingleIntfFtdi,
        MultiIntfTsu,       // -> down from here: NOT supported
        MultiIntfFtdi,
    };

    // mode
    //      StdBootloader       the old bulcky bootloader
    //      NewBootloader       the new tiny chris design bootloader
    typedef ProgsV2::StdProgrammer::Mode Mode;

    static const Mode StdBootloader;
    static const Mode NewBootloader;

private:
    typedef bool (Programmer::*cmd_handler_func)(const QString& s);
    QVector<cmd_handler_func> m_cmdHandlers;

    QString                             m_consoleCmdDescription;
    ProgrammerType                      m_currProgrammerType;


    ProgsV2::StdProgrammer*             m_currProg;
    QList<ProgsV2::StdProgrammer*>      m_progs;

    QVector<QThread*>                   m_threads;


public:
    explicit Programmer(QObject *parent = 0);

    ProgrammerType type() const;
    bool isProgramming() const;

    ProgsV2::StdProgrammer* programmer();

    const QString& consoleCmdDescription() const;
    bool handleConsoleCmd(QString);

private:
    void connectProgrammer(Skin::Implementation::Programmer* prog);
    void disconnectProgrammer(Skin::Implementation::Programmer* prog);

    bool handleInterfaceCommands(const QString& s);
    bool handleProgrammerCommands(const QString& s);

private slots:


public slots:
    void switchProgrammer(Skin::Managers::Programmer::Programmer::ProgrammerType t);
    void switchProgrammerMode(Skin::Managers::Programmer::Programmer::Mode m);

    // safe mode: avoid overriding flash parameters of app
    // writes to pages > 0x9000 are blocked
    void program(QString filename, bool eraseConfig=false, bool safeMode=true);

signals:
    void programFailed(void);
    void programmed(void);
    void progress(double p); // in percent

};


}}}


#endif // SKINMANAGERS_PROGRAMMER_H
