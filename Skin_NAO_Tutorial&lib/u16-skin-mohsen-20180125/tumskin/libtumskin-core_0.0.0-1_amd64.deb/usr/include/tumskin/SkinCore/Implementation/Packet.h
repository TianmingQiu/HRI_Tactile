/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINIMPLPACKET_H
#define SKINIMPLPACKET_H

#include <QByteArray>
#include <QVector>
#include <QString>

#include "Endpoint.h"
#include "TimestampedData.h"

namespace Skin{
namespace Implementation{

class Packet
{
public:
    // ATTENTION: this is for standard id places; there are some packets
    //  which place there id on a different place!
    static int getId(const Packet& p);
    static void setId(Packet& p, int id);

protected:
    Endpoint            m_src;      // single src
    QVector<Endpoint>   m_dest;     // one or mulitiple dests, to all if empty
    TimestampedData     m_data;     // data with ns timestamp

public:
    Packet();
    Packet(const Packet& p);

    Packet(const Endpoint& src,
           const TimestampedData& data=TimestampedData());

    Packet(const TimestampedData& data,
           const QVector<Endpoint>& dest=QVector<Endpoint>());


    bool operator== (const Packet& other) const;
    bool operator!= (const Packet& other) const;

    qint64 ts() const;

    // for single Endpoint sources
    const Endpoint& src() const;

    // for multiple Endpoint destinations
    const QVector<Endpoint>& dest() const;

    const TimestampedData& data() const;
    TimestampedData& data();

    void clear();
    int size() const;

    QString toString() const;

};

}
}

#endif // SKINIMPLPACKET_H
