#ifndef TUM_ICS_SKIN_DESCR_PATCH_TF_MARKER_PATCH_H
#define TUM_ICS_SKIN_DESCR_PATCH_TF_MARKER_PATCH_H

#include <tum_ics_skin_descr/Patch/TfPatchPub.h>
#include <tum_ics_skin_descr/Patch/MarkersPub.h>

namespace tum_ics_skin_descr{
namespace Patch{

// is a Tf Patch and provides facilities to broadcast TFs for rviz
class TfMarkerPatch :
        public TfPatchPub,
        public tum_ics_skin_common::CallbackProvider<QVector< ::Skin::Cell::Data> >
{
private:
    typedef ::Skin::Cell::Organization Organization;
    typedef ::Skin::Cell::Data Data;
    typedef ::Skin::Patch Patch;

    typedef QVector< ::Skin::Cell::Data> DataBunch;
    typedef tum_ics_skin_descr::Patch::DriverSettings PatchDriverSettings;
    typedef tum_ics_skin_descr::Patch::Extrinsics PatchExtrinsics;

protected:
    Markers* m_markers;
    MarkersPub m_markersPub;

public:
    // NOTE: you can add this class to any already existing
    //  data subscriber as it has a new data array callback

    TfMarkerPatch(const QString& markerNameSpace = "SkinCellMarkers",
                  const QString& cellTfNameBase = "/sensor_");

    ~TfMarkerPatch();

    // overload functions which also induces changes on markers
    //  (basically everything which changes the TfBranch names of the cells)
    bool load(const QString& filePath, int patchId = 0);
    bool loadDialog(const QString& path = QString(), int patchId = 0);

    bool create(const Patch& patch,
                const PatchExtrinsics& pe = PatchExtrinsics::Default());

    bool create(const Patch& patch,
                const PatchDriverSettings& pds,
                const PatchExtrinsics& pe = PatchExtrinsics::Default());

    bool create(const TfPatch& patch);


    // update the marker values
    void update(const ::Skin::Cell::Data& d);
    void update(const DataBunch& d);

    // only the cell markers
    visualization_msgs::MarkerArray cellMarkers(
            const ros::Duration& dur = ros::Duration(),
            const QString& ns="");

    // only the cell signal markers
    visualization_msgs::MarkerArray cellSignalMarkers(
            const ros::Duration& dur = ros::Duration(),
            const QString& ns="");

    /*!
     * \brief Get the markers for a signal of all cells
     *
     *  - ind 0: prox
     *  - ind 1: force1
     *  - ind 2: force2
     *  - ind 3: force3
     *  - ind 4: accX
     *  - ind 5: accY
     *  - ind 6: accZ
     *  - ind 7: temp
     */
    visualization_msgs::MarkerArray cellSignalMarker(
            int markerInd,
            const ros::Duration& dur = ros::Duration(),
            const QString& ns="");

    // all the markers of a patch
    visualization_msgs::MarkerArray markers(
            const ros::Duration& dur = ros::Duration(),
            const QString& ns="");

    // publish tfs and markers (empty namespace: use default namespace)
    void publish(const ros::Duration& dur=ros::Duration(),const QString& ns="");

    void publishTfs();
    void publishMarkers(
            const ros::Duration& dur=ros::Duration(),
            const QString& ns=""); // markers for all cells

private:
    // data array callback of DataSubscriber
    void callback(const DataBunch &);

};

}}


#endif // TUM_ICS_SKIN_DESCR_PATCH_TF_MARKER_PATCH_H
