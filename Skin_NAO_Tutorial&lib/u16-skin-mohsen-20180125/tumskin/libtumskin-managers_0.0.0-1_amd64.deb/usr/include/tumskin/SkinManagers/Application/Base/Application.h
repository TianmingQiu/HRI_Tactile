#ifndef SKINMANAGERS_APPLICATION_BASE_APPLICATION_H
#define SKINMANAGERS_APPLICATION_BASE_APPLICATION_H


#include <QObject>
#include <QMap>

#include <Threads/Thread.h>
#include <SkinCore/Cell/LedColor.h>
#include <SkinCore/Implementation/Packet.h>
#include <SkinCore/Implementation/Operator.h>
#include <SkinCore/Implementation/IntfNode.h>
#include <SkinCore/Cell/Events/Event.h>

#include <SkinManagers/Application/ConsoleCmdHandler.h>
#include <SkinManagers/Application/Type.h>


namespace Skin {
namespace Managers{
namespace Application{
namespace Base{


using namespace Skin::Cell;
using namespace Skin::Implementation;


class Application : public QObject
{
    Q_OBJECT

private:

public:
    typedef Skin::Implementation::IntfNode IntfNode;

protected:
    QVector<ConsoleCmdHandler*> m_intfCmdHandlers;
    QVector<ConsoleCmdHandler*> m_appCmdHandlers;

    QString             m_consoleCmdDescription;
    QString             m_intfCmdDescription;
    QString             m_appCmdDescription;

    Type                m_currAppType;

    Operator*               m_currApp;
    QMap<Type,Operator*>    m_appMap;

    QVector<Threads::Thread*>   m_threads;

public:
    explicit Application(QObject *parent = 0);

    const Type& type() const;
    bool isConnected() const;

    Operator* application();

    const QString& consoleCmdDescription() const;
    const QString& intfCmdDescription() const;
    const QString& appCmdDescription() const;

    bool handleConsoleCmd(QString);

    bool handleIntfCmd(QString);
    bool handleAppCmd(QString);

    bool autoConnect(const Type& t, const IntfNode& n = IntfNode(), int timeout=5000);
    bool autoDisconnect();

protected:
    void startThreads();

private:
    void connectApplication(Operator* app);
    void disconnectApplication(Operator* app);

private slots:

public slots:
    void connect();
    void connect(Skin::Managers::Application::Type t, IntfNode n = IntfNode());
    void disconnect();

    void switchApplication(Skin::Managers::Application::Type t);

    void changeLedColor(Skin::Cell::LedColor color);
    void changeLedColor(Skin::Cell::LedColor color,int id);

    virtual void exploreMasterPorts(bool explore);

    void sendMemoryCommand(Skin::Implementation::Operator::MemoryCommand cmd);
    void sendPacket(Skin::Implementation::Packet);

signals:
    void connected();
    void connectFailed();
    void disconnected();

    void newNumberOfCells(int);
    void newNeighborList(QVector<Skin::Cell::Neighbors>);

    void ledColorChanged(Skin::Cell::LedColor color);
    void ledColorChanged(Skin::Cell::LedColor color,int id);

    void newDataBunch(QVector<Skin::Cell::Data>);
    void newPacketBunch(QVector<Skin::Implementation::Packet>);
    void newEventDataPacketBunch(QVector<Skin::Implementation::Packet>);
    void newEventBunch(QVector<Skin::Cell::Events::Event>);

};

}}}}




#endif // SKINMANAGERS_APPLICATION_BASE_APPLICATION_H
