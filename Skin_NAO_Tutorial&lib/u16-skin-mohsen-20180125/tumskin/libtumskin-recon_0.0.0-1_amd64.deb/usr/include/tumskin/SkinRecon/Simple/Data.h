/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINRECON_SIMPLE_DATA_H
#define SKINRECON_SIMPLE_DATA_H

#include <QObject>
#include <QVector>
#include <QMap>
#include <QElapsedTimer>
#include <QMetaType>

#include <Eigen/Eigen>

namespace Skin{
namespace Recon{
namespace Simple{

class Data
{
public:
    static const Data Default;

private:
    static const QVector<Eigen::Vector3d> defaultVec;
    static const Eigen::Vector3d defaultSample;

private:
    int m_numOfSamples;             // the total number of successfully added samples
    int m_numOfPoses;               // the number of poses
    int m_numOfCells;               // the number of cells

    QVector<int> m_cellIds;         // list of cell ids
    QMap<int,int> m_cellIdMap;      // map cell id to index

    // 3d array:
    //      first dimension:    pose index, ordered index 0 = pose 1
    //      second dimension:   cell index, not ordered, map exits
    //      third dimension:    sample index, ordered
    QVector< QVector< QVector<Eigen::Vector3d> > > m_data;

    // notes:
    // - the first and second dimensions of the array have defined sizes
    // - the cells are ordered according to the map for each pose
    // - the samples (third dim) are not fixed
    // - ids are always positive and start at 1
    // - indices are always positive, ordered, consecutive and start at 0

public:
    Data(int numberOfCells = 0, int numberOfPoses = 1);
    Data(const Data& d);
    ~Data();

    // create and initialize data
    void init(int numberOfCells = 0, int numberOfPoses = 1);


    // clears data array and reinits everything
    void clear();


    bool isEmpty() const;
    int indexOfCell(int cellId) const;


    // direct access to 3d array
    const QVector<Eigen::Vector3d>&  operator() (int poseInd, int cellInd) const;
    QVector<Eigen::Vector3d>&  operator() (int poseInd, int cellInd);

    const Eigen::Vector3d& operator() (int poseInd, int cellInd, int sampleInd) const;
    Eigen::Vector3d& operator() (int poseInd, int cellInd, int sampleInd);


    // pose starts at 0, should be in the map
    bool appendSample(const Eigen::Vector3d& d, int cellId, int poseInd=0);

    // returns Eigen::Vector3d() on failure
    const Eigen::Vector3d& sample(int sampleInd, int cellId, int poseInd=0) const;

    // vector of all samples of a pose of one cell
    // empty on failure
    const QVector<Eigen::Vector3d>& samples(int cellId, int poseInd=0) const;

    // normalized mean sample vector for a cell
    //  returns (0,0,1) on error
    Eigen::Vector3d normalizedMean(int cellId, int poseInd=0) const;


    // the number of poses
    int numberOfPoses() const;

    // the number of cells
    int numberOfCells() const;

    // total number of samples
    int numberOfSamples() const;

    // number of samples of a cell for a given pose
    int numberOfSamples(int cellId, int poseInd=0) const;


    // a list of all cell ids of a pose which have at least the given number
    // samples
    QVector<int> complete(int numOfSamples, int poseInd) const;
    QVector<int> incomplete(int numOfSamples, int poseInd) const;

    // the mean vector of all the samples of a cell
    Eigen::Vector3d mean(int cellId, int poseInd=0) const;

    // map: cellInd -> cellId
    const QVector<int>& cellIds() const;

    // inverse map: cellId -> cellInd
    const QMap<int,int>& cellIdMap() const;

};

}}}

Q_DECLARE_METATYPE(Skin::Recon::Simple::Data)
Q_DECLARE_METATYPE(QVector<Skin::Recon::Simple::Data>)

#endif // SKINRECON_SIMPLE_DATA_H
