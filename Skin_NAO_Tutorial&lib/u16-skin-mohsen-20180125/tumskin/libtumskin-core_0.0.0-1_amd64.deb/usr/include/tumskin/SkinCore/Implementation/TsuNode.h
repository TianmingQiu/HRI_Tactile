/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINIMPL_TSUNODE_H
#define SKINIMPL_TSUNODE_H

#include <QMetaType>
#include <QVector>

namespace Skin{
namespace Implementation{

class TsuNode
{
public:
    static const TsuNode Undefined;         // undefined, empty

    // standard node
    //  ip: 192.168.0.10, tsu-port: 1336, pc-port: 1337
    static const TsuNode StdNode;

    // some predefined nodes
    //  [0]:    ip: 192.168.0.10, tsu-port: 1336, pc-port: 1337, ra
    //  [1]:    ip: 192.168.0.11, tsu-port: 1336, pc-port: 2337, la
    //  [2]:    ip: 192.168.0.12, tsu-port: 1336, pc-port: 3337, rh
    //  [3]:    ip: 192.168.0.13, tsu-port: 1336, pc-port: 4337, lh
    static const QVector<TsuNode> StdNodes; // some predefined nodes

private:
    QString m_tsuIpAddr;
    quint16 m_tsuPort;
    quint16 m_pcPort;

public:
    TsuNode();
    TsuNode(const TsuNode& s);
    TsuNode(const QString& tsuIpAddr,
                quint16 tsuPort = 1336,
                quint16 pcPort = 1337);

    ~TsuNode();

    bool operator== (const TsuNode& other) const;
    bool operator!= (const TsuNode& other) const;

    const QString& tsuIpAddr() const;
    quint16 tsuPort() const;
    quint16 pcPort() const;

    QString toString() const;

};


}
}


#endif // SKINIMPL_TSUNODE_H
