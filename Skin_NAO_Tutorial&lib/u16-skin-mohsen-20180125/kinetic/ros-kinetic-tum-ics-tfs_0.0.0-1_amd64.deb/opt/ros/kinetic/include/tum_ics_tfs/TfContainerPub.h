#ifndef TUM_ICS_TFS_TF_CONTAINER_PUB_H
#define TUM_ICS_TFS_TF_CONTAINER_PUB_H

#include <QString>
#include <QVector>

#include <tf/transform_broadcaster.h>
#include <tum_ics_tfs/TfContainer.h>

namespace tum_ics_tfs{

class TfContainerPub : public TfContainer
{
public:

private:
    tf::TransformBroadcaster m_tfPub;

public:
    TfContainerPub(const QString& name,
                   const QString& baseFrame,
                   const QString& nameSpace    = "Default");

    TfContainerPub(const QString& name,
                   const QString& baseFrame,
                   const tf::Transform& tf     = tf::Transform::getIdentity(),
                   const QString& nameSpace    = "Default");

    TfContainerPub(const QString& name,
                   const QString& baseFrame,
                   const Eigen::Affine3d&,
                   const QString& nameSpace    = "Default");

    TfContainerPub(const TfBranch& tfBranch    = TfBranch::Default(),
                   const tf::Transform& tf     = tf::Transform::getIdentity());

    TfContainerPub(const TfBranch& tfBranch,
                   const Eigen::Affine3d& tf);

    TfContainerPub(const TfContainer& tfc);


    ~TfContainerPub();

    void publish(const ros::Time& t = ros::Time::now());

    void publish(const QVector<TfContainer>& tfcs,
                 const ros::Time& t = ros::Time::now());

    void publish(const TfContainer& tfc,
                 const ros::Time& t = ros::Time::now());

private:

};

}

#endif // TUM_ICS_TFS_TF_CONTAINER_PUB_H
