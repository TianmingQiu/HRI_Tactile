#ifndef SKINEVENTS_ADDITONS_EVENTLOGGERADV_H
#define SKINEVENTS_ADDITONS_EVENTLOGGERADV_H


#include <QObject>
#include <QTimer>
#include <QThread>
#include <QMutex>
#include <QFile>

#include <SkinCore/Cell/Neighbors.h>
#include <SkinManagers/Application/Base/Application.h>
#include <SkinCore/Implementation/Packets/Version2/PacketDefinitions.h>

namespace Skin {
namespace Additions{

class EventLoggerAdv : public QObject
{
    Q_OBJECT

public:

private:

public:

private:
    typedef bool (EventLoggerAdv::*cmd_handler_func)(const QString& s);
    QVector<cmd_handler_func> m_cmdHandlers;
    QString             m_consoleCmdDescription;

    Skin::Managers::Application::Base::Application* m_app;


    QVector<int>        m_cellIds;
    QVector<int>        m_usrCellIds;
    QMap<int,int>       m_cellIdMap;    // map: id -> ind;
    QVector<QFile*>     m_files;        // events
    QVector<QFile*>     m_cfiles;       // complete events
    QFile*              m_err;
    QFile*              m_pktFile;      // all event packets

    QString             m_path;

    bool                m_started;
    QVector<QThread*>   m_threads;
    QMutex              m_mutex;

public:
    explicit EventLoggerAdv(Skin::Managers::Application::Base::Application* app,
                        QObject *parent = 0);

    void setPath(const QString& path = "./cellEventsLogsAdv");

    const QString& consoleCmdDescription() const;
    bool handleConsoleCmd(QString);

private:
    bool handleEventLoggerAdvCommands(const QString& s);

    bool open();
    void close();
    void clear();

private slots:
    void newNeighborList(QVector<Skin::Cell::Neighbors>);
    void newEventDataPacketBunch(QVector<Skin::Implementation::Packet>);

public slots:
    void start(QVector<int> cellIds = QVector<int>());
    void stop();

signals:


};

}}

#endif // SKINEVENTS_ADDITONS_EVENTLOGGERADV_H
