/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINRECON_SKINGRAPH_GRAPH_H
#define SKINRECON_SKINGRAPH_GRAPH_H

//#include <QMetaType>

#include <QVector>
#include <QString>
#include <QMap>

#include <boost/graph/graph_traits.hpp>
#include <boost/graph/adjacency_list.hpp>
#include <boost/graph/dijkstra_shortest_paths.hpp>
#include <boost/graph/connected_components.hpp>

#include "VertexProperties.h"
#include "EdgeProperties.h"
#include "GraphProperties.h"
#include "Edge.h"



namespace Skin{
namespace Reconstruction{
namespace SkinGraph{


// BGLGraph typedef
typedef boost::adjacency_list<  boost::setS,            // no parallel edges (multi-graph) allowed
                                boost::vecS,            // automatic assignment of vertex indices by vector
                                boost::bidirectionalS,  // bidirectional edges
                                VertexProperties,       // vertex properties
                                EdgeProperties,         // edge properties
                                GraphProperties,        // graph properties
                                boost::listS            // edge storage type
                             >
                    BGLGraph;

class Graph
{
public:
    enum InterationMode
    {
        VertexIteration,
        EdgeIteration
    };

private:
    BGLGraph m_graph;

    typedef boost::graph_traits<BGLGraph>::vertex_descriptor BGLVertex;
    typedef boost::graph_traits<BGLGraph>::edge_descriptor BGLEdge;

    QMap<int,BGLVertex>     m_vertexMap;       // map cell id to vertex
    QMap<Edge,BGLEdge>      m_edgeMap;         // map cell id src& dest to edge

public:
    Graph();
    Graph(const Graph& g);
    ~Graph();

    BGLGraph& graph();

    void addVertex(int cellId);
    void addVertex(const VertexProperties& p);
    void addVertices(QVector<int> cellIds);
    void addVertices(const QVector<VertexProperties>& p);

    void addEdge(int srcCellId, int destCellId);
    void addEdge(const Edge& e);
    void addEdge(const EdgeProperties& p);
    void addEdges(const QVector<Edge>& e);
    void addEdges(const QVector<EdgeProperties>& p);

    VertexProperties& vertexProperties(int cellId);
    EdgeProperties& edgeProperties(const Edge& e);
    GraphProperties& graphProperties();

    const VertexProperties& vertexProperties(int cellId) const;
    const EdgeProperties& edgeProperties(const Edge& e) const;
    const GraphProperties& graphProperties() const;

    QList<int> cellIds() const;
    QList<Edge> edges() const;

    void deleteEdges();
    void deleteVertices();

    void clear();

    // graphviz: program "dot"
    // saves graph in graphviz format
    bool saveGraphForGraphviz(const QString& filename=QString("./skingraph.dot")) const;

    // saves reconstruction in matlab file
    bool saveReconToMatlabScript(const QString& filename=QString("./recon.m")) const;

    // do a connected components analysis,
    // find patches and reset patch reference ids and accumulated paths
    void findPatches();

    // start at each vertex, run dijkstra using weighted edges and thus
    // find shortest path to all connected cells,
    // add all distances to get accumulated path
    // check if accumulated path is better than the one we already have
    // if so, store new accumulated path and new root cell id
    void findPatchRootCells();


    // run dijkstra from every root cell and get the predecessor cell id
    // for each cell in the shortested path and also the weight distance
    // to the root cell
    void findShortestPathsInPatches();
};


}
}
}



#endif // SKINRECON_SKINGRAPH_GRAPH_H
