#ifndef SKINEVENTS_MANAGERS_APPLICATION_STANDARD_H
#define SKINEVENTS_MANAGERS_APPLICATION_STANDARD_H

#include <QObject>
#include <SkinManagers/Application/Standard/Application.h>

namespace Skin{
namespace Managers{
namespace Application{
namespace Standard{
namespace Events{


class Application : public Skin::Managers::Application::Standard::Application
{
    Q_OBJECT

private:

public:

private:

public:
    explicit Application(QObject *parent = 0);


};

}}}}}




#endif // SKINEVENTS_MANAGERS_APPLICATION_STANDARD_H
