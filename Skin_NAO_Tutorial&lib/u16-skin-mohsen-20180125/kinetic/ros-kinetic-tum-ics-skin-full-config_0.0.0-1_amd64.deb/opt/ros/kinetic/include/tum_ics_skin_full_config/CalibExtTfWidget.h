#ifndef TUM_ICS_SKIN_FULL_CONFIG_CALIB_EXT_TF_WIDGET_H
#define TUM_ICS_SKIN_FULL_CONFIG_CALIB_EXT_TF_WIDGET_H

#include <QWidget>
#include <QStatusBar>
#include <QComboBox>
#include <QPushButton>

//This definition is needed with libboost 1.58
#ifndef Q_MOC_RUN
#include <SkinCore/Config/Config.h>
#include <tum_ics_skin_descr/Patch/Extrinsics.h>
#include <tum_ics_skin_descr/Patch/TfMarkerDataPatch.h>

#include <tum_ics_tfs/TfContainer.h>
#include <tum_ics_tfs/InteractiveTf.h>
#endif


namespace tum_ics_skin_full_config
{

namespace Ui {
class CalibExtTfWidget;
}

class CalibExtTfWidget : public QWidget
{
    Q_OBJECT

private:
    typedef ::Skin::Config SkinConfig;
    typedef tum_ics_skin_descr::Patch::Extrinsics PatchExtrinsics;
    typedef tum_ics_skin_descr::Patch::TfMarkerDataPatch TfMarkerDataPatch;
    typedef tum_ics_tfs::TfContainer TfContainer;
    typedef tum_ics_tfs::InteractiveTf InteractiveTf;

    enum State
    {
        UndefinedPatch,
        SelectBaseFrame,
        ITfStart,
        ITfRunning,
        ITfStop,
    };

    Ui::CalibExtTfWidget *ui;
    QStatusBar* m_sb;

    QComboBox* m_cbBaseFrame;
    QPushButton* m_pbExtTf;
    QPushButton* m_pbSave;
    QPushButton* m_pbLoadExtTf;

    QVector<QString> m_baseFrames;

    // current input patch
    Skin::Patch m_patch;
    QString m_prefix;
    tum_ics_skin_descr::Patch::Extrinsics m_patchExtrinsics;

    TfMarkerDataPatch m_tfPatch;
    TfContainer m_tfc_itf_base;
    InteractiveTf* m_itf;

    QString m_itfName;

    State m_state;
    QString m_defaultPath;

public:
    explicit CalibExtTfWidget(QWidget *parent = 0);
    ~CalibExtTfWidget();

    bool init(QStatusBar* sb, const QString& defaultPath = ".");
    void setDefaultPath(const QString& path = ".");

    // call this function in the main while loop
    void update();


private:
    void updateGui();

    void status(const QString& msg);
    void warning(const QString& msg);
    void error(const QString& msg);

    QString baseFrame() const;

public slots:
    void newSkinPatch(::Skin::Patch patch,
                      QString prefix,
                      tum_ics_skin_descr::Patch::Extrinsics pe);

private slots:
    void cbBaseFrame_currentIndexChanged(int index);

    void pbExtTfClicked();
    void pbLoadExtTfClicked();
    void pbSaveClicked();

signals:
    void newSkinPatchWithExtTf(::Skin::Patch patch,
                               QString prefix,
                               tum_ics_skin_descr::Patch::Extrinsics pe);

    // lock other GUIs
    void lockGui(bool enable);

private slots:

};

}

#endif // TUM_ICS_SKIN_FULL_CONFIG_CALIB_EXT_TF_WIDGET_H
