/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINEVENTS_PACKETSV2_EVENTS_ALLDATAPACKETV2_H
#define SKINEVENTS_PACKETSV2_EVENTS_ALLDATAPACKETV2_H

#include <SkinCore/Implementation/Packet.h>
#include <SkinCore/Cell/Data.h>

#include <SkinCore/Implementation/Packets/Version2/Data/SensorDataPacket.h>
#include <SkinCore/Implementation/Packets/Version2/Data/SensorData.h>
#include <SkinCore/Implementation/Packets/Version2/Data/RawSensorData.h>

namespace Skin{
namespace Implementation{
namespace Packets {
namespace Version2{
namespace Events{

using namespace Data;

class AllDataPacket : public SensorDataPacket
{
public:
    static bool check(const Packet& p);

public:
    AllDataPacket();
    AllDataPacket(const QVector<Endpoint>& dest);

    bool check() const;

private:
    void init();

};

}}}}}

#endif // SKINEVENTS_PACKETSV2_EVENTS_ALLDATAPACKETV2_H
