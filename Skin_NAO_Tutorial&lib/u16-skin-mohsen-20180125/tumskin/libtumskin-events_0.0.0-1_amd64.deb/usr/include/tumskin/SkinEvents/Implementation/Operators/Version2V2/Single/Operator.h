/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINEVENTS_OPERATORSV2V2_SINGLE_OPERATOR_H
#define SKINEVENTS_OPERATORSV2V2_SINGLE_OPERATOR_H

#include <QMap>

#include <SkinCore/Implementation/Operators/Version2/Base/Operator.h>

#include <SkinCore/Cell/Events/Event.h>
#include <SkinCore/Cell/Events/Events.h>

namespace Skin{
namespace Implementation{
namespace Operators{
namespace Version2V2{
namespace Single{
namespace Events{

class Operator : public Skin::Implementation::Operators::Version2::Base::Operator
{
    Q_OBJECT

public:

private:
    QVector<int> m_cellIds;

    QVector<Skin::Cell::Data> m_data;
    QMap<int,int> m_cellIdMap;

public:
    Operator(QObject* parent = 0,
             Interface* interface = 0);

    ~Operator();

private:
    using Skin::Implementation::Operators::Version2::Base::Operator::handleError;
    using Skin::Implementation::Operators::Version2::Base::Operator::errorToString;

public:

private:

public slots:

private slots:
    void handle_newNumberOfCells(int num);
    void parseInterfacePacket();

};


}}}}}}

#endif // SKINEVENTS_OPERATORSV2V2_SINGLE_OPERATOR_H
