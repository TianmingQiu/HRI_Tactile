/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINIMPLINTERFACE_H
#define SKINIMPLINTERFACE_H

#include "Packet.h"
#include "IntfNode.h"

#include <QString>
#include <QObject>


namespace Skin{
namespace Implementation{


class Interface : public QObject
{
    Q_OBJECT

public:
    enum InterfaceError
    {
        NoError = 0,
        InitError,
        DeInitError,
        NotInitializedError,
        WriteError,
        ReadError,
        TimeoutError,
        UnknownError,
    };

public:
    explicit Interface(QObject* parent = 0) : QObject(parent){}

    virtual ~Interface(){}

    virtual bool setNode(const IntfNode& node) = 0;
    virtual bool setNodes(const QVector<IntfNode>& nodes) = 0;

    virtual bool init() = 0;
    virtual bool deinit() = 0;

    virtual int type() const = 0;
    virtual QString name() const = 0;

    virtual bool isInitialized() const = 0;
    virtual bool hasPendingPackets() = 0;

    virtual bool enablePower(bool enable) = 0;

    virtual bool readPacket(Packet& p) = 0;
    virtual bool writePacket(const Packet& p) = 0;

    virtual bool flushRx() = 0;

    virtual qint64 getTime() = 0;

    virtual void clearError() = 0;
    virtual InterfaceError error() const = 0;
    virtual QString errorString() = 0;

public slots:


private:
    void handleError(InterfaceError error);


signals:
    void readyRead();
    void error(Skin::Implementation::Interface::InterfaceError error);


};


}
}



#endif // SKINIMPLINTERFACE_H
