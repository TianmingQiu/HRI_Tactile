#ifndef SKINADDITIONS_COLORFEEDBACK_H
#define SKINADDITIONS_COLORFEEDBACK_H


#include <QObject>

#include <SkinManagers/Application/Base/Application.h>
#include <SkinCore/Implementation/Packets/Version2/Commands/ColorFeedbackPacket.h>

namespace Skin {
namespace Additions{

using namespace Skin::Cell;
using namespace Skin::Managers;

class ColorFeedback : public QObject
{
    Q_OBJECT

public:
    typedef Skin::Implementation::Packets::Version2::Commands::ColorFeedbackPacket::Settings Settings;

private:

public:


private:
    typedef bool (ColorFeedback::*cmd_handler_func)(const QString& s);
    QVector<cmd_handler_func> m_cmdHandlers;
    QString             m_consoleCmdDescription;

    Skin::Managers::Application::Base::Application* m_app;

public:
    explicit ColorFeedback(Skin::Managers::Application::Base::Application* app,
                        QObject *parent = 0);

    const QString& consoleCmdDescription() const;
    bool handleConsoleCmd(QString);

private:
    bool handleColorFeedbackCommands(const QString& s);

private slots:

public slots:
    void enableColorFeedback(bool enable);

    void setSettings(LedColor::ColorCode idleColor,
                     LedColor::ColorCode proxColor,
                     LedColor::ColorCode forceColor,
                     int delayCnts,                 // 1 cnt = 1 ms, 7 bits
                     double proxThresh,             // 0 ... 1
                     double forceThresh,            // 0 ... 1
                     int id = Skin::Implementation::Packets::Version2::ID_ALL
                     );

    void setSettings(LedColor::ColorCode idleColor  = LedColor::CodeGreen,
                     LedColor::ColorCode proxColor  = LedColor::CodeRed,
                     LedColor::ColorCode forceColor = LedColor::CodeBlue,
                     int delayCnts                  = 100,      // 1 cnt = 1 ms, 7 bits
                     int proxThresh                 = 10000,    // 16 bit, raw
                     int forceThresh                = 100,       // 10 bit, raw
                     int id                         = Skin::Implementation::Packets::Version2::ID_ALL
                     );

    void setSettings(Settings s, int id = Skin::Implementation::Packets::Version2::ID_ALL);

signals:


};

}}




#endif // SKINADDITIONS_COLORFEEDBACK_H
