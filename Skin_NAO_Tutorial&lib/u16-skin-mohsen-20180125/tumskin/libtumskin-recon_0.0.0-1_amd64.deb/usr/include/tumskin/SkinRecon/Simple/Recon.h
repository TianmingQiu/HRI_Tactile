/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINRECON_SIMPLE_RECON_H
#define SKINRECON_SIMPLE_RECON_H

#include <QVector>
#include <QMap>
#include <QElapsedTimer>

#include <Eigen/Eigen>

#include <SkinCore/Config/Config.h>
#include <SkinCore/Config/SegmentMap.h>
#include <SkinRecon/Simple/Data.h>

// because of moc bug in combination with boost in qt4
#ifndef Q_MOC_RUN
#include <SkinRecon/SkinGraph/Graph.h>
#endif


namespace Skin{
namespace Recon{
namespace Simple{

class Recon
{
public:
    static void registerMetaTypes();

private:
    static const QVector<Eigen::Vector3d> defaultPos;
    static const QVector<Eigen::Vector3d> defaultRollAxis;
    static const QVector<Eigen::Vector3d> defaultPitchAxis;
    static const QVector<Eigen::Vector3d> defaultYawAxis;

    static Eigen::Vector3d getRPY(const Eigen::Matrix3d& r);
    static Eigen::Matrix3d rotRPY(const Eigen::Vector3d& rpy);
    static QString convMatrix(const Eigen::MatrixXd& m);

private:
    QVector<Skin::Cell::Neighbors>      m_neigbors;
    QMap<int,int>                       m_segMap;       // map: cell id -> seg id
    Data                                m_samples;

    QVector<Skin::Cell::Organization>   m_cells;
    QMap<int,int>                       m_cellIdMap;    // map cell id -> cell ind

    Skin::Reconstruction::SkinGraph::Graph m_graph;
\
    Skin::Config                        m_config;

public:
    Recon();
    ~Recon();

    // triggers a new reconstrution
    //  returns Undefined config on error (which is empty)
    const Skin::Config& recon(const Skin::Recon::Simple::Data& d,
                              const QVector<Skin::Cell::Neighbors>& n,
                              const Skin::SegmentMap& segMap = Skin::SegmentMap());

    const Skin::Config& config() const;

private:
    // uses neighbor list to init cells and create cellIdMap
    void initCellList();

    // creates skin cell graph
    //  -> uses cells vector (id and neighbor info)
    //  -> adds vertices to graph
    //  -> adds edges to graph
    //  -> saves graphviz file
    void initGraph();

    // finds skin patches
    //  -> uses skin graph to find patches
    //  -> asigns patch ids to cells
    void findPatches();

    // calculates rotations between cells
    //  -> goes through all edges in skin graph
    //  -> calculates the rotation using the recon data
    //  -> asigns a rotation and a weight to each edge
    void calcRotationMatrices();

    // finds the root cell for each patch
    // -> uses the skin graph to find root cells
    // -> uses the skin graph property
    // -> asignes root cell to cells
    void findPatchRootCells();

    // sets the standard pose to the root cells
    void setRootCellPoses();

    // updates all the cell poses with respect to root cell pose
    // -> uses the skin graph to find the shortest paths
    // -> sets the poses to the cells
    void updatePatchCellPoses();
};



}}}



#endif // SKINRECON_RECON_H
