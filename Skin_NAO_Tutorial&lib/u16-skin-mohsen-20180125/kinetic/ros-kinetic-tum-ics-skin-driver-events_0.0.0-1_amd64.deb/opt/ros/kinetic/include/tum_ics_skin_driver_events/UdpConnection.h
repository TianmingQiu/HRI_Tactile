#ifndef TUM_ICS_SKIN_DRIVER_EVENTS_UDP_CONNECTION_H
#define TUM_ICS_SKIN_DRIVER_EVENTS_UDP_CONNECTION_H

#include <qglobal.h>

#include <QObject>
#include <QScopedPointer>

#include <tum_ics_skin_driver_events/IpEndpoint.h>

namespace tum_ics_skin_driver_events{

class UdpConnectionPrivate;

/*!
 * \brief The Interface class for a standard single tsu interface.
 */
class UdpConnection :
    public QObject
{
protected:
    /*!
     * \brief The macro for simple access to the private class.
     */
    Q_DECLARE_PRIVATE(UdpConnection)

    const QScopedPointer<UdpConnectionPrivate> d_ptr;

    /*!
     * \brief Constructor for passing down the pointer of the private class (d_ptr).
     */
    UdpConnection(UdpConnectionPrivate& d, QObject* parent);

public:

public:
    /*!
     * \brief Default constructor.
     */
    UdpConnection(QObject* parent = 0);

    /*!
     * \brief Deconstructor.
     */
    ~UdpConnection();


    /*!
     * \brief Open connection.
     *
     * \param local is a valid ip endpoint on this PC. The ip address has to
     *      be available on through a local interface.
     *
     * \param client is a valid ip endpoint to which this program/PC is communicating.
     */
    bool open(const IpEndpoint& local,
              const IpEndpoint& client);

    /*!
     * \brief Close connection.
     */
    bool close();


    bool isOpened() const;
    bool isClosed() const;

    /*!
     * \brief Write one udp packet.
     */
    bool write(const QByteArray& data);
    bool write(const QByteArray& data, const IpEndpoint& client);

    /*!
     * \brief Read one udp packet.
     */
    bool read(QByteArray& data);
    bool read(QByteArray& data, IpEndpoint& client);


    /*!
     * \brief Checks if there are packets in the read buffer.
     */
    bool hasPendingPackets() const;

    /*!
     * \brief Flushes/empties the receive buffer.
     */
    bool flushReadBuffer();

private:
    /*!
     * \brief Not copyable.
     */
    UdpConnection(const UdpConnection& other);

    /*!
     * \brief Not assignable.
     */
    UdpConnection& operator=(const UdpConnection& other);

};

}

#endif // TUM_ICS_SKIN_DRIVER_EVENTS_
