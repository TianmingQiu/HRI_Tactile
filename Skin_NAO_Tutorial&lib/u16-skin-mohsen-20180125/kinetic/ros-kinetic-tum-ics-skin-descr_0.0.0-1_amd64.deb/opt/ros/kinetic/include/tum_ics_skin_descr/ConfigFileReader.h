#ifndef TUM_ICS_DESCR_CONFIGFILEREADER_H
#define TUM_ICS_DESCR_CONFIGFILEREADER_H

#include <SkinCore/Config/ConfigFileReader.h>
#include <tum_ics_skin_descr/Patch/Extrinsics.h>
#include <tum_ics_skin_descr/Patch/DriverSettings.h>

namespace tum_ics_skin_descr{

class ConfigFileReader : public ::Skin::ConfigFileReader
{

protected:
    QVector<Patch::Extrinsics> m_pe;
    QVector<Patch::DriverSettings> m_pds;

public:
    ConfigFileReader(const QString& filename);
    ~ConfigFileReader();

    const QVector<Patch::DriverSettings>& patchDriverSettings() const;
    const QVector<Patch::Extrinsics>& patchExtrinsics() const;

protected:
    void read(const QString& filename);

    Patch::DriverSettings readDriverSettings(bool* ok=0);

    Patch::Extrinsics readPatchExtrinsics(bool* ok=0);
    Eigen::Affine3d readTf(const QString& name, bool* ok=0);
};

}

#endif // TUM_ICS_DESCR_CONFIGFILEREADER_H
