#ifndef SKINEVENTS_MANAGERS_EVENTS_ACTIVEEVENTSCMDHANDLER_H
#define SKINEVENTS_MANAGERS_EVENTS_ACTIVEEVENTSCMDHANDLER_H

#include <QStringList>

#include <SkinManagers/Application/ConsoleCmdHandler.h>
#include <SkinEvents/Managers/Events/Manager.h>
#include <SkinCore/Cell/Events/Events.h>

namespace Skin {
namespace Managers{
namespace Events{

class ActiveEventsCmdHandler : public ConsoleCmdHandler
{
public:

private:
    static const QStringList EventStrList;
    static const QList<Skin::Cell::Events::Flags> EventFlagsList;

    Skin::Managers::Application::Base::Application* m_app;
    Skin::Managers::Events::Manager* m_mgr;

public:
    ActiveEventsCmdHandler(
            Skin::Managers::Application::Base::Application* app,
            Skin::Managers::Events::Manager* mgr);

    virtual bool handleMessage(const QString &s);
    virtual QString cmdDescription() const;
};


}}}

#endif // SKINEVENTS_MANAGERS_EVENTS_ACTIVEEVENTSCMDHANDLER_H
