#ifndef SKINEVENTS_EVALUATIONS_EVALUATION_H
#define SKINEVENTS_EVALUATIONS_EVALUATION_H

#include <QObject>
#include <QTimer>
#include <QMap>
#include <QMutex>

#include <Threads/Thread.h>

#include <SkinCore/Cell/Data.h>
#include <SkinCore/Implementation/Packet.h>
#include <SkinManagers/Application/Base/Application.h>

#include <SkinEvents/Evaluations/EvaluationData.h>


namespace Skin{
namespace Events{
namespace Evaluations{

class Evaluation : public QObject
{
    Q_OBJECT

private:
    Skin::Managers::Application::Base::Application* m_app;
    Threads::Thread m_thread;
    QMutex m_mutex;

    int m_numOfCells;

    EvaluationData m_data;
    EvaluationData m_prevData;

    QVector<int> m_cellIds;

    QMap<int,int> m_cellIdMap;      // map: cell id -> ind
    QMap<int,int> m_eventTypeIdMap; // map: event type -> data ind

    bool m_enabled;

public:
    explicit Evaluation(Skin::Managers::Application::Base::Application* app,
                        QObject *parent = 0);


    ~Evaluation();

    int indexOfCell(int cellId);
    int indexOfEvent(int eventTypeId);
    int indexOfEvent(const Skin::Events::Type& e);

    int dataPktCnt(int cellId);
    int eventPktCnt(int cellId);

    // eventTypeId == -1: all events of a cell
    int eventCnt(int cellId, int eventTypeId=-1);
    int eventCnt(int cellId, const Skin::Events::Type& e);

    int totalDataPktCnt();
    int totalEventPktCnt();
    int totalEventCnt();

    EvaluationData data();
    EvaluationData dData();

    QVector<int> cellIds();

    bool isCellIdMapComplete();

    void reset();

    void enable();
    void disable();

    bool isEnabled() const;

private:


private slots:
//    void newNumberOfCells(int);
    void newNeighborList(QVector<Skin::Cell::Neighbors>);

    void newDataBunch(QVector<Skin::Cell::Data>);
    void newEventDataPacketBunch(QVector<Skin::Implementation::Packet>);

public slots:

signals:

};


}}}


#endif // SKINEVENTS_EVALUATIONS_EVALUATION_H
