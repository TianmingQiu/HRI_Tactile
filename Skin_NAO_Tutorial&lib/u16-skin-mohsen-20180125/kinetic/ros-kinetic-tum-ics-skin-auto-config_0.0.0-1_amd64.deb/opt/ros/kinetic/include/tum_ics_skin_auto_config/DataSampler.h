#ifndef TUM_ICS_SKIN_AUTO_CONFIG_DATA_SAMPLER_H
#define TUM_ICS_SKIN_AUTO_CONFIG_DATA_SAMPLER_H

#include <ros/ros.h>
#include <tum_ics_skin_common/CallbackProvider.h>
#include <tum_ics_skin_bridge/Cell/DataConnection.h>

#include <SkinRecon/Simple/Sampler.h>

#include <QString>
#include <QVector>
#include <QMap>
#include <QMutex>

namespace tum_ics_skin_auto_config{

class DataSampler :
        private tum_ics_skin_bridge::Cell::DataConnection,     // to connect to the skin driver
        private ::Skin::Recon::Simple::Sampler, // to sample the data
        public tum_ics_skin_common::CallbackProvider<QVector< ::Skin::Cell::Data> >
{

public:
    typedef ::Skin::Cell::Data Data;

private:
    bool m_complete;
    QString m_topicName;

public:
    DataSampler(int poseTimeout = -1);
    ~DataSampler();

    // std topic name is: 'dataSampler'

    // delete samples and start sampling of first pose with timeout
    bool start(
            const QString& topicName,
            int numOfCells,
            int numOfPoses=1,
            int samplesPerCell=16);

    bool start(
            int numOfCells,
            int numOfPoses=1,
            int samplesPerCell=16);

    bool restart();


    // === lets use some stuff from the Sampler class ===
    using Sampler::nextPose;

    // get the current pose
    using Sampler::currentPose;
    using Sampler::currentPoseInd;

    // timeout error
    //  -> getting samples for current pose timed out
    using Sampler::timeoutError;

    // pose complete
    using Sampler::poseComplete;

    // all samples complete
    using Sampler::complete;

    using Sampler::samples;

private:
    // data array callback of DataConnection
    virtual void callback(const QVector<Data> &);

private:

};

}

#endif // TUM_ICS_SKIN_AUTO_CONFIG_DATA_SAMPLER_H
