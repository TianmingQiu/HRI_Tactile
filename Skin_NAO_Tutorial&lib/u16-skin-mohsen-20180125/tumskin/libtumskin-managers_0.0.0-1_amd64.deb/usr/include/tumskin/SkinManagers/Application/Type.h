#ifndef SKINMANAGERS_APPLICATION_TYPE_H
#define SKINMANAGERS_APPLICATION_TYPE_H

#include <QMetaType>

namespace Skin {
namespace Managers{
namespace Application{


class Type
{
private:
    int m_type;

public:
    Type(int type = -1);
    Type(const Type& t);

    bool operator== (const Type& other) const;
    bool operator!= (const Type& other) const;

    // QMap
    bool operator< (const Type& other) const;

    operator const int&() const;
};


}}}

Q_DECLARE_METATYPE(Skin::Managers::Application::Type)

#endif // SKINMANAGERS_APPLICATION_TYPE_H
