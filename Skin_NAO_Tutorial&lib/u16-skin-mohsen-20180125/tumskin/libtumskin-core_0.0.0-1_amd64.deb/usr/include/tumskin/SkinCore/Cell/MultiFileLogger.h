/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINCELL_MULTIFILELOGGER_H
#define SKINCELL_MULTIFILELOGGER_H

#include <QObject>
#include <QFile>
#include <QTextStream>

namespace Skin{
namespace Cell{

class MultiFileLogger
{

private:
    QString m_name;
    QString m_path;

    unsigned int m_num;
    QList<QFile*> m_fileList;
    QList<QTextStream*> m_outList;

    bool m_opened;

public:
    MultiFileLogger(const QString& path, const QString& name);

    void open(int numberOfFiles);
    void close();
    void clear();

    int numberOfFiles();

    QFile* file(int fileIndex);
    QTextStream* out(int fileIndex);


};


}}

#endif // SKINCELL_MULTIFILELOGGER_H
