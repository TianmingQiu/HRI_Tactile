/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINIMPLPKTS_PACKETSV2_H
#define SKINIMPLPKTS_PACKETSV2_H

#include <SkinCore/Implementation/Packets/Version2/PacketDefinitions.h>
#include <SkinCore/Implementation/Packet.h>

#include <SkinCore/Implementation/Packets/Version2/Bootloader/ConnectPacket.h>
#include <SkinCore/Implementation/Packets/Version2/Bootloader/JumpToApplicationPacket.h>
#include <SkinCore/Implementation/Packets/Version2/Bootloader/StartWritePacket.h>
#include <SkinCore/Implementation/Packets/Version2/Bootloader/EndWritePacket.h>
#include <SkinCore/Implementation/Packets/Version2/Bootloader/WriteDataPacket.h>
#include <SkinCore/Implementation/Packets/Version2/Bootloader/NewStartWritePacket.h>

#include <SkinCore/Implementation/Packets/Version2/ActivePortCalibration/SyncTokenPacket.h>
#include <SkinCore/Implementation/Packets/Version2/ActivePortCalibration/QueryPacket.h>
#include <SkinCore/Implementation/Packets/Version2/ActivePortCalibration/ReplyPacket.h>

#include <SkinCore/Implementation/Packets/Version2/MasterPortCalibration/MasterPortPacket.h>

#include <SkinCore/Implementation/Packets/Version2/IdDistribution/IdPacket.h>
#include <SkinCore/Implementation/Packets/Version2/IdDistribution/ConfirmationPacket.h>
#include <SkinCore/Implementation/Packets/Version2/IdDistribution/AccomplishedPacket.h>

#include <SkinCore/Implementation/Packets/Version2/NearestNeighborExploration/MyIdPacket.h>
#include <SkinCore/Implementation/Packets/Version2/NearestNeighborExploration/NearestNeighborListPacket.h>

#include <SkinCore/Implementation/Packets/Version2/Commands/LedColorPacket.h>
#include <SkinCore/Implementation/Packets/Version2/Commands/LedPwmColorPacket.h>
#include <SkinCore/Implementation/Packets/Version2/Commands/MemIdPacket.h>
#include <SkinCore/Implementation/Packets/Version2/Commands/MemOffsetPacket.h>
#include <SkinCore/Implementation/Packets/Version2/Commands/PingPacket.h>
#include <SkinCore/Implementation/Packets/Version2/Commands/ChangeUpdateRatePacket.h>
#include <SkinCore/Implementation/Packets/Version2/Commands/ColorFeedbackPacket.h>

#include <SkinCore/Implementation/Packets/Version2/Data/SensorDataPacket.h>

#include <SkinCore/Implementation/Packets/Version2/Clock/ResetPacket.h>
#include <SkinCore/Implementation/Packets/Version2/Clock/CommandPacket.h>
#include <SkinCore/Implementation/Packets/Version2/Clock/ClockValuePacket.h>

#include <SkinCore/Implementation/Packets/Version2/MasterPort/CommandPacket.h>
#include <SkinCore/Implementation/Packets/Version2/MasterPort/StorePacket.h>
#include <SkinCore/Implementation/Packets/Version2/MasterPort/ValuePacket.h>

#include <SkinCore/Implementation/Packets/Version2/Commands/GetNeighborListPacket.h>

#endif // SKINIMPLPKTS_PACKETSV2_H
