/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINIMPL_BOOTLOADERUPDATERS_STDUPDATER_H
#define SKINIMPL_BOOTLOADERUPDATERS_STDUPDATER_H

#include <SkinCore/Implementation/Programmer.h>
#include <SkinCore/Implementation/Interface.h>
#include <SkinCore/Implementation/Packets/Version2/Packets.h>
#include <SkinCore/Implementation/Packets/Version2/Bootloader/NewStartWritePacket.h>

#include <QVector>
#include <QTimer>

namespace Skin{
namespace Implementation{
namespace Updaters{
namespace Version2{

using namespace Skin::Implementation::Packets::Version2::Bootloader;

class StdUpdater : public Programmer
{
    Q_OBJECT

public:
    static const int waitResetOff               = 500*1000;      // us
    static const int waitBootloaderStartup      = 700*1000;
    static const int waitBootloaderNetConfig    = 100*1000;

//    static const int waitConnectAckVanishing    = 10*1000;
//    static const int waitStartDataWrite         = 100*1000;

//    static const int waitWriteData              = 100*1000;
//    static const int waitEndeDataWrite          = 100*1000;
//    static const int waitSyncTokenVanishing     = 10*1000;

//    static const int timeoutConnect             = 2000*1000;
//    static const int timeoutWriteAcknowledge    = 1000*1000;
//    static const int timeoutSyncToken           = 1000*1000;

private:
    Interface* m_intf;
    QString m_name;

    bool m_programming;

    ProgrammerError m_error;
    QString m_errorString;

public:
    StdUpdater(QObject* parent = 0);
    StdUpdater(Interface* interface, QObject* parent = 0);
    ~StdUpdater();

    bool setNode(const IntfNode& n);
    bool setNodes(const QVector<IntfNode>& nodes);

private:
    void init();

public:
    bool isProgramming() const;
    void setInterface(Interface* interface);
    void setName(const QString& name);

    const QString& name() const;

    void clearError();
    Programmer::ProgrammerError error() const;
    QString errorString();


public slots:
    void program(QVector<Skin::Implementation::DataBlock> blocks);



private:
    bool connectToBootloader();
    bool launchUpdater();

    void enablePower(bool enable);

    void handleError(ProgrammerError error);
    void handleError(ProgrammerError error, const QString& details);
    QString errorToString(ProgrammerError error);


private slots:
    void handleInterfaceError(Skin::Implementation::Interface::InterfaceError error);
    void handleProgrammerError(Skin::Implementation::Programmer::ProgrammerError error);

};


}
}
}
}

#endif // SKINIMPL_BOOTLOADERUPDATERS_STDUPDATER_H
