/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINIMPL_PROGRAMMER_H
#define SKINIMPL_PROGRAMMER_H

#include <QVector>
#include <QObject>

#include "DataBlock.h"
#include <SkinCore/Implementation/IntfNode.h>

namespace Skin{
namespace Implementation{

class Programmer : public QObject
{
    Q_OBJECT

public:
    enum ProgrammerError
    {
        NoError = 0,
        ConnectError,
        InterfaceError,
        TimeoutError,
        ProgrammingError,
        UnknownError,
    };

public:
    explicit Programmer(QObject* parent = 0) : QObject(parent){}
    virtual ~Programmer(){}

    virtual bool setNode(const IntfNode& n) = 0;
    virtual bool setNodes(const QVector<IntfNode>& nodes) = 0;

    virtual const QString& name() const = 0;

    virtual bool isProgramming() const = 0;

    virtual void clearError() = 0;
    virtual Programmer::ProgrammerError error() const = 0;
    virtual QString errorString() = 0;

public slots:
    virtual void program(QVector<DataBlock> blocks) = 0;

signals:
    void programFailed(void);
    void programmed(void);
    void progress(double p); // in percent

    void error(Skin::Implementation::Programmer::ProgrammerError error);

};


}
}


#endif // SKINIMPL_PROGRAMMER_H
