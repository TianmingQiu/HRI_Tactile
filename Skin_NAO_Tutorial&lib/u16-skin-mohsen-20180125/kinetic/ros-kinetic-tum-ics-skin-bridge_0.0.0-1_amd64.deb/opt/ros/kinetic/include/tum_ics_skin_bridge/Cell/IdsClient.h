#ifndef TUM_ICS_SKIN_CELL_IDSCLIENT_H
#define TUM_ICS_SKIN_CELL_IDSCLIENT_H

#include <ros/ros.h>

#include <QString>
#include <QVector>

namespace tum_ics_skin_bridge{
namespace Cell{

class IdsClient
{
public:

private:
    ros::NodeHandle                 m_node;
    QString m_srvName;

//    ros::ServiceClient              m_getIdsClient;

public:
    // empty means default
    IdsClient(const QString& srvName = "getSkinCellIds");
    ~IdsClient();

    void setServiceName(const QString& srvName = "getSkinCellIds");

    // broadcast id is rejected
    QVector<int> getIds(bool* ok=0);
};

}}

#endif // TUM_ICS_SKIN_CELL_IDSCLIENT_H
