#ifndef TUM_ICS_SKIN_TESTS_TOOLS_H
#define TUM_ICS_SKIN_TESTS_TOOLS_H

#include <QString>
#include <QVector>

namespace tum_ics_skin_full_config{


class Tools
{
public:
    static QVector<QString> getPublishers();
    static QVector<QString> getSubscribers();
    static QVector<QString> getServices();

    static QVector<QString> getRobotJoints();

private:
    static QVector<QString> getSystemStateNameList(int ind);

private:
    Tools();

};

}

#endif // TUM_ICS_SKIN_TESTS_TOOLS_H
