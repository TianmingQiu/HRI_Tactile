#ifndef SKININTFDNODE_DNODECOMPLETEPORTV2V0_H
#define SKININTFDNODE_DNODECOMPLETEPORTV2V0_H

#include <QElapsedTimer>
#include <QTimer>
#include <QMutex>
#include <QQueue>
#include <QUdpSocket>
#include <QMutex>
#include <QHostAddress>
#include <SkinCore/Implementation/Interface.h>

namespace Skin{
namespace Implementation{
namespace Interfaces{
namespace Version2V0{
namespace DNode{
namespace Complete{

class Port : public QObject
{
    Q_OBJECT

public :
static const quint8 DATA_MESS_TYPE_ID;
static const quint8 CTRL_MESS_TYPE_ID;
static const quint8 NET_INIT_CTRL_ID;
static const quint8 CHAIN_NET_INIT_CTRL_ID;
static const quint8 NET_STATUS_REQ_CTRL_ID;
static const quint8 CHAIN_NET_STATUS_REQ_CTRL_ID;
static const quint8 NET_STATUS_RESP_CTRL_ID;
static const quint8 POWER_CTRL_ID;
static const quint8 CHAIN_POWER_CTRL_ID;
static const QByteArray START_MAC_ADDRESS;
static const QByteArray MAC_BROADCAST;
static const int WRITE_INTERVAL;
static const int NODE_ID_INDEX ;
static const int MESS_TYPE_INDEX;
static const int MESS_SIZE_INDEX;
static const int MESS_HEAD_SIZE;
static const int CELL_DATA_PORT_INDEX;
static const int CELL_DATA_SIZE_INDEX;
static const int CELL_DATA_HEAD_SIZE;
static const int NODE_INIT_TIMEOUT;

static const int DEFAULT_PC_UDP_PORT;
static const int DEFAULT_MASTER_UDP_PORT;
static const QHostAddress DEFAULT_PC_IP;
static const QHostAddress DEFAULT_MASTER_IP;

private:
    bool m_initialized;
    QUdpSocket* m_udp_socket;
    quint16 m_pc_udp_port;
    quint16 m_master_udp_port;
    QHostAddress m_master_ip;
    QVector<Endpoint> m_v_node_endpoint;
    QVector<QByteArray> m_v_node_mac;
    QMutex m_error_mutex;
    Interface::InterfaceError m_error;
    QString m_errorString;
    QQueue<Packet> m_rx_queue;
    QQueue<Packet> m_tx_queue;
    QMutex m_rx_queue_mutex;
    QMutex m_tx_queue_mutex;
    QElapsedTimer m_tsTimer;


public:
    explicit Port(QObject *parent = 0);
    ~Port();

    void clearError();
    bool enablePower(bool enable);
    bool flushRx();
    bool isInitialized();
    bool hasPendingPackets();
    bool readPacket(Packet& p);
    bool writePacket(const Packet& p);
    Interface::InterfaceError error();
    QString errorString();
    qint64 getTime();


private:
    QString errorToString(Interface::InterfaceError error);
    void handleError(Interface::InterfaceError error);
    void handleError(Interface::InterfaceError error, const QString& details);

    bool initNetwork();
    bool init(QHostAddress pc_ip,quint16 pc_port,
              QHostAddress master_ip,quint16 master_port);
    bool rxDatagramParser(Packet& p);
    bool rxInitDatagramParser(Endpoint &endpoint, QByteArray &mac_src);
    bool txDatagramComposer(const Packet& p);
    bool initBranchNodes(QByteArray branch_mac,quint16 branch_id,
                         QVector<Endpoint>& branch_endpoints);
    bool initRootNodes(QVector<QByteArray>& vba_macs,QVector<Endpoint>& v_endpoints);
    bool writeData(QByteArray data,QHostAddress& addr,quint16& port);
    bool dataDatagramParser(Packet& p);
    bool readNetStatResp(QByteArray& mac_src,Endpoint& endpoint);

    bool sendPwEnPkt(Endpoint dest_endpoint,QByteArray dest_mac,
                     bool enable,bool chain);
    bool sendNetStatReqPkt(Endpoint dest_endpoint,QByteArray dest_mac,
                           bool chain);
    bool sendNetInitPkt(Endpoint dest_endpoint,QByteArray dest_mac,
                        QByteArray new_mac,quint8 new_id,bool chain);
    bool sendDataPkt(const Endpoint &dest_endpoint, const QByteArray &dest_mac,
                     const QByteArray &payload);

public slots:
    void txPacketHandler();
    void rxDatagramHandler();
    void initPort();
    void deinitPort();

signals:
    void readyRead(void);
    void readyWrite(void);
    void error(Skin::Implementation::Interface::InterfaceError error);

};

}}}}}}
#endif // SKININTFDNODE_DNODECOMPLETEPORTV2V0_H
