/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKIN_PATCH_H
#define SKIN_PATCH_H

#include <QVector>
#include <QMetaType>
#include <QMap>


#include <Eigen/Eigen>
#include <SkinCore/Cell/Neighbors.h>
#include <SkinCore/Cell/Organization.h>

namespace Skin{

class Patch
{
public:
    static const Patch Undefined; // undefined patch (std constructor)

    // if no patch id is specified, then load first patch in file
//    static Patch load(const QString& filePath, int patchId = 0);
    static bool save(const QString& filePath, const Patch& patch);

    // gets all the patches of the given vector of cells
    static QVector<Skin::Patch> getPatches(const QVector<Skin::Cell::Organization>& cells);

    // get cells of patchs
    static QVector<Skin::Cell::Organization> getCells(QVector<Skin::Patch> patches);

    // get number of cells of patches
    static int numberOfCells(const QVector<Skin::Patch>& patches);


    // check: check if segment id, patch id and root cell id match
    static bool check(const Skin::Patch& p, const Skin::Cell::Organization& c);

    // check if all cells are on the same patch
    static bool check(const QVector<Skin::Cell::Organization>& cells);

private:
    // NOTES:
    //  index is always consequtive and starts at 0
    //  id is unordered and starts at 1

    int m_segmentId;        // id of the segment to which this patch belongs to
    int m_patchId;          // id of this patch
    int m_rootId;           // id of root skin cell

    QMap<int,int> m_cellIdMap;  // map: cell id -> cell ind

    // topographical skin cell info
    QVector<Skin::Cell::Organization> m_cells;

public:
    Patch();    // is undefined
    Patch(const Patch& p);

    // if no patch id is specified, then load first patch in file
    Patch(const QString& filePath, int patchId = 0);

    Patch(int patchId, int rootCellId, int segmentId = 1);

    // uses the cell to init patch and appends cell to list
    Patch(const Skin::Cell::Organization& c);

    // takes first cell, init patch, add all cells which belong to patch
    Patch(const QVector<Skin::Cell::Organization>& cells);

    // gets all cells which have the given cell id
    //  -> is undefined if no cells have been found
    //  -> the first cell which matches the given id fully init the patch
    Patch(int patchId, const QVector<Skin::Cell::Organization>& cells);

    ~Patch();

    bool operator== (const Patch& other) const;
    bool operator!= (const Patch& other) const;

    // appends cell to patch
    //  - if the patch is undefined then the first cell
    //      initializes:
    //          the root cell id
    //          the patch id
    //          the segment id
    //  - if the cell doesn't fit to the patch then
    //      append fails and the cell is ignored
    //  - the append also fails if the cell is already in the list
    //  - append fails if cell is undefined
    bool appendCell(const Skin::Cell::Organization& c);

    bool changeRootCellPos(const Eigen::Vector3d& pos);
    bool changeRootCellRot(const Eigen::Matrix3d& rot);

    bool changeRootCell(int newRootCellId);

    bool changePatchId(int newPatchId);

    // cells
    void setCellPos(int cellInd, const Eigen::Vector3d& pos = Eigen::Vector3d::Zero());
    void setCellRot(int cellInd, const Eigen::Matrix3d& rot = Eigen::Matrix3d::Identity());
    void setCellPose(int cellInd,
                     const Eigen::Matrix3d& rot = Eigen::Matrix3d::Identity(),
                     const Eigen::Vector3d& pos = Eigen::Vector3d::Zero());

    void setCellPose(int cellInd,
                     const Eigen::Affine3d& tf = Eigen::Affine3d::Identity());


    bool check(const Skin::Cell::Organization& c) const;

    // get cell index of cell id
    //  returns -1 if not existent
    int index(int id) const;

    bool hasCell(int id) const;
    bool isUndefined() const;

    // returns reference to Undefined cell if not existent
    const Skin::Cell::Organization& cell(int id) const;

    int numberOfCells() const;

    int id() const; // patch id
    int segmentId() const;
    int rootCellId() const;

    const QVector<Skin::Cell::Organization>& cells() const;

    QVector<int> cellIds() const;
    QVector<int> orderedCellIds() const;

    bool load(const QString& filePath);
    bool load(const QString& filePath,int patchId);

    bool save(const QString& filePath = "patch.xml") const;

    bool loadDialog(const QString& path = QString(), int patchId = 0);
    bool saveDialog(const QString& path = QString());

    QString briefInfo() const;
};

}

Q_DECLARE_METATYPE(Skin::Patch)
Q_DECLARE_METATYPE(QVector<Skin::Patch>)

#endif // SKIN_PATCH_H
