/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINCORE_CELL_EVENTS_EVENT_H
#define SKINCORE_CELL_EVENTS_EVENT_H

#include <QVector>
#include <QMetaType>
#include <QTextStream>

#include <SkinCore/Events/EventBase.h>
#include <SkinCore/Events/Type.h>

namespace Skin{
namespace Cell{
namespace Events{

class Event : public Skin::Events::EventBase
{
public:

private:
    int m_cellId;               // cell id
    int m_patchId;              // patch id

public:
    // undefined event
    Event(const Skin::Events::Type& t = Skin::Events::Type(),
          int patchId = 0,
          int cellId = 0,
          double val = 0.0,
          qint64 ts = -1);

    Event(const Skin::Events::Type& t,
          int cellId,
          double val = 0.0,
          qint64 ts= -1);

    Event(const EventBase& e, int patchId, int cellId = 0);
    Event(const EventBase& e, int cellId);

    Event(const Event& e);
    ~Event();

    void setPatchId(int patchId);
    void setCellId(int cellId);

    // only check cell id and type id
    bool operator== (const Event& other) const;
    bool operator!= (const Event& other) const;

    // for QMap
    bool operator< (const Event& other) const;

    int cellId() const;
    int patchId() const;

    QString toString() const;

private:


};

}}}

QTextStream& operator << (QTextStream& s, const Skin::Cell::Events::Event& e);
QTextStream& operator >> (QTextStream& s, Skin::Cell::Events::Event& e);

Q_DECLARE_METATYPE(Skin::Cell::Events::Event)
Q_DECLARE_METATYPE(QVector<Skin::Cell::Events::Event>)

#endif // SKINCORE_CELL_EVENTS_EVENT_H
