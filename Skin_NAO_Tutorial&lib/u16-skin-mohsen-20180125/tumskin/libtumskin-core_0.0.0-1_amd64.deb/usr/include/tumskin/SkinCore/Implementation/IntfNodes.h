/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINIMPL_INTFNODES_H
#define SKINIMPL_INTFNODES_H

#include <QMetaType>
#include <QVector>

#include <SkinCore/Implementation/IntfNode.h>

namespace Skin{
namespace Implementation{

class IntfNodes : public QVector<IntfNode>
{
public:
    IntfNodes(const QVector<TsuNode>& nodes);
    IntfNodes(const QVector<FtdiNode>& nodes);

};


}
}


#endif // SKINIMPL_INTFNODES_H
