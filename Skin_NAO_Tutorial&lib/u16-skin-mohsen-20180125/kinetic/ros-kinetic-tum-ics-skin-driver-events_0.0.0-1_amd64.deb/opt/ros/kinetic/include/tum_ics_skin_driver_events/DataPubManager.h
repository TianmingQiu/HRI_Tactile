#ifndef TUM_ICS_SKIN_DRIVER_EVENTS_DATA_PUB_MANAGER_H
#define TUM_ICS_SKIN_DRIVER_EVENTS_DATA_PUB_MANAGER_H

#include <QVector>
#include <QMap>
#include <QMutex>

//This definition is needed with libboost 1.58
#ifndef Q_MOC_RUN
#include <ros/ros.h>
#include <tum_ics_skin_msgs_events/createSkinCellDataPub.h>
#include <tum_ics_skin_msgs_events/enableSkinCellDataPub.h>

#include <tum_ics_skin_driver_events/DataPublisher.h>
#endif

namespace tum_ics_skin_driver_events{

class DataPubManager
{
private:
    ros::NodeHandle m_node;
    ros::ServiceServer              m_createSkinCellDataPubSrv;
    ros::ServiceServer              m_enableSkinCellDataPubSrv;

    QVector<int> m_ids;             // ids of all available cells
    bool m_initialized;

    QVector<DataPublisher*>         m_dataPubs;
    QMap<QString,int>               m_dataPubMap;   // map: str -> pub

    QMutex                          m_dataPubsMutex;

public:
    DataPubManager();
    ~DataPubManager();

    void init(const QVector<int>& ids);

    // publish data
    void publish(const QVector<Skin::Cell::Data>& data);

private:
    bool createSkinCellDataPubCallback(
            tum_ics_skin_msgs_events::createSkinCellDataPub::Request &req,
            tum_ics_skin_msgs_events::createSkinCellDataPub::Response &res);

    bool enableSkinCellDataPubCallback(
            tum_ics_skin_msgs_events::enableSkinCellDataPub::Request &req,
            tum_ics_skin_msgs_events::enableSkinCellDataPub::Response &res);


};

}


#endif // TUM_ICS_SKIN_DRIVER_EVENTS_DATA_PUB_MANAGER_H
