#ifndef SKININTFDNODE_DNODESIMPLEINTFV2V0_H
#define SKININTFDNODE_DNODESIMPLEINTFV2V0_H

#include <QUdpSocket>
#include <QHostAddress>
#include <QTimer>
#include <QByteArray>
#include <QQueue>
#include <QMutex>
#include <QVector>
#include <QElapsedTimer>

#include <SkinCore/Implementation/Interface.h>

// NOTE: this has not been updated since 18.11.2015
//  and contains unfixed bugs (packet size, port mask, etc.)

namespace Skin{
namespace Implementation{
namespace Interfaces{
namespace Version2V0{
namespace DNode{
namespace Simple{


class Interface : public Skin::Implementation::Interface
{
    Q_OBJECT

public:
    explicit Interface(QObject* parent = 0);
    ~Interface();
    //Interface Attribute
    static const int TYPE;
    static const QString NAME;
    //Master Node Default Configuration
    static const int DEFAULT_PC_UDP_PORT;
    static const int DEFAULT_MASTER_UDP_PORT;
    static const int NODE_INIT_TIMEOUT;
    static const QHostAddress DEFAULT_PC_IP;
    static const QHostAddress DEFAULT_MASTER_IP;
    static const quint8 DATA_MESS_TYPE_ID;
    static const quint8 CTRL_MESS_TYPE_ID;
    static const quint8 NET_INIT_CTRL_ID;
    static const quint8 CHAIN_NET_INIT_CTRL_ID;
    static const quint8 NET_STATUS_REQ_CTRL_ID;
    static const quint8 CHAIN_NET_STATUS_REQ_CTRL_ID;
    static const quint8 NET_STATUS_RESP_CTRL_ID;
    static const quint8 POWER_CTRL_ID;
    static const quint8 CHAIN_POWER_CTRL_ID;
    static const QByteArray NODE_ID_MASK;
    static const QByteArray MAC_BROADCAST;
    static const QByteArray NODE_MAC_INIT;
    static const QByteArray NODE_ID_INIT;
    static const QByteArray PORT_MASK;

    static const int NODE_ID_INDEX;
    static const int MESS_TYPE_INDEX;
    static const int MESS_SIZE_INDEX;
    static const int MESS_HEAD_SIZE;


    static const int CELL_DATA_PORT_INDEX;
    static const int CELL_DATA_SIZE_INDEX;
    static const int CELL_DATA_HEAD_SIZE;
    static const int PORT_ID_SIZE;


    typedef struct cust_eth_header{
        quint8 node_id;
        quint8 mess_type;
        quint16 mess_size;
    } cust_header_t;

    typedef struct cell_data_header{
        quint8 data_size;
        quint16 port_mask;
    } cell_data_header_t;


private :
    bool m_initialized;
    QUdpSocket* m_udp_socket;
    QVector<Endpoint> m_node_endpoints;
    QVector<QByteArray> m_node_macs;
    QQueue<Packet> m_rx_queue;
    QMutex m_rx_queue_mutex;
    InterfaceError  m_error;
    QString         m_errorString;
    quint16 m_pc_udp_port;
    quint16 m_master_udp_port;
    QHostAddress m_master_ip;

    QTimer* m_timer;

    QElapsedTimer   m_tsTimer;

public :

    bool setNode(const IntfNode& node);
    bool setNodes(const QVector<IntfNode>& nodes);

    bool init();
    bool init(QHostAddress pc_ip,
              quint16 pc_port,
              QHostAddress master_ip,
              quint16 master_port
              );
    bool deinit();
    int type() const;
    bool isInitialized() const;
    bool hasPendingPackets();
    bool enablePower(bool enable);
    bool readPacket(Packet& p);
    bool readPacket(Packet& p,QByteArray src_mac);
    bool writePacket(const Packet& p);
    QVector<Endpoint> getEndpoints();
    bool flushRx();
    QString errorToString(InterfaceError error);
    QString name() const;
    qint64 getTime();
    void clearError();
    InterfaceError error() const;
    QString errorString();

private:
    bool initNetwork();
    bool writeData(QByteArray data, QHostAddress& addr, quint16& port);
    bool txDatagramComposer(const Packet& p);
    bool rxDatagramParser(Packet& p);
    void handleError(InterfaceError error);
    void handleError(InterfaceError error, const QString& details);
    bool rxInitDatagramParser(Endpoint &endpoint, QByteArray &mac_src);

private slots:
    void test();

public slots :
        void rxDatagramHandler();
signals :
};

}}}}}}

#endif // SKININTFDNODE_DNODESIMPLEINTFV2V0_H
