#ifndef TUM_ICS_SKIN_CELL_DATA_CONNECTION_H
#define TUM_ICS_SKIN_CELL_DATA_CONNECTION_H

#include <tum_ics_skin_bridge/Cell/DataSubscriber.h>
#include <tum_ics_skin_bridge/Cell/DataPubsClient.h>

#include <QString>
#include <QVector>

namespace tum_ics_skin_bridge{
namespace Cell{

class DataConnection  :
        public Cell::DataSubscriber,     // to connect to the skin driver
        private Cell::DataPubsClient     // to create and manage the topic
{

private:
    bool m_shared;                       // when true: just connect to topic, topic is
                                         //  already published

public:
    // default cell id filter is all cell ids of subscribed topic
    // takes the namespace prefix of the topic for calling services
    DataConnection(const QString& topicName = "", int patchId=0);
    ~DataConnection();

    // -> if data pub is not shared then data pub is created,
    //      otherwise only subscribe topic
    // -> fails if already enabled
    bool create(const QString& topicName,
                int patchId,
                const QVector<int>& ids = QVector<int>(),
                bool shared = false);

    bool create(const QString& topicName,
                const QVector<int>& ids = QVector<int>(),
                bool shared = false);

    bool create(const QString& topicName,
                bool shared);

    bool create(const QVector<int>& ids = QVector<int>(),
                bool shared = false);


    // does't enable/disable data publisher if it only subscribes
    // returns false if service call to driver failes
    bool enable();
    bool disable();

    bool setEnabled(bool enable);

private:

};


}}

#endif // TUM_ICS_SKIN_CELL_DATA_CONNECTION_H
