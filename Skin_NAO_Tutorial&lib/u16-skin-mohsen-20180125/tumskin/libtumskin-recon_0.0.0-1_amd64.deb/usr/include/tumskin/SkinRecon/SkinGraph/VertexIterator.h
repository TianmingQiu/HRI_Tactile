/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINRECON_SKINGRAPH_VERTEXITERATOR_H
#define SKINRECON_SKINGRAPH_VERTEXITERATOR_H

#include <SkinRecon/SkinGraph/Graph.h>

namespace Skin{
namespace Reconstruction{
namespace SkinGraph{

class VertexIterator
{

private:
    Graph& m_g;

    boost::graph_traits<BGLGraph>::vertex_iterator m_vi, m_vi_start, m_vi_end;

public:
    // ATTENTION: don't change the graph as long as iteration is performed
    // start & end are only updated at creation or assignment
    VertexIterator(Graph& g);
    ~VertexIterator();

    void toFront();
    void toBack();

    bool hasNext() const;
    bool hasPrevious() const;

    VertexProperties& peekNext() const;
    VertexProperties& peekPrevious() const;

    VertexProperties& next();
    VertexProperties& previous();

    VertexProperties& value();
    const VertexProperties& value() const;

private:
    void init();

};


}
}
}



#endif // SKINRECON_SKINGRAPH_VERTEXITERATOR_H
