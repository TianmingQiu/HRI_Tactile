#ifndef SKINEVENTS_CONVERTERS_EVENT_UNPACKER_H
#define SKINEVENTS_CONVERTERS_EVENT_UNPACKER_H

#include <QObject>
#include <QTimer>
#include <QMap>

#include <Threads/Thread.h>

#include <SkinCore/Cell/Data.h>
#include <SkinCore/Implementation/Packet.h>
#include <SkinManagers/Application/Base/Application.h>

#include <SkinCore/Cell/Events/Event.h>
#include <SkinCore/Cell/Events/Events.h>

namespace Skin{
namespace Events{
namespace Converters{
namespace Event{


class Unpacker : public QObject
{
    Q_OBJECT

private:
    Skin::Managers::Application::Base::Application* m_app;
    Threads::Thread m_thread;
    QVector<Skin::Cell::Events::Event> m_eventsBuf;
    int m_eventsInd;

public:
    explicit Unpacker(Skin::Managers::Application::Base::Application* app,
                       QObject *parent = 0);

    ~Unpacker();

private:

private slots:
    void newEventDataPacketBunch(QVector<Skin::Implementation::Packet>);

public slots:

signals:
    void newEventBunch(QVector<Skin::Cell::Events::Event>);
};


}}}}


#endif // SKINEVENTS_CONVERTERS_EVENT_UNPACKER_H
