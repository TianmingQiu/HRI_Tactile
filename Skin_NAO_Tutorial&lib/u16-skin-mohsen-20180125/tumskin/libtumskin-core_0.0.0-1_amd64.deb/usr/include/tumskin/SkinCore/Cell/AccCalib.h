/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINCELLACCCALIB3D_H
#define SKINCELLACCCALIB3D_H

#include <QVector>
#include <QMetaType>

namespace Skin{
namespace Cell{

class AccCalib
{

private:
    QVector<double> m_gains;
    QVector<double> m_offsets;

public:
    AccCalib();
    ~AccCalib();
    AccCalib(const AccCalib& ac);
    AccCalib(const QVector<double>& gains, const QVector<double>& offsets);

    const QVector<double>& gains() const;
    const QVector<double>& offsets() const;



};


}
}

Q_DECLARE_METATYPE(Skin::Cell::AccCalib)
Q_DECLARE_METATYPE(QVector<Skin::Cell::AccCalib>)

#endif // SKINCELLACCCALIB3D_H
