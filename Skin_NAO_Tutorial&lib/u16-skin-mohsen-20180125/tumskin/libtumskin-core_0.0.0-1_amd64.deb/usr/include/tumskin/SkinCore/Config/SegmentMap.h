/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKIN_SEGMENTMAP_H
#define SKIN_SEGMENTMAP_H

#include <QVector>
#include <QMetaType>
#include <QMap>

namespace Skin{

class SegmentMap : public QMap<int,int>
{
private:

public:
    SegmentMap();
    SegmentMap(const QMap<int,int>& sm);
    SegmentMap(const SegmentMap& sm);

    ~SegmentMap();

};

}

Q_DECLARE_METATYPE(Skin::SegmentMap)


#endif // SKIN_SEGMENTMAP_H
