#ifndef SKINADDITIONS_DATALOGGER_H
#define SKINADDITIONS_DATALOGGER_H


#include <QObject>
#include <QTimer>
#include <QThread>
#include <QMutex>
#include <QFile>

#include <SkinCore/Cell/Neighbors.h>
#include <SkinManagers/Application/Base/Application.h>
#include <SkinCore/Implementation/Packets/Version2/PacketDefinitions.h>

namespace Skin {
namespace Additions{

class DataLogger : public QObject
{
    Q_OBJECT

public:

private:

public:

private:
    typedef bool (DataLogger::*cmd_handler_func)(const QString& s);
    QVector<cmd_handler_func> m_cmdHandlers;
    QString             m_consoleCmdDescription;

    Skin::Managers::Application::Base::Application* m_app;


    QVector<int>        m_cellIds;
    QVector<int>        m_usrCellIds;
    QMap<int,int>       m_cellIdMap;    // map: id -> ind;
    QVector<QFile*>     m_files;

    QString             m_path;

    bool                m_started;
    QVector<QThread*>   m_threads;
    QMutex              m_mutex;

public:
    explicit DataLogger(Skin::Managers::Application::Base::Application* app,
                        QObject *parent = 0);

    void setPath(const QString& path = "./cellDataLogs");

    const QString& consoleCmdDescription() const;
    bool handleConsoleCmd(QString);

private:
    bool handleDataLoggerCommands(const QString& s);

    bool open();
    void close();
    void clear();

    void write(const Skin::Cell::Data& d);

private slots:
    void newNeighborList(QVector<Skin::Cell::Neighbors>);
    void newDataBunch(QVector<Skin::Cell::Data> d);

public slots:
    void start(QVector<int> cellIds = QVector<int>());
    void stop();

signals:


};

}}




#endif // SKINADDITIONS_DATALOGGER_H
