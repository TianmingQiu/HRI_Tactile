/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINIMPLPKTS_NEARESTNEIGHBORLISTPACKETV2_H
#define SKINIMPLPKTS_NEARESTNEIGHBORLISTPACKETV2_H

#include <SkinCore/Implementation/Packet.h>
#include <SkinCore/Cell/Neighbors.h>

namespace Skin{
namespace Implementation{
namespace Packets {
namespace Version2{
namespace NearestNeighborExploration{

using namespace Skin::Cell;

class NearestNeighborListPacket : public Packet
{
public:
    static const int PKT_SIZE = 20;

    static bool check(const Packet& p);
    static Neighbors getNeighbors(const Packet& p);

private:
    static void setId(Packet& p, int index, int id);
    static int getId(const Packet& p, int index);

    static void setNeighbors(Packet& p, const Neighbors& n);

public:
    NearestNeighborListPacket();
    NearestNeighborListPacket(const QVector<Endpoint>& dest);

    Neighbors getNeighbors() const;

private:
    void init();

    void setId(int index, int id);
    int getId(int index) const;

    void setNeighbors(const Neighbors& n);

};

}}}}}

#endif // SKINIMPLPKTS_MYIDPACKETV2_H
