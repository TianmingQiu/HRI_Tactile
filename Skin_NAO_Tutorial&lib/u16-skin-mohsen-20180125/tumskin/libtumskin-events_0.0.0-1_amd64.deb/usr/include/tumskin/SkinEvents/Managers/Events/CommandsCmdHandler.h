#ifndef SKINEVENTS_MANAGERS_EVENTS_COMMANDSCMDHANDLER_H
#define SKINEVENTS_MANAGERS_EVENTS_COMMANDSCMDHANDLER_H

#include <QStringList>

#include <SkinManagers/Application/ConsoleCmdHandler.h>
#include <SkinEvents/Managers/Events/Manager.h>

namespace Skin {
namespace Managers{
namespace Events{

class CommandsCmdHandler : public ConsoleCmdHandler
{
public:

private:
    Skin::Managers::Application::Base::Application* m_app;
    Skin::Managers::Events::Manager* m_mgr;

public:
    CommandsCmdHandler(
            Skin::Managers::Application::Base::Application* app,
            Skin::Managers::Events::Manager* mgr);

    virtual bool handleMessage(const QString &s);
    virtual QString cmdDescription() const;
};


}}}

#endif // SKINEVENTS_MANAGERS_EVENTS_COMMANDSCMDHANDLER_H
