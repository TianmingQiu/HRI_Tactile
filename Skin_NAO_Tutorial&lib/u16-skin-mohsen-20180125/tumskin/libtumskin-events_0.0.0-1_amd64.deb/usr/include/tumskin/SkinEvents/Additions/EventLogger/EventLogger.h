#ifndef SKINEVENTS_ADDITONS_EVENTLOGGER_H
#define SKINEVENTS_ADDITONS_EVENTLOGGER_H


#include <QObject>
#include <QTimer>
#include <QThread>
#include <QMutex>
#include <QFile>

#include <SkinCore/Cell/Neighbors.h>
#include <SkinManagers/Application/Base/Application.h>
#include <SkinCore/Implementation/Packets/Version2/PacketDefinitions.h>

namespace Skin {
namespace Additions{

class EventLogger : public QObject
{
    Q_OBJECT

public:

private:

public:

private:
    typedef bool (EventLogger::*cmd_handler_func)(const QString& s);
    QVector<cmd_handler_func> m_cmdHandlers;
    QString             m_consoleCmdDescription;

    Skin::Managers::Application::Base::Application* m_app;


    QVector<int>        m_cellIds;
    QVector<int>        m_usrCellIds;
    QMap<int,int>       m_cellIdMap;    // map: id -> ind;
    QVector<QFile*>     m_files;

    QString             m_path;

    bool                m_started;
    QVector<QThread*>   m_threads;
    QMutex              m_mutex;

public:
    explicit EventLogger(Skin::Managers::Application::Base::Application* app,
                        QObject *parent = 0);

    void setPath(const QString& path = "./cellEventsLogs");

    const QString& consoleCmdDescription() const;
    bool handleConsoleCmd(QString);

private:
    bool handleEventLoggerCommands(const QString& s);

    bool open();
    void close();
    void clear();

private slots:
    void newNeighborList(QVector<Skin::Cell::Neighbors>);
    void newEventDataPacketBunch(QVector<Skin::Implementation::Packet>);

public slots:
    void start(QVector<int> cellIds = QVector<int>());
    void stop();

signals:


};

}}




#endif // SKINEVENTS_ADDITONS_EVENTLOGGER_H
