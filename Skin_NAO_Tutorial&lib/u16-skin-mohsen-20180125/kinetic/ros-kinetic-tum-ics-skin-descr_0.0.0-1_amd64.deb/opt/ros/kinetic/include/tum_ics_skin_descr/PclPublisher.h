#ifndef TUM_ICS_SKIN_DESCR_PCL_PUBLISHER_H
#define TUM_ICS_SKIN_DESCR_PCL_PUBLISHER_H

#include <QString>
#include <QVector>

#include <pcl_ros/point_cloud.h>
#include <pcl/point_types.h>


namespace tum_ics_skin_descr{

class PclPublisher
{
public:
    typedef pcl::PointCloud<pcl::PointXYZRGB> PointCloud;
    typedef PointCloud::Ptr PclMessage;

    static PclMessage createMsg(
            const QVector<pcl::PointXYZRGB>& pcl,
            const QString& baseFrame = "world",
            const ros::Time& t = ros::Time::now());

private:
    ros::NodeHandle m_node;
    ros::Publisher m_pub;

    QString m_topicName;

public:
    PclPublisher(const QString& topicName);
    ~PclPublisher();

    void publish(const PclMessage& msg);

    void publish(const QVector<pcl::PointXYZRGB>& pcl,
                 const QString& baseFrame = "world",
                 const ros::Time& t = ros::Time::now());

private:

};

}

#endif // TUM_ICS_SKIN_DESCR_PCL_PUBLISHER_H
