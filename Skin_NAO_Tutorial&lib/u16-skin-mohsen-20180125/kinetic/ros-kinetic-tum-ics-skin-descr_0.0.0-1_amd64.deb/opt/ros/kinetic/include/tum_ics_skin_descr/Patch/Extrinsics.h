#ifndef TUM_ICS_SKIN_DESCR_PATCH_EXTRINSICS_H
#define TUM_ICS_SKIN_DESCR_PATCH_EXTRINSICS_H

#include <Eigen/Eigen>
#include <QVector>
#include <QMetaType>
#include <QTextStream>

namespace tum_ics_skin_descr{
namespace Patch{

class Extrinsics
{
public:
    static Extrinsics Undefined();

    // default extrinisics
    // identity tfs
    // baseFrame = /world
    // dhFrame = world
    static Extrinsics Default();

private:
    int m_patchId;
    QString m_baseFrame;    // base frame for rviz tf
    QString m_dhFrame;      // base frame for dh tf

    /**  Transformation:
     *
     *      rootCell
     *                  T
     *                      base
     *
     *  -> tf: from base to rootCell:           base -> rootCell
     *  -> tf: rootCelll with respect to base:  rootCell wrt. base
    */
    Eigen::Affine3d m_tf_rootCell_base;


    /**  Transformation:
     *
     *      base
     *                  T
     *                      dh
     *
     *  -> tf: from base to dh:             dh -> base
     *  -> tf: dh with respect to base:     base wrt. dh
    */
    Eigen::Affine3d m_tf_base_dh;

    int m_jointId;                          // Joint id of the patch (dh link number)

public:
    Extrinsics(int patchId=-1,int jointId=-1,
                    const QString& baseFrame="",
                    const Eigen::Affine3d& tf_rootCell_base = Eigen::Affine3d::Identity(),
                    const QString& dhFrame="",
                    const Eigen::Affine3d& tf_base_dh = Eigen::Affine3d::Identity());

    Extrinsics(const Extrinsics& pe);
    ~Extrinsics();

    // comparisons only for id
    bool operator== (const Extrinsics& other) const;
    bool operator!= (const Extrinsics& other) const;

    bool operator< (const Extrinsics& other) const;


    void setPatchId(int patchId);
    void setBaseFrame(const QString& baseFrame);
    void setDHFrame(const QString& dhFrame);

    void set_tf_base_dh(const Eigen::Affine3d& h);
    void set_tf_rootCell_base(const Eigen::Affine3d& h);
    void setJointId(int jointId);


    // undefined if patch id == -1
    bool isUndefined() const;

    bool isDefault() const;

    int patchId() const;

    const QString& baseFrame() const;
    const QString& dhFrame() const;

    const Eigen::Affine3d& tf_rootCell_base() const;
    const Eigen::Affine3d& tf_base_dh() const;

    Eigen::Affine3d tf_rootCell_dh() const;
    Eigen::Affine3d tf_dh_base() const;


    int jointId() const;

    QString toString() const;


};

}}

Q_DECLARE_METATYPE(tum_ics_skin_descr::Patch::Extrinsics)
Q_DECLARE_METATYPE(QVector<tum_ics_skin_descr::Patch::Extrinsics>)

#endif // TUM_ICS_SKIN_DESCR_PATCH_EXTRINSICS_H
