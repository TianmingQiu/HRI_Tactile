#ifndef TUM_ICS_SKIN_CELL_DATA_H
#define TUM_ICS_SKIN_CELL_DATA_H

#include <ros/ros.h>
#include <tum_ics_skin_msgs/SkinCellData.h>

#include <SkinCore/Cell/Data.h>

#include <QString>
#include <QVector>

namespace tum_ics_skin_common{
namespace Cell{

/*! \brief A type class which contains the full set of sensor values for one skin cell
 *         which we call skin cell data.
 *
 * This class is derived from the type class ::Skin::Cell::Data, which is defined in
 * the low level library SkinCore and extends that class with wrapper functions for
 * the corresponding ROS message.
*/
class Data :
      public ::Skin::Cell::Data
{
private:
    typedef tum_ics_skin_msgs::SkinCellData DataMsg;

public:
    /*!
     * \brief Creates the new type class for a given Skin Cell Data ROS message
     * \param m The Skin Cell Data ROS message.
     * \return The new extended type class for skin cell data.
     */
    static Data fromMsg(const DataMsg& m);

    /*!
     * \brief Converts the low level type class to the Skin Cell Data ROS message
     * \param d the low level type class for skin cell data
     * \return Skin Cell Data ROS message
     */
    static DataMsg toMsg(const ::Skin::Cell::Data& d);


    /*!
     * \brief Updates the Skin Cell Data ROS message with the skin cell data of
     * the low level type class. Updates also Ids and timestamps.
     * \param d the low level type class for skin cell data
     * \return Skin Cell Data ROS message
     */
    static DataMsg& toMsg(DataMsg& m, const ::Skin::Cell::Data& d);

private:

public:
    /*!
     * \brief Default constructor for skin cell data for skin cells
     *        of version 2.
     *
     * Initializes all data fields to 0 and also the cell id, the patch id,
     * and the time stamp to 0
     */
    Data();

    /*!
     * \brief Copy constructor.
     */
    Data(const Data& d);

    /*!
     * \brief Copy constructor for low level type class.
     * \param d The type class of the low level library.
     */
    Data(const ::Skin::Cell::Data& d);

    /*!
     * \brief Copy constructor for the Skin Cell Data ROS message
     * \param d The Skin Cell Data ROS message
     */
    Data(const DataMsg& d);

    ~Data();

    /*! \brief Conversion operator for converting the data of a skin cell
     *         to the corresponding Skin Cell Data ROS message.
    */
    operator DataMsg() const;

    /*!
     * \brief Creates a Skin Cell Data ROS message for the skin cell data of this class.
     * \return Skin Cell Data ROS message
     */
    DataMsg msg() const;


    /*!
     * \brief Updates a Skin Cell Data ROS message for the skin cell data of this class.
     * \return The updated Skin Cell Data ROS message for the given reference.
     */
    DataMsg& msg(DataMsg&) const;
};


}}

#endif // TUM_ICS_SKIN_CELL_DATA_H
