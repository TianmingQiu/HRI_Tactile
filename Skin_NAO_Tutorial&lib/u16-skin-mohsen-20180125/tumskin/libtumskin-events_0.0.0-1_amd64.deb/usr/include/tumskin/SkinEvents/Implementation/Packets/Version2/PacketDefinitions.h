/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINEVENTS_PACKETSV2_PACKETDEFINITIONS_H
#define SKINEVENTS_PACKETSV2_PACKETDEFINITIONS_H

#include <SkinCore/Implementation/Packets/Version2/PacketDefinitions.h>

namespace Skin{
namespace Implementation{
namespace Packets
{
    namespace Version2
    {
        namespace Events
        {
            const char CMD_PKT_HEADER               = 0xE0;
            const char CMD_MODE_OFF                 = 0x50;
            const char CMD_MODE_STD                 = 0x51;
            const char CMD_SEND_THRESH              = 0x52;
            const char CMD_STORE_THRESH             = 0x53;
            const char CMD_LOAD_THRESH              = 0x54;
            const char CMD_SEND_CONFIG              = 0x55;

            const char THRESH_PKT_HEADER            = 0xE1;
//            const char EVENTS_DATA_PKT_HEADER       = 0xE2;
            const char EVENTS_DIFF_PKT_HEADER       = 0xE3;
            const char EVENTS_ALL_DATA_PKT_HEADER   = 0xE4;
            const char EVENTS_CONFIG_PKT_HEADER     = 0xE5;
        }
    }
}
}
}

#endif // SKINEVENTS_PACKETSV2_PACKETDEFINITIONS_H
