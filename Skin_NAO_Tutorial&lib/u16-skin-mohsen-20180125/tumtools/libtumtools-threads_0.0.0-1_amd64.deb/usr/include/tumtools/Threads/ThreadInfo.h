#ifndef THREADS_THREADINFO_H
#define THREADS_THREADINFO_H

#include <QString>
#include <QList>
#include <QTextStream>

namespace Threads{

class ThreadInfo
{
public:

private:
    int m_tid;
    QString m_name;

public:
    ThreadInfo(int tid = -1,
               const QString& name = "");

    ThreadInfo(const ThreadInfo& ti);
    ~ThreadInfo();

    // operators only consider thread id !
    bool operator== (const ThreadInfo& other) const;
    bool operator!= (const ThreadInfo& other) const;

    // only works for ip v4 addresses
    bool operator< (const ThreadInfo& other) const;

    int tid() const;
    const QString& name() const;

    QString toString() const;

private:

};

}

QTextStream& operator << (QTextStream& s, const Threads::ThreadInfo& ti);
QTextStream& operator >> (QTextStream& s, Threads::ThreadInfo& ti);

QTextStream& operator << (QTextStream& s, const QList<Threads::ThreadInfo>& til);
QTextStream& operator >> (QTextStream& s, QList<Threads::ThreadInfo>& til);


#endif  // THREADS_THREADINFO_H
