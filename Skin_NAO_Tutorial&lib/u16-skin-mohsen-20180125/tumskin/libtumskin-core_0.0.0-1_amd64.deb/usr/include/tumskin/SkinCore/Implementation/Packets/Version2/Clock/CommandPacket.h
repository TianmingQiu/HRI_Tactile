/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINIMPLPKTS_CLOCK_COMMANDPACKETV2_H
#define SKINIMPLPKTS_CLOCK_COMMANDPACKETV2_H

#include <SkinCore/Implementation/Packet.h>
#include <SkinCore/Implementation/Packets/Version2/PacketDefinitions.h>

namespace Skin{
namespace Implementation{
namespace Packets {
namespace Version2{
namespace Clock{

class CommandPacket : public Packet
{

public:
    enum Command
    {
        SendClock = 0,
    };

    static const int PKT_SIZE = 20;
    static Packet& setId(Packet& p, int id);
    static void setCommand(Packet& p, Command cmd);


public:
    CommandPacket(Command cmd=SendClock,
                  int id=ID_ALL,
                  const QVector<Endpoint>& dest=QVector<Endpoint>());

    void setId(int id);
    void setCommand(Command cmd);

private:
    void init(Command mode=SendClock,int id=ID_ALL);

};

}}}}}

#endif // SKINIMPLPKTS_CLOCK_COMMANDPACKETV2_H
