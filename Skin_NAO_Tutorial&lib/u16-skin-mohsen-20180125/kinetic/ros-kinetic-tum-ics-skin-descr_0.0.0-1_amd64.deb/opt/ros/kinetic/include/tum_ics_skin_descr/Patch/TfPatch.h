#ifndef TTUM_ICS_SKIN_DESCR_PATCH_TF_PATCH_H
#define TTUM_ICS_SKIN_DESCR_PATCH_TF_PATCH_H

#include <tum_ics_skin_descr/ConfigFileReader.h>
#include <tum_ics_skin_descr/ConfigFileWriter.h>

#include <tum_ics_skin_descr/Cell/Markers.h>
#include <tum_ics_skin_descr/Patch/Extrinsics.h>
#include <tum_ics_skin_descr/Patch/DriverSettings.h>

#include <SkinCore/Config/Patch.h>
#include <SkinCore/Cell/Data.h>

#include <Math/MathTools.h>

namespace tum_ics_skin_descr{
namespace Patch{

// this it the high level representation of a skin patch
//  -> it contains patch intrinsics (pose and kinematic chains of skin patch)
//  -> it contains patch extrinsics (baseFrame, dh pose, dh baseFrame)
class TfPatch
{
public:
    static TfPatch Undefined();

private:
    static const Cell::TfContainer CellTfContainerDefault;

    typedef ::Skin::Cell::Organization Organization;
    typedef ::Skin::Cell::Data Data;
    typedef ::Skin::Patch Patch;

    typedef tum_ics_skin_descr::Patch::Extrinsics PatchExtrinsics;
    typedef tum_ics_skin_descr::Patch::DriverSettings PatchDriverSettings;

    typedef tum_ics_tfs::TfConversions TfConversions;
    typedef Tum::Tools::MathTools MathTools;

private:
    Patch m_patch;

    QString m_cellTfNameBase;
    QString m_markerNameSpace;

    int m_rootCellId;
    int m_rootCellInd;

    PatchExtrinsics m_patchExtrinsics;
    PatchDriverSettings m_patchDriverSettings;

    /**  Transformation:
     *
     *          dh
     *                  T
     *                      base
     *
     *  -> tf: from base to dh:           base -> dh
     *  -> tf: dh with respect to base:  dh wrt. base
    */
    tum_ics_tfs::TfContainer m_tfc_dh_base;          // inverse of tf in extrinsics


    /**  Transformation:
     *
     *      rootCell
     *                  T
     *                      base
     *
     *  -> tf: from base to rootCell:           base -> rootCell
     *  -> tf: rootCelll with respect to base:  rootCell wrt. base
    */
    tum_ics_tfs::TfContainer m_tfc_rootCell_base;    // same as in extrinsics


    /**  Transformation:
     *
     *      rootCell
     *                  T
     *                      dh
     *
     *  -> tf: from dh to rootCell:             dh -> rootCell
     *  -> tf: rootCell with respect to dh:     rootCell wrt. dh
    */
    tum_ics_tfs::TfContainer m_tfc_rootCell_dh;

    /**  Transformation:
     *
     *      cell_i
     *                  T
     *                      rootCell
     *
     *  -> tf: from rootCell to cell_i:         rootCell -> cell_i
     *  -> tf: cell_i with respect to rootCell: cell_i wrt. rootCell
     *
     *
     *  -> root cell in the list contains tf:   dh -> rootCell
     *
     *      rootCell
     *                  T
     *                      dh
     *
     *  -> tf: from rootCell to dh:             dh -> rootCell
     *  -> tf: rootCell with respect to dh:     rootCell wrt. dh
     *
     *  -> root cell in the list contains tf:   dh -> rootCell
     *
     *
     *  - the cells are indexed in the same way as the low level patch
    */
    QVector<Cell::TfContainer>  m_cellTfcs;      // all the cells, including root cell
    QMap<QString,int>           m_cellNameMap;  // map: cell name -> cell ind



    /**  Transformation:
     *
     *      cell_i
     *                  T
     *                      base
     *
     *  -> tf: from base to cell_i:             base -> cell_i
     *  -> tf: cell_i with respect to base:     cell_i wrt. base
     *
     *
     *  - the cells are indexed in the same way as the low level patch
    */
    QVector<Eigen::Affine3d> m_tf_cell_base;  // tf: base -> cell


    /**  Transformation:
     *
     *      cell_i
     *                  T
     *                      dh
     *
     *  -> tf: from dh to cell_i:               dh -> cell_i
     *  -> tf: cell_i with respect to dh:       cell_i wrt. dh
     *
     *
     *  - the cells are indexed in the same way as the low level patch
    */
    QVector<Eigen::Affine3d> m_tf_cell_dh;    // tf: dh -> cell

    // z axis and translation of m_tf_cell_dh
    QVector<Eigen::Vector3d> m_z_cell_dh;
    QVector<Eigen::Vector3d> m_t_cell_dh;

    // cross product of (z_cell_dh, t_cell_dh)
    QVector<Eigen::Vector3d> m_c_cell_dh;

    bool m_dhTfUsed;  // decides which chain to use: either over base or dh

public:
    TfPatch(const QString& markerNameSpace = "SkinCellMarkers",
            const QString& cellTfNameBase = "/sensor_");

    TfPatch(const TfPatch& p);
    ~TfPatch();

    // when enabled then use tf chain: dh frame -> root cell
    // when not enabled then use tf chain: base frame -> root cell
    // default: not enabled
    void useDHTf(bool used = true);

    // if no patch id is specified, then load first patch in file
    bool load(const QString& filePath, int patchId = 0);
    bool save(const QString& filePath);

    // load / save dialogs
    bool loadDialog(const QString& path = QString(), int patchId = 0);
    bool saveDialog(const QString& path = QString());

    // gets extrinsics from dialog
    bool patchExtrinsicsDialog();

    // create Tf patch from given patch
    // if the patch extrinsics are undefined, then default extrinsics will be created
    // the dh frame name defaults to dh_<patch_id>
    bool create(const Patch& patch,
                const PatchExtrinsics& pe = PatchExtrinsics::Default());

    bool create(const Patch& patch,
                const PatchDriverSettings& pds,
                const PatchExtrinsics& pe = PatchExtrinsics::Default());

    bool create(const TfPatch& patch);

    void setPatchDriverSettings(const PatchDriverSettings& pds
                                = PatchDriverSettings::Undefined());

    // =============================================================================
    //
    //              Patch extriniscs
    //
    // =============================================================================

    // NOTE: the local tf kinematic chain is:
    //      dh -> rootCell ----> cells

    // this fails if the patch is undefined
    void setPatchExtrinsics(const PatchExtrinsics& pe = PatchExtrinsics::Default());

    // assigns the base frame of the patch; changes the parent of the DH TF
    void setBaseFrame(const QString& baseFrame);

    // empty defaults to dh_<patch_id>
    void setDHFrame(const QString& dhFrame="");

    void setJointId(int jointId);

    // sets the tf: dh -> base
    // updates list of dh tfs
    // updates tf: dh -> rootCell
    // does NOT update tf: base -> rootCell
    // does NOT update tf of root cell in low level patch
    void set_tf_base_dh(const Eigen::Affine3d& h);

    // sets the tf: base -> root cell
    // updates tf: base -> rootCell, updates also tf of root cell in low level patch
    // updates tf of root cell in cell tf list and low level patch
    // updates the list of base tfs
    // updates the tf: dh -> rootCell
    // does NOT update tf: dh -> base
    void set_tf_rootCell_base(const Eigen::Affine3d& h);

    // set patch pose wrt. base frame
    // same as: set_tf_rootCell_base
    void setPose(const tum_ics_tfs::TfContainer& tf);

    void setPose(const Eigen::Affine3d& tf);

    void setPose(const Eigen::Matrix3d& rot,
                 const Eigen::Vector3d& pos);

    void setPose(const Eigen::Quaterniond& q,
                 const Eigen::Vector3d& pos);

    void setPose(const tf::Transform& tf);

    void setPose(const tf::Quaternion& q,
                 const tf::Vector3& pos);

    void setPose(const geometry_msgs::Pose& pose);


    void setPos(const Eigen::Vector3d& pos);
    void setPos(const tf::Vector3& pos);

    void setRot(const Eigen::Matrix3d& rot);

    void setQuaternion(const Eigen::Quaterniond& q);
    void setQuaternion(const tf::Quaternion& q);



    const PatchExtrinsics& patchExtrinsics() const;

    // base frame of the patch
    const QString& baseFrame() const;
    const QString& dhFrame() const;
    int jointId() const;

    Eigen::Affine3d tf_rootCell_base() const;
    Eigen::Affine3d tf_rootCell_dh() const;

    const tum_ics_tfs::TfContainer& tfc_rootCell_base() const;
    const tum_ics_tfs::TfContainer& tfc_rootCell_dh() const;

    // get patch pose with respect to base frame (same as tfc_rootCell_base)
    const tum_ics_tfs::TfContainer& tfc() const;

    const tf::Transform& poseTf() const;
    tf::Vector3 posTf() const;
    tf::Quaternion quaternionTf() const;

    Eigen::Affine3d poseEigen() const;
    Eigen::Vector3d posEigen() const;
    Eigen::Matrix3d rotEigen() const;
    Eigen::Quaterniond quaternionEigen() const;

    geometry_msgs::Pose poseMsg() const;

    // get index from cell id
    int index(int id) const;

    // cells wrt. base / dh, the cells are indexed in the same way as the low level patch
    const QVector<Eigen::Affine3d>& tf_cell_base() const;
    const QVector<Eigen::Affine3d>& tf_cell_dh() const;

    // z axis of tf cell wrt dh
    const QVector<Eigen::Vector3d>& z_cell_dh() const;
    const QVector<Eigen::Vector3d>& t_cell_dh() const;

    // cross product of (z_cell_dh, t_cell_dh)
    const QVector<Eigen::Vector3d>& c_cell_dh() const;



    // =============================================================================
    //
    //              Patch intrinsics
    //
    // =============================================================================


    // change the root (reference) cell of the patch; mirrored to Patch
    bool changeRootCell(int newRootCellId);
    bool changePatchId(int patchId);

    bool isUndefined() const;
    const Patch& patch() const;

    const QString& rootCellFrame() const;
    const QString& cellTfNameBase() const;


    QVector<int> cellIds() const;
    int numberOfCells() const;

    int indexOfCell(const QString& cellName) const;
    int indexOfCellId(int cellId) const;
    int indexOfLocalCellId(int localCellId) const;     // localId = ind + 1

    // all the cell tfs, cell tf wrt. root cell, rootCell wrt. dh
    const Cell::TfContainer& cellTfc(int cellInd) const;
    const QVector<Cell::TfContainer>& cellTfcs() const;

    // all the cell tfs, cell tf wrt. root cell, rootCell wrt. dh or wrt. base
    // reference frame of rootCell is defined by useDHTf() flag
    QVector<tf::StampedTransform> stampedTfs() const;


    const PatchDriverSettings& patchDriverSettings() const;
    QString briefInfo() const;


private:
    QString genCellName(int cellInd); // local id + (patch id - 1) * 1000

    // update tf chaines tf_cell_dh and m_tf_cell_base
    void updateTfChains();

};

}}



#endif // TTUM_ICS_SKIN_DESCR_PATCH_TF_PATCH_H
