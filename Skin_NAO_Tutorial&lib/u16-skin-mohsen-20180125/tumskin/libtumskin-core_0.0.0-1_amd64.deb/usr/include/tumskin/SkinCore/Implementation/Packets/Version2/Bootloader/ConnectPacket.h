/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINIMPLPKTS_CONNECTPACKETV2_H
#define SKINIMPLPKTS_CONNECTPACKETV2_H

#include <SkinCore/Implementation/Packet.h>

namespace Skin{
namespace Implementation{
namespace Packets {
namespace Version2{
namespace Bootloader{

class ConnectPacket : public Packet
{
public:
    static const int PKT_SIZE = 4;
    static bool check(const Packet& p);

public:
    ConnectPacket();
    ConnectPacket(const QVector<Endpoint>& dest);

private:
    void init();

};

}}}}}





#endif // SKINIMPLPKTS_CONNECTPACKETV2_H
