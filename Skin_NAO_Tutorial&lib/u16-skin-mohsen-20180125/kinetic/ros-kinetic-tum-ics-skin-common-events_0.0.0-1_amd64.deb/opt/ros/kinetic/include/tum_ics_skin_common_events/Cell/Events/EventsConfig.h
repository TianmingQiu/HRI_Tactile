#ifndef TUM_ICS_SKIN_EVENTS_CELL_EVENTS_EVENTSCONFIG_H
#define TUM_ICS_SKIN_EVENTS_CELL_EVENTS_EVENTSCONFIG_H

#include <ros/ros.h>
#include <tum_ics_skin_msgs_events/SkinCellEventConfig.h>

#include <tum_ics_skin_common_events/Events/Type.h>
#include <tum_ics_skin_common_events/Cell/Events/Events.h>

#include <QString>
#include <QVector>

namespace tum_ics_skin_common_events{
namespace Cell{
namespace Events{

class EventsConfig
{
private:
    typedef tum_ics_skin_common_events::Events::Type EventsType;
    typedef tum_ics_skin_msgs_events::SkinCellEventConfig ConfigMsg;

public:
    static EventsConfig fromMsg(const ConfigMsg&);
    static ConfigMsg toMsg(const EventsConfig& c);
    static ConfigMsg& toMsg(ConfigMsg& m, const EventsConfig& c);

private:
    int m_cellId;                       // cell id starts at one
    QVector<EventsType> m_events;     // active skin cell events

public:
    EventsConfig(int cellId = -1, const QVector<EventsType>& e = AllEvents);
    EventsConfig(int cellId, const EventsType& e);
    EventsConfig(const ConfigMsg& c);
    EventsConfig(const EventsConfig& c);

    void clear();
    void append(const QVector<EventsType>& e);
    void append(const EventsType& e);

    // only id desides
    bool operator== (const EventsConfig& other) const;
    bool operator!= (const EventsConfig& other) const;

    // for QMap
    bool operator< (const EventsConfig& other) const;

    bool hasEvent(const ::Skin::Events::Type& e) const;

    int id() const;
    const QVector<EventsType>& events() const;

    QString toString() const;


    operator ConfigMsg() const;

    ConfigMsg msg() const;
    ConfigMsg& msg(ConfigMsg&) const;
};


}}}

#endif // TUM_ICS_SKIN_EVENTS_CELL_EVENTS_EVENTSCONFIG_H
