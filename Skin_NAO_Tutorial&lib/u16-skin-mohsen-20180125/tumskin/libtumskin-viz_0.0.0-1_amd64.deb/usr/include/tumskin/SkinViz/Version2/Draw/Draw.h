/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINVIZ_DRAWV2_H
#define SKINVIZ_DRAWV2_H

#include <QVector>

#include <GL/glu.h>
#include <Eigen/Eigen>

#include <SkinCore/Cell/LedColor.h>
#include <SkinCore/Cell/Data.h>

namespace Skin{
namespace Visualization{
namespace Version2{

using namespace Cell;

class Draw
{
public:
    static void skinCell(const Eigen::Vector3d& pos,
                         const Eigen::Matrix3d& rot,
                         const Data& data,
                         const LedColor& color=LedColor::Black,
                         bool labelsEnabled=true);

private:
    static void vcln4010Sensor(const Eigen::Vector3d& pos,
                               double rot,
                               double val);

    static void bma250Sensor(const Eigen::Vector3d& pos,
                             double rot,
                             double val[3]);

    static void lm71Sensor(const Eigen::Vector3d& pos,
                           double rot,
                           double val);

    static void forceCellSensor(const Eigen::Vector3d& pos,
                                double rot,
                                double val);

    static void rgbLed(const Eigen::Vector3d& pos,
                       const LedColor& color);

    static void glutString(const QString& str);
private:
    Draw();



};


}
}
}


#endif // SKINVIZ_DRAWV2_H
