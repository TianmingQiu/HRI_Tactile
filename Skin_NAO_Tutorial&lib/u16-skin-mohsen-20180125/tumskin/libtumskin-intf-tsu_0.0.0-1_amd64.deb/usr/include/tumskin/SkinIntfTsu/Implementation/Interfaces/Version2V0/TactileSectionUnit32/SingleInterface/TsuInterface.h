/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKININTFTSU_TSU32SINGLEINTERFACEV2V0_H
#define SKININTFTSU_TSU32SINGLEINTERFACEV2V0_H

#include <SkinCore/Implementation/Interface.h>

// needs network in "QT       += core gui network"
#include <QUdpSocket>
#include <QElapsedTimer>
#include <QTimer>

#include <SkinCore/Implementation/IntfNode.h>

namespace Skin{
namespace Implementation{
namespace Interfaces{
namespace Version2V0{
namespace TactileSectionUnit32{
namespace SingleInterface{

class TsuInterface : public Interface
{
    Q_OBJECT

public:

    static const int ALIVE_INTERVAL        = 100;      // ms
    static const int TYPE;
    static const QString NAME;

    static const int PC_UDP_PORT;


    static const QString STD_IP_ADDR;
    static const int UDP_PORT;

    static const QString PKT_HEADER;
    static const int IND_OF_CMD;
    static const int IND_OF_ARG;

    static const int CMD_UART_TX;
    static const int CMD_LEDS;
    static const int CMD_POWER;

    static const int ARG_PORT_MASK;
    static const int ARG_LEDS_ON;
    static const int ARG_LEDS_OFF;
    static const int ARG_POWER_ON;
    static const int ARG_POWER_OFF;


private:
    QUdpSocket*     m_sock;

    TsuNode         m_node;

    bool            m_ledToggleFlag;
    bool            m_initialized;

    QElapsedTimer   m_timer;

    InterfaceError  m_error;
    QString         m_errorString;

    QTimer*         m_aliveTimer;


public:
    explicit TsuInterface(QObject* parent = 0);
    ~TsuInterface();

    bool setNode(const IntfNode& node);
    bool setNodes(const QVector<IntfNode>& nodes);

    bool init();
    bool deinit();

    int type() const;
    QString name() const;

    bool isInitialized() const;
    bool hasPendingPackets();

    bool enablePower(bool enable);

    bool readPacket(Packet& p);
    bool writePacket(const Packet& p);

    bool flushRx();

    qint64 getTime();

    void clearError();
    Interface::InterfaceError error() const;
    QString errorString();


private:


    bool writeData(const QByteArray& data);
    bool writeData(const QByteArray& data,
                        const QString &destIpAddr,
                        quint16 destPort);

    void handleError(InterfaceError error);
    void handleError(InterfaceError error, const QString& details);
    QString errorToString(InterfaceError error);

private slots:
    void sendAlive();

};

}
}
}
}
}
}



#endif // SKININTFTSU_TSU32SINGLEINTERFACEV2V0_H
