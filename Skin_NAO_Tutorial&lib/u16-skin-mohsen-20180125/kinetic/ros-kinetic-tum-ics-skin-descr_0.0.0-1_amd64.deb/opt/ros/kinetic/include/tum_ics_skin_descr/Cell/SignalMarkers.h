#ifndef TUM_ICS_SKIN_DESCR_SIGNALMARKERS_H
#define TUM_ICS_SKIN_DESCR_SIGNALMARKERS_H

#include <visualization_msgs/MarkerArray.h>
#include <tum_ics_skin_descr/Cell/SignalMarker.h>
#include <SkinCore/Cell/Data.h>

namespace tum_ics_skin_descr{
namespace Cell{

class SignalMarkers
{
public:

    enum SignalType
    {
        Prox = 0,
        Force1,
        Force2,
        Force3,
        AccX,
        AccY,
        AccZ,
        Temp,
        NumOfSignalTypes,
        Undefined = -1
    };

private:
    typedef ::Skin::Cell::Data Data;

    QVector<SignalMarker> m_signalMarkers;
    visualization_msgs::MarkerArray m_markers;

    QVector<double> m_sigScale;
    QVector<double> m_sigOffset;
    QVector<bool> m_updated;

public:
    // the base tf frame is the tf frame of the cell
    // marker base id: marker id to with the signal types are added
    SignalMarkers(const tum_ics_tfs::TfBranch& base, int baseMarkerId);
    SignalMarkers(const tum_ics_skin_descr::Cell::TfBranch& base, int baseMarkerId);

    SignalMarkers(const SignalMarkers& sm);

    ~SignalMarkers();

    void update(const Data& d);

    void update(SignalType t, double value);

    // only gets updated signal markers; resets updated state var on call
    visualization_msgs::MarkerArray updatedMarkers();

    // signal markers
    const visualization_msgs::MarkerArray& markers() const;


private:
    void init(const tum_ics_tfs::TfBranch& base, int baseMarkerId);

};

}}

#endif // TUM_ICS_SKIN_DESCR_SIGNALMARKERS_H
