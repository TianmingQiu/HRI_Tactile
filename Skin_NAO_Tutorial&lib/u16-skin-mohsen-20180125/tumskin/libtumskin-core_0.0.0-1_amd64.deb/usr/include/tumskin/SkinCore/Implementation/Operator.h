/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINIMPLOPERATOR_H
#define SKINIMPLOPERATOR_H

#include <QVector>
#include <QObject>

#include <SkinCore/Cell/Data.h>
#include <SkinCore/Cell/Neighbors.h>
#include <SkinCore/Cell/AccCalib.h>
#include <SkinCore/Cell/LedColor.h>
#include <SkinCore/Implementation/Packet.h>

#include <SkinCore/Implementation/IntfNode.h>

#include <SkinCore/Cell/Events/Event.h>

namespace Skin{
namespace Implementation{

using namespace Skin::Cell;
using namespace Skin::Implementation;

class Operator : public QObject
{
    Q_OBJECT

public:
    enum OperatorError
    {
        NoError = 0,
        ConnectError,
        DisconnectError,
        AlreadyConnectedError,
        NotConnectedError,
        InterfaceError,
        WriteError,
        ReadError,
        InvalidIdError,
        TimeoutError,
        UnknownError,
    };

    enum MemoryCommand
    {
        StoreIds        = 1,
        ClearIds        = 2,
        StoreOffsets    = 3,
        ClearOffsets    = 4,
    };

public:
    explicit Operator(QObject* parent = 0) : QObject(parent){}
    virtual ~Operator(){}

    virtual bool setNode(const IntfNode& n) = 0;
    virtual bool setNodes(const QVector<IntfNode>& nodes) = 0;

    virtual const QString& name() const = 0;

    virtual int numberOfCells() const = 0;
    virtual bool isConnected() const = 0;

    virtual qint64 getTime() = 0;

    virtual void clearError() = 0;
    virtual Operator::OperatorError error() const = 0;
    virtual QString errorString() = 0;

public slots:
    virtual void connect() = 0;
    virtual void disconnect() = 0;

    virtual void sendMemoryCommand(Skin::Implementation::Operator::MemoryCommand cmd) = 0;
    virtual void changeLedColor(Skin::Cell::LedColor color, int id) = 0;

    virtual void sendPacket(Skin::Implementation::Packet p) = 0;

signals:
    void connected(void);
    void disconnected(void);

    void connectFailed(void);
    void disconnectFailed(void);

    void newNumberOfCells(int num);
    void newNeighborList(QVector<Skin::Cell::Neighbors> nl);
    void newIdList(QVector<int> ids);

    void newDataBunch(QVector<Skin::Cell::Data> d);
    void newPacketBunch(QVector<Skin::Implementation::Packet> p);

    void newEventDataPacketBunch(QVector<Skin::Implementation::Packet> p);
    void newEventBunch(QVector<Skin::Cell::Events::Event>);

    void error(Skin::Implementation::Operator::OperatorError error);

};


}
}


#endif // SKINIMPLOPERATOR_H
