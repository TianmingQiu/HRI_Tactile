/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINEVENTS_PACKETSV2_EVENTS_EVENTSDATAPACKETV2_H
#define SKINEVENTS_PACKETSV2_EVENTS_EVENTSDATAPACKETV2_H

#include <SkinCore/Implementation/Packet.h>
#include <SkinCore/Implementation/Packets/Version2/Events/EventsDataPacketBase.h>
#include <SkinCore/Implementation/Packets/Version2/Data/RawSensorData.h>
#include <SkinCore/Cell/Events/Events.h>
#include <SkinCore/Cell/Events/Flags.h>

namespace Skin{
namespace Implementation{
namespace Packets {
namespace Version2{
namespace Events{


class EventsDataPacket : public EventsDataPacketBase
{

public:
    static const int PKT_SIZE = 20;

    static Skin::Cell::Events::Flags& getActiveEventFlags(Skin::Cell::Events::Flags& f, const Packet& p);
    static Skin::Cell::Events::Flags getActiveEventFlags(const Packet& p);

    static QVector<Skin::Events::Type>& getActiveEvents(QVector<Skin::Events::Type>& events,const Packet& p);
    static QVector<Skin::Events::Type> getActiveEvents(const Packet& p);

    // add events to events, starting at eventsInd
    // eventsInd is updated
    static QVector<Skin::Cell::Events::Event>& addEvents(
            QVector<Skin::Cell::Events::Event>& events,
            int& eventsInd,
            const Packet& p);

    // gets all active events and appends them to events
    static QVector<Skin::Cell::Events::Event>& getEvents(
            QVector<Skin::Cell::Events::Event>& events,
            const Packet& p);

    static QVector<Skin::Cell::Events::Event> getEvents(const Packet& p);

    static Skin::Cell::Data& updateData(Skin::Cell::Data& d, const Packet& p);
    static Data::RawSensorData& updateData(Data::RawSensorData& d, const Packet& p);

public:
    static unsigned int getRawEventValue(const Packet& p, int ind);
    static double getEventValue(int ind, unsigned int val);

private:
    static Data::RawSensorData& updateData(Data::RawSensorData& d, int ind, unsigned int val);
    static Skin::Cell::Data& updateData(Skin::Cell::Data& d, int ind, unsigned int val);

    static int int8_to_int(unsigned int val_int8);
    static int int10_to_int(unsigned int val_int10);
    static int int14_to_int(unsigned int val_int14);

public:
    EventsDataPacket(const QVector<Endpoint>& dest=QVector<Endpoint>());

private:




};

}}}}}

#endif // SKINEVENTS_PACKETSV2_EVENTS_EVENTSDATAPACKETV2_H
