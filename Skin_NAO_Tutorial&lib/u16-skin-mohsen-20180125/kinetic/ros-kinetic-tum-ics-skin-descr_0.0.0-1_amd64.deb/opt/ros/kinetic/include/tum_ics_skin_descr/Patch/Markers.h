#ifndef TUM_ICS_SKIN_DESCR_PATCH_MARKERS_H
#define TUM_ICS_SKIN_DESCR_PATCH_MARKERS_H

#include <tum_ics_skin_descr/Cell/TfContainer.h>
#include <tum_ics_skin_descr/Cell/Markers.h>
#include <tum_ics_skin_descr/Patch/TfPatch.h>

#include <tum_ics_skin_common/CallbackProvider.h>

#include <SkinCore/Config/Patch.h>
#include <SkinCore/Cell/Data.h>

#include <QMutex>

namespace tum_ics_skin_descr{
namespace Patch{

class Markers :
        private tum_ics_skin_common::CallbackProvider<QVector< ::Skin::Cell::Data> >
{
public:

protected:
    typedef ::Skin::Cell::Data Data;
    typedef QVector< ::Skin::Cell::Data> DataBunch;

    QVector<Cell::Markers*> m_cellMarkers;
    QVector<Cell::TfBranch> m_tfbs;

    QMap<int,int> m_cellIdMap;  // map: cell id -> cell ind

    // structure (map and cell markers) and data
    QMutex m_mutex;

public:
    // NOTE: the markers need only information about the tf branch to
    //          to which they are attached to
    //       the transformation between marker and associated tf is
    //          always the identity

    Markers(const QVector<Cell::TfBranch> tfbs = QVector<Cell::TfBranch>());
    Markers(const QVector<Cell::TfContainer> tfcs); // takes only the tf branches
    Markers(const TfPatch& patch);  // takes only the tf branches

    Markers(const Markers& m);
    virtual ~Markers();

    virtual void create(const QVector<Cell::TfBranch>& tfbs);
    virtual void create(const QVector<Cell::TfContainer>& tfcs);
    virtual void create(const TfPatch& patch);

    // updates the markers
    void update(const ::Skin::Cell::Data& d);
    void update(const DataBunch& d);

    bool isUndefined() const;

    // stamped on call; create viz markers and sig markers for given cells
    visualization_msgs::MarkerArray markers(int cellId,const ros::Duration& dur = ros::Duration());
    visualization_msgs::MarkerArray markers(const QVector<int>& cellIds,const ros::Duration& dur = ros::Duration());

    // stamped on call; create viz markers for all cells and all sigs
    visualization_msgs::MarkerArray markers(
            const ros::Duration& dur = ros::Duration(),
            const QString& ns="");

    // only the cell markers
    visualization_msgs::MarkerArray cellMarkers(
            const ros::Duration& dur = ros::Duration(),
            const QString& ns="");

    // only the cell signal markers
    visualization_msgs::MarkerArray cellSignalMarkers(
            const ros::Duration& dur = ros::Duration(),
            const QString& ns="");

    /*!
     * \brief Get the markers for a signal of all cells
     *
     *  - ind 0: prox
     *  - ind 1: force1
     *  - ind 2: force2
     *  - ind 3: force3
     *  - ind 4: accX
     *  - ind 5: accY
     *  - ind 6: accZ
     *  - ind 7: temp
     */
    visualization_msgs::MarkerArray cellSignalMarker(
            int markerInd,
            const ros::Duration& dur = ros::Duration(),
            const QString& ns="");

    const QVector<Cell::TfBranch>& tfBranches() const;

protected:
    void deleteCellMarkers();

private:
    // data array callback of DataSubscriber
    void callback(const QVector< ::Skin::Cell::Data> &);

};

}}

#endif // TUM_ICS_SKIN_DESCR_PATCH_MARKERS_H
