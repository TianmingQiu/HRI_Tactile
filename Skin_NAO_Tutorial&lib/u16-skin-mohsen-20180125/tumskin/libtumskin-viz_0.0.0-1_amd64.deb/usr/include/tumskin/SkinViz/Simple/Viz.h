/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINVIZ_SIMPLE_VIZ_H
#define SKINVIZ_SIMPLE_VIZ_H

#include <QGLWidget>
#include <QtOpenGL>
#include <QDebug>
#include <QTimer>
#include <QVector>
#include <QMap>

#include <GL/glu.h>

#include <Eigen/Eigen>

#include <SkinCore/Implementation/Packets/Version2/Packets.h>
#include <SkinCore/Cell/Data.h>
#include <SkinCore/Cell/LedColor.h>
#include <SkinCore/Config/Config.h>

namespace Skin{
namespace Viz{
namespace Simple{

using namespace Cell;


// NOTE: you need to call "glutInit(&argc,argv);" in the main.cpp
class Viz : public QGLWidget
{
    Q_OBJECT

private:
    double m_userScale;
    double m_userTranslation[3];
    double m_userRotation[3];

    bool m_launched;
    QPoint m_lastMousePos;
    QTimer* m_updateTimer;                              // update timer for GL Update

    double m_mouseWheelSpeed;

    QMap<int,int> m_cellIdMap;  // map: id -> ind

    QVector<Data>           m_data;
    QVector<LedColor>       m_ledColors;
    Config                  m_config;

public:
    Viz(QWidget* parent = 0);
    ~Viz();

    void setMouseWheelSpeed(double speed = 0.1);

protected:

    void initializeGL();
    void paintGL();
    void resizeGL(int width, int height);


private:
    void mousePressEvent(QMouseEvent* e);
    void mouseMoveEvent(QMouseEvent* e);
    void wheelEvent(QWheelEvent* e);
    void mouseDoubleClickEvent(QMouseEvent* e);

    // KEY EVENTS
    void keyPressEvent(QKeyEvent* e);


    void showEvent(QShowEvent * e);
    void hideEvent(QHideEvent * e);

    void closeEvent(QCloseEvent* e);


public slots:
    void show();
    void hide();

    // build up id map if skin config is empty
    // otherwise refuse ids which do not exits
    void newDataBunch(QVector<Skin::Cell::Data> data);

    // overwrites map and reinitializes everything
    void newSkinConfig(Skin::Config);

    // refuse all ids which are not in the map
    void changeLedColor(Skin::Cell::LedColor color,
                        int id=Implementation::Packets::Version2::ID_ALL);

private slots:
    void update();  // update GL

signals:
    void visibilityChanged(bool visible);

};


}
}
}


#endif // SKIN_VIZV2_H
