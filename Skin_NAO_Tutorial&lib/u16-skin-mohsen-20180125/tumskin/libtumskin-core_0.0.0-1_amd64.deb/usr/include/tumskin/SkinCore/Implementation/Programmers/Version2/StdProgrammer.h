/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINIMPLPROGS_STDPROGRAMMER_H
#define SKINIMPLPROGS_STDPROGRAMMER_H

#include <SkinCore/Implementation/Programmer.h>
#include <SkinCore/Implementation/Interface.h>
#include <SkinCore/Implementation/Packets/Version2/Packets.h>
#include <SkinCore/Implementation/Packets/Version2/Bootloader/NewStartWritePacket.h>

#include <QVector>
#include <QTimer>

namespace Skin{
namespace Implementation{
namespace Programmers{
namespace Version2{

using namespace Skin::Implementation::Packets::Version2;

class StdProgrammer : public Programmer
{
    Q_OBJECT

public:
    static const int waitResetOff               = 500*1000;      // us
    static const int waitBootloaderStartup      = 700*1000;
    static const int waitConnectAckVanishing    = 10*1000;
    static const int waitStartDataWrite         = 100*1000;

    static const int waitWriteData              = 100*1000;
    static const int waitEndeDataWrite          = 100*1000;
    static const int waitSyncTokenVanishing     = 10*1000;

    static const int timeoutConnect             = 2000*1000;
    static const int timeoutWriteAcknowledge    = 1000*1000;
    static const int timeoutSyncToken           = 1000*1000;


    enum Mode
    {
        StdBootloader = 0,
        NewBootloader = 1,
    };


private:
    Interface* m_intf;
    QString m_name;

    bool m_programming;

    ProgrammerError m_error;
    QString m_errorString;

    Mode m_mode;


public:
    StdProgrammer(QObject* parent = 0);
    StdProgrammer(Interface* interface, QObject* parent = 0);
    ~StdProgrammer();

    bool setNode(const IntfNode& n);
    bool setNodes(const QVector<IntfNode>& nodes);

    bool isProgramming() const;

private:
    void init();

public:
    void setInterface(Interface* interface);
    void setName(const QString& name);
    void setMode(Mode mode);

    const QString& name() const;


    void clearError();
    Programmer::ProgrammerError error() const;
    QString errorString();


public slots:
    void program(QVector<Skin::Implementation::DataBlock> blocks);



private:
    bool connectToBootloader();
    bool launchApplication();

    int calcNumberOfDataPackets(const QVector<DataBlock>& blocks);
    int calcNumberOfDataPackets(const DataBlock& block);

    Version getVersion(
            const QVector<DataBlock>& blocks,
            bool* ok=0);

    bool writeDataPackets(const QVector<DataBlock>& blocks);

    void enablePower(bool enable);

    void handleError(ProgrammerError error);
    void handleError(ProgrammerError error, const QString& details);
    QString errorToString(ProgrammerError error);


private slots:
    void handleInterfaceError(Skin::Implementation::Interface::InterfaceError error);
    void handleProgrammerError(Skin::Implementation::Programmer::ProgrammerError error);

};


}
}
}
}

#endif // SKINIMPLPROGS_STDPROGRAMMER_H
