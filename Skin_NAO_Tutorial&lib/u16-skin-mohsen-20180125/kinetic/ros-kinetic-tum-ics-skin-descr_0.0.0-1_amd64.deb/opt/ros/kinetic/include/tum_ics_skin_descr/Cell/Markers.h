#ifndef TUM_ICS_SKIN_DESCR_CELL_MARKERS_H
#define TUM_ICS_SKIN_DESCR_CELL_MARKERS_H

#include <visualization_msgs/Marker.h>
#include <visualization_msgs/MarkerArray.h>

#include <tum_ics_skin_descr/Cell/SignalMarkers.h>

#include <SkinCore/Cell/Data.h>

namespace tum_ics_skin_descr{
namespace Cell{

class Markers
{
public:

protected:
    typedef ::Skin::Cell::Data Data;

    int m_cellId;
    QString m_mesh;
    visualization_msgs::Marker m_cellMarker;
    SignalMarkers m_signalMarkers;

public:
    // NOTE: the markers need only information about the tf branch to
    //          to which they are attached to
    //       the transformation between marker and associated tf is
    //          always the identity

    Markers(const int cellId,
            const tum_ics_tfs::TfBranch& cellTfb,
            const QString& mesh = "package://tum_ics_skin_descr/meshes/SkinCellRx90z90.dae",
            double meshScale = 0.1);

    Markers(const tum_ics_skin_descr::Cell::TfBranch& cellTfb = tum_ics_skin_descr::Cell::TfBranch::Default(),
            const QString& mesh = "package://tum_ics_skin_descr/meshes/SkinCellRx90z90.dae",
            double meshScale = 0.1);

    Markers(const Markers* m);
    Markers(const Markers& m);

    virtual ~Markers();

    void update(const Data& d);

    int cellId() const;

    const visualization_msgs::Marker& cellMarker() const;
    const visualization_msgs::MarkerArray& signalMarkers() const;

private:
    void createCellMarker(const tum_ics_tfs::TfBranch& cellTfb, double scale);

};

}}



#endif // TUM_ICS_SKIN_DESCR_CELL_MARKERS_H
