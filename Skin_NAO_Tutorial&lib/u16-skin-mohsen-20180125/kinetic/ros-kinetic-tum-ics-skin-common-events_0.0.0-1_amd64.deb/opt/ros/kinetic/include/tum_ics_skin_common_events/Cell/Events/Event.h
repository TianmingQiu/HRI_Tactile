#ifndef TUM_ICS_SKIN_EVENTS_CELL_EVENT_H
#define TUM_ICS_SKIN_EVENTS_CELL_EVENT_H

#include <ros/ros.h>
#include <tum_ics_skin_msgs_events/SkinCellEventValue.h>
#include <tum_ics_skin_common_events/Events/Type.h>

#include <SkinCore/Cell/Events/Event.h>

#include <QString>
#include <QVector>

namespace tum_ics_skin_common_events{
namespace Cell{
namespace Events{

class Event :
    public ::Skin::Cell::Events::Event
{
private:
    typedef tum_ics_skin_msgs_events::SkinCellEventValue EventMsg;
    typedef tum_ics_skin_common_events::Events::Type Type;

public:
    static Event fromMsg(const EventMsg&);

    static EventMsg toMsg(const ::Skin::Cell::Events::Event& e);
    static EventMsg& toMsg(EventMsg& m, const ::Skin::Cell::Events::Event& e);

public:
    Event(const ::Skin::Events::Type& type=::Skin::Events::Type(),
          int patchId = 0,
          int cellId = 0,
          double val = 0.0,
          qint64 ts = -1);

    Event(const ::Skin::Events::Type& type,
          int cellId,
          double val = 0.0,
          qint64 ts = -1);

    Event(const ::Skin::Cell::Events::Event& e);
    Event(const EventMsg& m);
    Event(const Event& e);

    operator EventMsg() const;

    EventMsg msg() const;
    EventMsg& msg(EventMsg&) const;

};

}}}

#endif // TUM_ICS_SKIN_EVENTS_CELL_EVENT_H
