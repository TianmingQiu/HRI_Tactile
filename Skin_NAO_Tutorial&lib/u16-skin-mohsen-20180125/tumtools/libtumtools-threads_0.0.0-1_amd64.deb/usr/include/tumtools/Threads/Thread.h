#ifndef THREADS_THREAD_H
#define THREADS_THREAD_H

#include <Threads/ThreadInfo.h>
#include <Threads/ThreadList.h>

#include <QString>
#include <QStringList>
#include <QList>
#include <QVector>
#include <QThread>
#include <QMutex>

namespace Threads{

class Thread : public QThread
{
public:
    static QList<ThreadInfo> threadInfoList();
    static ThreadList threadList();

    static bool saveThreadList(const QString& = "./ThreadList.txt");

    // the process id
    static int getpid();

    // tid of current thread
    static int gettid();

private:
    static QList<ThreadInfo> g_threadInfoList; // global thread list
    static QMutex g_mutex;

private:
    ThreadInfo m_info;

public:
    Thread(const QString& name = "", QObject* parent = 0);
    ~Thread();

    int tid();
    QString name();

protected:
    // note: if you overload this function either call 'run'
    //  of this class, or call 'addToList' 'removeFromList'
    //  to update the thread info list
    virtual void run();

    void addToList();
    void removeFromList();
};

}

#endif  // THREADS_THREAD_H
