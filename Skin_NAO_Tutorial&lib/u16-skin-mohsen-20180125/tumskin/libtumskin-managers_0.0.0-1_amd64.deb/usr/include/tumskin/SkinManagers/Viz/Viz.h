#ifndef SKINMANAGERS_VIZ_H
#define SKINMANAGERS_VIZ_H


#include <QObject>

#include <SkinManagers/Application/Base/Application.h>
#include <SkinViz/Version2/Viz.h>

namespace Skin {
namespace Managers{

using namespace Skin::Cell;

class Viz : public QObject
{
    Q_OBJECT

private:

public:


private:
    typedef bool (Viz::*cmd_handler_func)(const QString& s);
    QVector<cmd_handler_func> m_cmdHandlers;
    QString             m_consoleCmdDescription;

    Skin::Visualization::Version2::Viz  m_viz;
    Skin::Managers::Application::Base::Application*     m_app;

public:
    explicit Viz(Skin::Managers::Application::Base::Application* app,
                        QObject *parent = 0);

    const QString& consoleCmdDescription() const;
    bool handleConsoleCmd(QString);

private:
    bool handleVizCommands(const QString& s);

private slots:
    void vizVisibilityChanged(bool visible);

public slots:
    void newDataBunch(QVector<Skin::Cell::Data> data);
    void newSkinConfig(Skin::Config skin);

signals:
    void visibilityChanged(bool visible);

};

}}




#endif // SKINMANAGERS_VIZ_H
