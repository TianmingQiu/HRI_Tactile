/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKIN_CONFIGFILEWRITER_H
#define SKIN_CONFIGFILEWRITER_H

#include <QVector>
#include <QMetaType>
#include <QMap>

#include <QFile>
#include <QDir>
#include <QXmlStreamWriter>

#include <Eigen/Eigen>

#include <SkinCore/Config/Config.h>
#include <SkinCore/Cell/Neighbors.h>
#include <SkinCore/Cell/Organization.h>


namespace Skin{

using namespace Cell;

class ConfigFileWriter
{
public:

protected:
    bool m_error;
    QString m_errorString;
    QXmlStreamWriter m_xml;

public:
    ConfigFileWriter(const QString& filename,
                     const QVector<Organization>& cells);

    ConfigFileWriter(const QString& filename,
                     const Config& skin);

    ~ConfigFileWriter();

    bool error() const;
    const QString& errorString() const;

protected:
    ConfigFileWriter();

protected:
    void write(const QString& filename,
               const QVector<Organization>& cells);

    void writeCell(const Organization& o);

    void writeRootCellId(int id);
    void writeNeighbors(const Neighbors& n);
    void writeNeighbor(int port, int id);

    void writePos(const Eigen::Vector3d& v);
    void writeRot(const Eigen::Matrix3d& m);

    void writeMatrixXd(const Eigen::MatrixXd& m);
    void writeMatrixElement(int r, int c, double value);

};

}


#endif // SKIN_CONFIGFILEWRITER_H
