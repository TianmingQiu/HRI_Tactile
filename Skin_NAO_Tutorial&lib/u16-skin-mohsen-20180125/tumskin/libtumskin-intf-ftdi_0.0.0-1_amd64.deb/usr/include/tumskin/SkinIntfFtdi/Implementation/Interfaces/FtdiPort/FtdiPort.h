/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKININTFFTDI_FTDIPORT_H
#define SKININTFFTDI_FTDIPORT_H

#include <QElapsedTimer>
#include <QTimer>
#include <QQueue>
#include <QMutex>
#include <Threads/Thread.h>

#include <SkinIntfFtdi/Implementation/Interfaces/FtdiDriver/FtdiDriver.h>
#include <SkinCore/Implementation/TimestampedData.h>

namespace Skin{
namespace Implementation{
namespace Interfaces{

class FtdiPort : public Threads::Thread, private FtdiDriver
{
    Q_OBJECT

private:

    enum PacketState
    {
        WaitForStart    = 0,
        WaitForEnd      = 1
    };

    QElapsedTimer                   m_timer;
    QElapsedTimer                   m_wrTimer;

    bool                            m_stopped;

    QMutex                          m_writeMutex;
    QMutex                          m_readMutex;

    PacketState                     m_pktState;
    QByteArray                      m_pktCache;

    QQueue<TimestampedData>         m_writeBuf;
    QQueue<TimestampedData>         m_readBuf;


public:
    explicit FtdiPort(QObject* parent = 0);

//    using FtdiDriver::setDeviceIndex;
//    using FtdiDriver::setSerialNumber;
//    using FtdiDriver::setDescription;
//    using FtdiDriver::setBaudrate;

    using FtdiDriver::isOpened;

    using FtdiDriver::enablePower;
    using FtdiDriver::enableLed;

    using FtdiDriver::clearError;
    using FtdiDriver::error;
    using FtdiDriver::errorString;


    void startTimer();
    qint64 getTime();


    bool open(const FtdiNode& n);
    void close();

    bool hasPendingPacketData();

    bool readPacketData(TimestampedData& d);
    bool writePacketData(const TimestampedData& d);

    bool flushRx();

private:
    void run();

    void writeHandler();
    void readHandler();

signals:
    void readyRead(void);

};

}
}
}


#endif // SKININTFFTDI_FTDIPORT_H
