/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINIMPLPKTS_NEWSTARTWRITEPACKETV2_H
#define SKINIMPLPKTS_NEWSTARTWRITEPACKETV2_H

#include <SkinCore/Implementation/Packet.h>
#include <SkinCore/Implementation/Packets/Version2/PacketDefinitions.h>
#include <SkinCore/Implementation/Packets/Version2/Version.h>

namespace Skin{
namespace Implementation{
namespace Packets {
namespace Version2{
namespace Bootloader{

class NewStartWritePacket : public Packet
{
public:
    static const int PKT_SIZE = 12;

public:
    NewStartWritePacket();
    NewStartWritePacket(int num = 0,
                        const Version& ver = Version::defaultVersion,
                        const QVector<Endpoint>& dest=QVector<Endpoint>());


    void setVersion(const Version& ver);

    void setMcuFamilyCode(int num);  // 8 bit
    void setMcuDeviceId(int id); // 8 bit
    void setHardwareRevision(int rev); // 8 bit
    void setApplicationVersion(int ver); // 8 bit


    void setNumberOfPackets(int num);   // number of write packets

private:
    void init(int num = 0, const Version& ver=Version::defaultVersion);



};

}}}}}





#endif // SKINIMPLPKTS_NEWSTARTWRITEPACKETV2_H
