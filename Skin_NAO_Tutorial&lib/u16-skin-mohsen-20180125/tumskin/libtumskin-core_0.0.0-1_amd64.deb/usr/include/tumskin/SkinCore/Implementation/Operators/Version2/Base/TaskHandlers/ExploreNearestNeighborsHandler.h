#ifndef SKINCORE_OPERATORSV2_BASE_TASKHANDLERS_EXPLORENEARESTNEIGHBORSHANDLER_H
#define SKINCORE_OPERATORSV2_BASE_TASKHANDLERS_EXPLORENEARESTNEIGHBORSHANDLER_H

#include <SkinCore/Implementation/Operators/Version2/Base/TaskHandler.h>
#include <SkinCore/Implementation/Operators/Version2/Base/Operator.h>

namespace Skin{
namespace Implementation{
namespace Operators{
namespace Version2{
namespace Base{
namespace TaskHandlers{

class ExploreNearestNeighborsHandler : public
        Skin::Implementation::Operators::Version2::Base::TaskHandler
{

private:
    QVector<Neighbors>* m_nneList;
    int* m_num;

public:
    ExploreNearestNeighborsHandler(
            Skin::Implementation::Operators::Version2::Base::Operator* op,
            Skin::Implementation::Interface** intf,
            Skin::Implementation::Operators::Version2::Base::Timing* timings,
            QVector<Neighbors>* nneList,
            int* numberOfCells);

    virtual bool handleTask();
};

}}}}}}

#endif // SKINCORE_OPERATORSV2_BASE_TASKHANDLERS_EXPLORENEARESTNEIGHBORSHANDLER_H
