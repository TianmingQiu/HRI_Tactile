#ifndef TUM_ICS_SKIN_DESCR_SIGNALMARKER_H
#define TUM_ICS_SKIN_DESCR_SIGNALMARKER_H

#include <visualization_msgs/Marker.h>
#include <tum_ics_skin_descr/Cell/TfBranch.h>
#include <tum_ics_skin_descr/Cell/TfContainer.h>

namespace tum_ics_skin_descr{
namespace Cell{

class SignalMarker
{
public:

    static SignalMarker prox(int markerId);
    static SignalMarker accX(int markerId);
    static SignalMarker accY(int markerId);
    static SignalMarker accZ(int markerId);
    static SignalMarker force1(int markerId);
    static SignalMarker force2(int markerId);
    static SignalMarker force3(int markerId);
    static SignalMarker temp(int markerId);

private:

private:
    int m_markerId;
    Eigen::Vector4i m_color;


    /**  Transformation:
     *
     *      signal
     *                  T
     *                      cell
     *
     *  -> tf: from cell to signal:             cell -> signal
     *  -> tf: signal with respect to cell:     signal wrt. cell
    */
    Eigen::Affine3d m_tf_s_c;   // tf: cell -> signal

    double m_boxSide;
    double m_zeroValue;

public:
    SignalMarker(int markerId = 0,
                 const Eigen::Vector4i& color = Eigen::Vector4i(255,255,255,1),
                 const Eigen::Affine3d& tf_s_c = Eigen::Affine3d::Identity(),
                 double boxSide = 0.002,
                 double zeroValue = 0.001);

    SignalMarker(const SignalMarker& sm);

    ~SignalMarker();


    // complete marker, reinit everything, use tf frame of a cell
    visualization_msgs::Marker create(const tum_ics_skin_descr::Cell::TfBranch& base);
    visualization_msgs::Marker create(const tum_ics_tfs::TfBranch& base);

    // updates the visualization marker
    void update(visualization_msgs::Marker& m, double value);

};

}}

#endif // TUM_ICS_SKIN_DESCR_SIGNALMARKER_H
