/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINIMPL_DATABLOCK_H
#define SKINIMPL_DATABLOCK_H

#include <QMetaType>

namespace Skin{
namespace Implementation{

class DataBlock
{

private:
    int m_addr;                 // 16 bit word addr (start)
    QByteArray m_data;          // 3 bytes for 2 words, highest byte = 0x00

public:
    DataBlock();
    DataBlock(const DataBlock& db);
    DataBlock(int addr, const QByteArray& data = QByteArray());

    ~DataBlock();

    bool operator== (const DataBlock& other) const;
    bool operator!= (const DataBlock& other) const;

    // for QMap
    bool operator< (const DataBlock& other) const;

    void setAddress(int addr);

    bool checkAddress(int addr) const;
    int getDataWord(int addr) const;

    int addr() const;
    const QByteArray& data() const;
    QByteArray& data();

    int size() const;

    int endAddr() const;

    void clear();

    QString toString() const;

};


}
}

Q_DECLARE_METATYPE(Skin::Implementation::DataBlock)



#endif // SKINIMPL_DATABLOCK_H
