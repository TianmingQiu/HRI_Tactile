/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINRECON_SIMPLE_SAMPLER_H
#define SKINRECON_SIMPLE_SAMPLER_H

#include <QObject>
#include <QVector>
#include <QMap>
#include <QElapsedTimer>
#include <QMutex>

#include <Eigen/Eigen>

#include <SkinCore/Cell/Data.h>
#include <SkinRecon/Simple/Data.h>

namespace Skin{
namespace Recon{
namespace Simple{

class Sampler
{
private:
    QElapsedTimer m_timeout;

    Data m_samples;

    int m_numOfPoses;
    int m_numOfCells;
    int m_samplesPerCell;

    int m_poseInd;      // pose index
    int m_poseTimeoutVal;  // pose timeout in ms

    bool m_poseTimeout;
    bool m_poseComplete;
    bool m_complete;

    QMutex m_mutex;

public:
    Sampler(int poseTimeout = -1);    // pose timeout in ms, -1 means no timeout
    ~Sampler();

    // delete samples and start sampling of first pose with timeout
    void start(int numOfCells, int numOfPoses=1, int samplesPerCell=16);
    void restart();

    // returns false if adding failed
    //  reason can be:
    //  -> already collected all samples
    //  -> the cell id is invalid
    //  -> timeout
    bool addSample(const Skin::Cell::Data& sample);
    bool addSample(const Eigen::Vector3d& d, int cellId);

    // returns false if
    //  -> current pose is not complete yet
    //  -> there is not next pose
    //  -> there is a timeout
    bool nextPose();

    // get the current pose
    int currentPose() const;
    int currentPoseInd() const;

    // timeout error
    //  -> getting samples for current pose timed out
    bool timeoutError() const;

    // pose complete
    bool poseComplete() const;

    // all samples complete
    bool complete() const;

    // returns empty data as long as incomplete or error
    const Skin::Recon::Simple::Data& samples() const;
};

}}}



#endif // SKINRECON_SIMPLE_SAMPLER_H
