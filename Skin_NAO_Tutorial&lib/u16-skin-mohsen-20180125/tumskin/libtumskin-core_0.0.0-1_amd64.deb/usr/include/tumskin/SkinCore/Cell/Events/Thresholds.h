/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINCORE_CELL_EVENTS_THRESHOLD_H
#define SKINCORE_CELL_EVENTS_THRESHOLD_H

#include <QVector>
#include <QMetaType>

namespace Skin{
namespace Cell{
namespace Events{

class Thresholds
{
public:

    enum Versions
    {
        Version1 = 0,
        Version2
    };

    // order of values in version 2
    //  prox1
    //  force1
    //  force2
    //  force3
    //  acc1
    //  acc2
    //  acc3
    //  temp1
    //  temp2

private:
    QVector<double> m_prox;
    QVector<double> m_force;
    QVector<double> m_acc;
    QVector<double> m_temp;

public:
    Thresholds(Thresholds::Versions v = Version2);

    Thresholds(const QVector<double>& vals, Thresholds::Versions v = Version2);

    Thresholds(const QVector<double>& prox,
               const QVector<double>& force,
               const QVector<double>& acc,
               const QVector<double>& temp);

    Thresholds(double prox,
                double force1,
                double force2,
                double force3,
                double acc1,
                double acc2,
                double acc3,
                double temp1,
                double temp2);

    Thresholds(const Thresholds& t);
    ~Thresholds();

    // enforce positve threshold values
    void setProx(const QVector<double>& prox);
    void setForce(const QVector<double>& force);
    void setAcc(const QVector<double>& acc);
    void setTemp(const QVector<double>& temp);

    const QVector<double>& prox() const;
    const QVector<double>& force() const;
    const QVector<double>& acc() const;
    const QVector<double>& temp() const;

    // collect all values and put them into vector
    //  order is: prox, force, acc, temp
    const QVector<double> values() const;

    void resize(Thresholds::Versions v=Version2);

    void clear();

    QString toString() const;

private:
    void abs();

};

}}}

Q_DECLARE_METATYPE(Skin::Cell::Events::Thresholds)

#endif // SKINCORE_CELL_EVENTS_THRESHOLD_H
