#ifndef SKINCORE_OPERATORS_TASKHANDLER_H
#define SKINCORE_OPERATORS_TASKHANDLER_H

namespace Skin{
namespace Implementation{
namespace Operators{

class TaskHandler
{
public:
    virtual bool handleTask() = 0;
    virtual ~TaskHandler() = 0;
};

inline TaskHandler::~TaskHandler(){}

}}}

#endif // SKINCORE_OPERATORS_TASKHANDLER_H
