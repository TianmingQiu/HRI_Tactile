#ifndef SKINADDITIONS_UPDATERATE_H
#define SKINADDITIONS_UPDATERATE_H


#include <QObject>

#include <SkinManagers/Application/Base/Application.h>

namespace Skin {
namespace Additions{

using namespace Skin::Cell;
using namespace Skin::Managers;

class UpdateRate : public QObject
{
    Q_OBJECT

private:

public:


private:
    typedef bool (UpdateRate::*cmd_handler_func)(const QString& s);
    QVector<cmd_handler_func> m_cmdHandlers;
    QString             m_consoleCmdDescription;

    Skin::Managers::Application::Base::Application*                        m_app;

public:
    explicit UpdateRate(Skin::Managers::Application::Base::Application* app,
                        QObject *parent = 0);

    const QString& consoleCmdDescription() const;
    bool handleConsoleCmd(QString);

private:
    bool handleUpdateRateCommands(const QString& s);

private slots:

public slots:

signals:


};

}}




#endif // SKINADDITIONS_UPDATERATE_H
