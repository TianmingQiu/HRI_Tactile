#ifndef TUM_ICS_SKIN_DRIVER_EVENTS_ROS_SKIN_H
#define TUM_ICS_SKIN_DRIVER_EVENTS_ROS_SKIN_H

#include <QObject>
#include <QTimer>
#include <QVector>
#include <QMutex>

//This definition is needed with libboost 1.58
#ifndef Q_MOC_RUN
#include <Threads/Thread.h>
#include <SkinCore/Cell/Data.h>
#include <SkinCore/Cell/Neighbors.h>
#include <SkinCore/Cell/LedColor.h>
#include <SkinManagers/Application/Standard/Application.h>
#include <SkinAdditions/UpdateRate/UpdateRate.h>
#include <SkinAdditions/ColorFeedback/ColorFeedback.h>
#include <SkinEvents/Managers/Events/Manager.h>


#include <ros/ros.h>

#include <tum_ics_skin_msgs/setSkinCellLedColor.h>
#include <tum_ics_skin_msgs/getSkinCellNeighbors.h>
#include <tum_ics_skin_msgs/getSkinCellIds.h>
#include <tum_ics_skin_msgs_events/enableEventGenerator.h>

#include <tum_ics_skin_msgs/setCmd.h>

#include <tum_ics_skin_driver/DataPubManager.h>
#include <tum_ics_skin_driver_events/ExtForceEventsGenerator.h>
#include <tum_ics_skin_driver_events/EventPubManager.h>

#include <tum_ics_skin_driver_events/MainConsole.h>

#endif

namespace tum_ics_skin_driver_events{

class RosSkin : public QObject
{
    Q_OBJECT

private:
    static Skin::Cell::LedColor convSkinCellLedColor(
            const tum_ics_skin_msgs::SkinCellLedColor& color);

    static tum_ics_skin_msgs::SkinCellNeighbors convNeighbors(
            const Skin::Cell::Neighbors& n);

private:
    ros::NodeHandle                 m_node;

    ros::ServiceServer              m_setSkinLedColorSrv;
    ros::ServiceServer              m_getSkinCellNeighborsSrv;
    ros::ServiceServer              m_getSkinCellIdsSrv;

    ros::ServiceServer              m_enableEventGeneratorSrv;

    ros::ServiceServer              m_setCmdSrv;


    Skin::Managers::Application::Standard::Application* m_app;
    Skin::Additions::UpdateRate*            m_updateRate;
    Skin::Additions::ColorFeedback*         m_colorFeedback;
    Skin::Managers::Events::Manager*        m_events;

    MainConsole* m_mainConsole;

    tum_ics_skin_driver::DataPubManager     m_dataPubMgr;
    EventPubManager                         m_eventPubMgr;

    ExtForceEventsGenerator         m_extForceEventsGen;

    QVector<Skin::Cell::Neighbors>  m_neighs;
    QVector<int>                    m_ids;
    QMap<int,int>                   m_cellIdMap;    // map:  cell id -> ind

    Threads::Thread                 m_thread;
    QMutex                          m_ledColorSrvMutex;

public:
    explicit RosSkin(Skin::Managers::Application::Standard::Application* app,
                     Skin::Additions::UpdateRate* updateRate,
                     Skin::Additions::ColorFeedback* colorFeedback,
                     Skin::Managers::Events::Manager* events,
                     MainConsole* mainConsole,
                     QObject* parent =0);

    ~RosSkin();

private:
    bool setSkinCellLedColorCallback(
            tum_ics_skin_msgs::setSkinCellLedColor::Request &req,
            tum_ics_skin_msgs::setSkinCellLedColor::Response &res);

    bool getSkinCellNeighborsCallback(
            tum_ics_skin_msgs::getSkinCellNeighbors::Request &req,
            tum_ics_skin_msgs::getSkinCellNeighbors::Response &res);

    bool getSkinCellIdsCallback(
            tum_ics_skin_msgs::getSkinCellIds::Request &req,
            tum_ics_skin_msgs::getSkinCellIds::Response &res);

    bool enableEventGeneratorCallback(
            tum_ics_skin_msgs_events::enableEventGenerator::Request &req,
            tum_ics_skin_msgs_events::enableEventGenerator::Response &res);

    bool setCmdCallback(
            tum_ics_skin_msgs::setCmd::Request &req,
            tum_ics_skin_msgs::setCmd::Response &res);

private:

private slots:
    void newNeighborList(QVector<Skin::Cell::Neighbors>);
    void newDataBunch(QVector<Skin::Cell::Data>);
    void newEventDataPacketBunch(QVector<Skin::Implementation::Packet>);

public slots:

signals:


};

}



#endif // TUM_ICS_SKIN_DRIVER_EVENTS_ROS_SKIN_H
