/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINEVENTS_PACKETSV2_EVENTS_ABSDIFFDATA_H
#define SKINEVENTS_PACKETSV2_EVENTS_ABSDIFFDATA_H

#include <SkinCore/Implementation/Packet.h>
#include <SkinCore/Cell/Events/Thresholds.h>

namespace Skin{
namespace Implementation{
namespace Packets {
namespace Version2{
namespace Events{

class RawAbsDiffData;

class AbsDiffData
{
public:
    static double convToProx(unsigned int rawProxDiff);
    static double convToForce(unsigned int rawForceDiff);
    static double convToAcc(unsigned int rawAccDiff);
    static double convToTemp1(unsigned int rawTemp1Diff);
    static double convToTemp2(unsigned int rawTemp2Diff);

    static Skin::Cell::Events::Thresholds& convToThresholds(
            Skin::Cell::Events::Thresholds& t,
            const AbsDiffData& d);

    static AbsDiffData& convToAbsDiffData(AbsDiffData& d, const Skin::Cell::Events::Thresholds& t);
    static AbsDiffData& convToAbsDiffData(AbsDiffData& d, const RawAbsDiffData& rd);

    double prox;
    double force[3];
    double acc[3];
    double temp[2];

private:

public:
    AbsDiffData(double prox = 0,
                double force1 = 0,
                double force2 = 0,
                double force3 = 0,
                double acc1 = 0,
                double acc2 = 0,
                double acc3 = 0,
                double temp1 = 0,
                double temp2 = 0);


    AbsDiffData(const AbsDiffData& d);
    AbsDiffData(const RawAbsDiffData& d);
    AbsDiffData(const Skin::Cell::Events::Thresholds& t);
    AbsDiffData(const Packet& p);

    Skin::Cell::Events::Thresholds toThresholds() const;

    void abs();

    QString toString() const;
};

}}}}}

#endif // SKINEVENTS_PACKETSV2_EVENTS_ABSDIFFDATA_H
