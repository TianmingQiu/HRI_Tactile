#ifndef TUM_ICS_SKIN_FULL_CONFIG_CALIB_MAINWINDOW_H
#define TUM_ICS_SKIN_FULL_CONFIG_CALIB_MAINWINDOW_H

#include <QMainWindow>
#include <QCloseEvent>

#include <tum_ics_skin_full_config/CalibWidget.h>

namespace tum_ics_skin_full_config
{

namespace Ui {
class CalibMainWindow;
}

class CalibMainWindow : public QMainWindow
{
    Q_OBJECT

private:
    Ui::CalibMainWindow *ui;

    CalibWidget* m_wCalib;

    bool m_closed;

public:
    explicit CalibMainWindow(QWidget *parent = 0);
    ~CalibMainWindow();

    void setDefaultPath(const QString& path=".");

    void update();


    bool isClosed() const;

private:
    void showEvent(QShowEvent* e);
    void hideEvent(QHideEvent* e);
    void closeEvent(QCloseEvent* e);

};

}

#endif // TUM_ICS_SKIN_FULL_CONFIG_CALIB_MAINWINDOW_H
