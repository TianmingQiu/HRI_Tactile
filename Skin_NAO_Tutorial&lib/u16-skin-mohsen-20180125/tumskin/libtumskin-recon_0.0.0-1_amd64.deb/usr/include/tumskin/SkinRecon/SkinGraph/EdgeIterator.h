/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINRECON_SKINGRAPH_EDGEITERATOR_H
#define SKINRECON_SKINGRAPH_EDGEITERATOR_H

#include <SkinRecon/SkinGraph/Graph.h>

namespace Skin{
namespace Reconstruction{
namespace SkinGraph{

class EdgeIterator
{

private:
    Graph& m_g;

    boost::graph_traits<BGLGraph>::edge_iterator m_ei, m_ei_start, m_ei_end;

public:
    // ATTENTION: don't change the graph as long as iteration is performed
    // start & end are only updated at creation or assignment

    EdgeIterator(Graph& g);
    ~EdgeIterator();

    void toFront();
    void toBack();

    bool hasNext() const;
    bool hasPrevious() const;

    EdgeProperties& peekNext() const;
    EdgeProperties& peekPrevious() const;

    EdgeProperties& next();
    EdgeProperties& previous();

    EdgeProperties& value();
    const EdgeProperties& value() const;

private:
    void init();

};


}
}
}



#endif // SKINRECON_SKINGRAPH_EDGEITERATOR_H
