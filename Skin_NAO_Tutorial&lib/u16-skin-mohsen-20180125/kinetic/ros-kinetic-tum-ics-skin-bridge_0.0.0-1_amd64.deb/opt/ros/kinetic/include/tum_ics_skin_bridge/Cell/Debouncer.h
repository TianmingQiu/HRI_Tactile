#ifndef TUM_ICS_SKIN_CELL_DEBOUNCER_H
#define TUM_ICS_SKIN_CELL_DEBOUNCER_H

#include <ros/ros.h>
#include <tum_ics_skin_common/Cell/Data.h>
#include <tum_ics_skin_common/CallbackProvider.h>

#include <QString>
#include <QVector>
#include <QMap>
#include <QMutex>
#include <QElapsedTimer>

namespace tum_ics_skin_bridge{
namespace Cell{

class Debouncer :
        public tum_ics_skin_common::CallbackProvider<QVector< ::Skin::Cell::Data> >
{
public:

private:
    enum State
    {
        Idle,
        Change,
        ChangeBreak,
        Dead,
    };

    QVector<int> m_ids;
    QMap<int,int> m_cellIdMap;              // map: cellId -> ind;
    QMutex m_mutex;

    QVector<State> m_state;
    QVector<qint64> m_time;
    QVector<bool> m_selected;
    QVector<bool> m_changed;

    QElapsedTimer m_timer;

    int m_t_debouce;
    int m_t_dead;

    double m_forceThresh;
    double m_proxThresh;

    bool m_useGlobalCellIds;

public:
    // default cell id filter is all cell ids of subscribed topic
    Debouncer(double forceThresh=0.7,
              double proxThresh=0.1,
              int t_debounce=32,
              int t_dead = 1000);

    ~Debouncer();

    void setConfig(double forceThresh=0.7,
                   double proxThresh=0.1,
                   int t_debounce=32,
                   int t_dead = 1000);


    /*!
     * \brief Use global cell ids.
     *
     * All ids are treated as global cell ids.
     *
     * Global cell id: cell id + (patch id - 1) * 1000.
     */
    void useGlobalCellIds(bool enabled);



    void create(const QVector<int>& ids);

    // reset the selected state of all cells
    void reset();

    // cell has been selected
    bool isSelected(int cellId);
    QVector<bool> selected();
    QVector<bool> changed();

    const QVector<int>& cellIds() const;
    int index(int cellId) const;

    void update(const QVector< ::Skin::Cell::Data>& d);

private:
    void callback(const QVector<Skin::Cell::Data> &);

};


}}

#endif // TUM_ICS_SKIN_CELL_DEBOUNCER_H
