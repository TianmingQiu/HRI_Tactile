/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKIN_VIZV2_H
#define SKIN_VIZV2_H

#include <QGLWidget>
#include <QtOpenGL>
#include <QDebug>
#include <QTimer>
#include <QVector>
#include <QMap>

#include <GL/glu.h>

#include <Eigen/Eigen>

#include <SkinCore/Implementation/Packets/Version2/Packets.h>
#include <SkinCore/Cell/Data.h>
#include <SkinCore/Cell/LedColor.h>
#include <SkinCore/Config/Config.h>

namespace Skin{
namespace Visualization{
namespace Version2{

using namespace Cell;


// NOTE: you need to call "glutInit(&argc,argv);" in the main.cpp
class Viz : public QGLWidget
{
    Q_OBJECT


private:

    int m_numOfCells;

    double m_userScale;
    double m_userTranslation[3];
    double m_userRotation[3];

    bool m_launched;

    QPoint m_lastMousePos;

    QMap<int,int> m_cellIdMap;                          // map cell id to index of cells vector

    QVector<Data>        m_dataList;                    // unordered list of skin cell raw data
    QVector<LedColor>    m_ledColorList;                // unordered list of led colors

    Config                 m_skin;                        // configuration of patches


    QTimer* m_updateTimer;                              // update timer for GL Update

    double m_mouseWheelSpeed;

public:
    Viz(QWidget* parent = 0);
    ~Viz();

    void setMouseWheelSpeed(double speed = 0.1);

protected:

    void initializeGL();
    void paintGL();
    void resizeGL(int width, int height);


private:
    void mousePressEvent(QMouseEvent* e);
    void mouseMoveEvent(QMouseEvent* e);
    void wheelEvent(QWheelEvent* e);
    void mouseDoubleClickEvent(QMouseEvent* e);

    // KEY EVENTS
    void keyPressEvent(QKeyEvent* e);


    void showEvent(QShowEvent * e);
    void hideEvent(QHideEvent * e);

    void closeEvent(QCloseEvent* e);


public slots:
    void show();
    void hide();

    void newNumberOfCells(int num);
    void newDataBunch(QVector<Skin::Cell::Data> data);
    void newSkinConfig(Skin::Config skin);

    void changeLedColor(Skin::Cell::LedColor color, int id=Implementation::Packets::Version2::ID_ALL);

private slots:
    void update();  // update GL

signals:
    void visibilityChanged(bool visible);

};


}
}
}


#endif // SKIN_VIZV2_H
