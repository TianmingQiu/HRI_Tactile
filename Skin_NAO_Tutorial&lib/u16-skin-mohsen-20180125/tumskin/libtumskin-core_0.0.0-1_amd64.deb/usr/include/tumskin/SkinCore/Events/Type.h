#ifndef SKINCORE_EVENTS_TYPE_H
#define SKINCORE_EVENTS_TYPE_H

#include <QMetaType>
#include <QString>
#include <QVector>
#include <QTextStream>

namespace Skin{
namespace Events{


class Type
{

private:
    int m_id;
    QString m_name;

public:
    Type(int id = 0, const QString& name = "");
    Type(const Type& t);

    // only id is important
    bool operator== (const Type& other) const;
    bool operator!= (const Type& other) const;

    // for QMap
    bool operator< (const Type& other) const;

    operator const int&() const;

    const QString& name() const;
    int id() const;

    QString toString() const;
};


}}

QTextStream& operator << (QTextStream& s, const Skin::Events::Type& t);
QTextStream& operator >> (QTextStream& s, Skin::Events::Type& t);

Q_DECLARE_METATYPE(Skin::Events::Type)
Q_DECLARE_METATYPE(QVector<Skin::Events::Type>)

#endif // SKINCORE_EVENTS_TYPE_H
