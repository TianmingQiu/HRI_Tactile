#ifndef TUM_ICS_SKIN_DESCR_PCL_PATCH_H
#define TUM_ICS_SKIN_DESCR_PCL_PATCH_H

#include <tum_ics_skin_descr/Patch/TfMarkerDataPatch.h>
#include <tum_ics_skin_bridge/Cell/ActiveCellConfig.h>

#include <pcl_ros/point_cloud.h>
#include <pcl/point_types.h>

#include <tf/transform_listener.h>
#include <tum_ics_tfs/TfContainer.h>

namespace tum_ics_skin_descr{

class PclPatch
{
public:
    typedef pcl::PointCloud<pcl::PointXYZRGB> PointCloud;
    typedef PointCloud::Ptr PclMessage;

    static void proxToColor(QVector<int>& color, double val);
    static void forceToColor(QVector<int>& color, double val);
    static void tempToColor(QVector<int>& color, double val);

    static void enforceColorType(QVector<int>& color);

private:
    typedef tum_ics_skin_bridge::Cell::ActiveCellConfig ActiveCellConfig;
    typedef tum_ics_skin_descr::Patch::TfMarkerDataPatch Patch;
    typedef tum_ics_tfs::TfContainer TfContainer;

    ros::NodeHandle m_node;
    tf::TransformListener m_tfListener;
    TfContainer m_tfc_patch_base;

    Patch* m_patch;

    QVector<pcl::PointXYZRGB> m_pcl;
    PointCloud::Ptr m_msg;

    QVector<Eigen::Vector3d> m_cellPos;

public:
    /*!
     * \brief Defaut constructor.
     *
     * Per default uses the ActiveCellConfig of the given patch.
     */
    PclPatch(Patch* patch, const QString& baseFrame = "world");
    ~PclPatch();

    /*!
     * \brief Set the base frame to for the pcl points.
     */
    void setBaseFrame(const QString& baseFrame);

    /*!
     * \brief Update the pose of the patch and create pcl msgs
     */
    bool update();

    Patch* patch();

    const QVector<pcl::PointXYZRGB>& pcl() const;
    const PclMessage& msg(const ros::Time& t = ros::Time::now());

    const QString& baseFrame() const;

private:
    pcl::PointXYZRGB createPclPoint(const Eigen::Vector3d& pos,
                                    const QVector<int>& color);

    void getTf();


};

}

#endif // TUM_ICS_SKIN_DESCR_PCL_PATCH_H
