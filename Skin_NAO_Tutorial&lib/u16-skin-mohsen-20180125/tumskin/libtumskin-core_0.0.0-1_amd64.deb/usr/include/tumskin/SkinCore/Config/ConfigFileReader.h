/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKIN_CONFIGFILEREADER_H
#define SKIN_CONFIGFILEREADER_H

#include <QVector>
#include <QMetaType>
#include <QMap>

#include <QFile>
#include <QDir>
#include <QXmlStreamReader>


#include <Eigen/Eigen>

#include <SkinCore/Cell/Neighbors.h>
#include <SkinCore/Cell/Organization.h>


namespace Skin{

using namespace Cell;

class ConfigFileReader
{
protected:
    struct MatrixElement
    {
        int row;
        int col;
        double value;
    };

    struct Neighbor
    {
        int port;
        int id;
    };


protected:
    bool m_error;
    QString m_errorString;
    QXmlStreamReader m_xml;
    QVector<Organization> m_cells;

public:
    ConfigFileReader(const QString& filename);
    ~ConfigFileReader();

    const QVector<Organization>& cells() const;

    bool error() const;
    const QString& errorString() const;


protected:
    ConfigFileReader();

protected:
    void read(const QString& filename);

    Organization readCell(bool* ok=0);

    int readRootCellId(bool* ok=0);
    Neighbors readNeighbors(bool* ok=0);
    Neighbor readNeighbor(bool* ok=0);

    Eigen::Vector3d readPos(bool* ok=0);
    Eigen::Matrix3d readRot(bool* ok=0);

    Eigen::MatrixXd readMatrixXd(bool* ok=0);
    MatrixElement readMatrixElement(bool* ok=0);

};

}


#endif // SKIN_CONFIGFILEREADER_H
