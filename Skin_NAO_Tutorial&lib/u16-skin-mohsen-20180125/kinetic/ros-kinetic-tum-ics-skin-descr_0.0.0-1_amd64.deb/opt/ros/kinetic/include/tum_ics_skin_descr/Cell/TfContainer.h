#ifndef TUM_ICS_SKIN_DESCR_CELL_TF_CONTAINER_H
#define TUM_ICS_SKIN_DESCR_CELL_TF_CONTAINER_H

#include <tum_ics_skin_descr/Cell/TfBranch.h>
#include <tum_ics_tfs/TfContainer.h>

#include <SkinCore/Cell/Organization.h>


namespace tum_ics_skin_descr{
namespace Cell{

class TfContainer : public tum_ics_tfs::TfContainer
{
public:
    static TfContainer Default();

    static QVector<tum_ics_skin_descr::Cell::TfBranch> toTfBranchVector(
            const QVector<TfContainer>& tfcs);

private:
    typedef ::Skin::Cell::Organization Organization;
    int m_cellId;

public:
    TfContainer(int cellId,
                const QString& name,
                const QString& baseFrame,
                const QString& nameSpace);

    TfContainer(int cellId,
                const QString& name,
                const QString& baseFrame,
                const tf::Transform& tf     = tf::Transform::getIdentity(),
                const QString& nameSpace    = "Default");

    TfContainer(int cellId,
                const QString& name,
                const QString& baseFrame,
                const Eigen::Affine3d& tf,
                const QString& nameSpace    = "Default");

    TfContainer(int cellId,
                const tum_ics_tfs::TfBranch& tfBranch,
                const tf::Transform& tf);

    TfContainer(int cellId,
                const tum_ics_tfs::TfBranch& tfBranch,
                const Eigen::Affine3d& tf);

    TfContainer(int cellId,
                const tum_ics_tfs::TfContainer& tfc);


    TfContainer(const tum_ics_skin_descr::Cell::TfBranch& tfBranch =
            tum_ics_skin_descr::Cell::TfBranch::Default(),
                const tf::Transform& tf =
            tf::Transform::getIdentity());

    TfContainer(const tum_ics_skin_descr::Cell::TfBranch& tfBranch,
                const Eigen::Affine3d& tf);

    TfContainer(const TfContainer& tfc);


    ~TfContainer();

    void setCellId(int cellId);

    // set transformations with respect to base frame
    void setPose(const Organization& o);

    // to give access again to base class as this func. is overloaded here
    using tum_ics_tfs::TfContainer::setPose;


    int cellId() const;
    operator tum_ics_skin_descr::Cell::TfBranch () const;

    // loads tf into given Organization if id matches
    Organization toOrganization(bool* ok=0) const;
    Organization& toOrganization(Organization& o, bool* ok=0) const;

    QString toString() const;

private:

};

}}

#endif // TUM_ICS_SKIN_DESCR_CELL_TF_CONTAINER_H
