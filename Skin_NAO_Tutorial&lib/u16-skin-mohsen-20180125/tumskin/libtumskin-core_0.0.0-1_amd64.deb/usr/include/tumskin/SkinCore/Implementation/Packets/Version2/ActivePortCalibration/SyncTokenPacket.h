/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINIMPLPKTS_SYNCTOKENPACKETV2_H
#define SKINIMPLPKTS_SYNCTOKENPACKETV2_H

#include <SkinCore/Implementation/Packet.h>

namespace Skin{
namespace Implementation{
namespace Packets {
namespace Version2{
namespace ActivePortCalibration{

class SyncTokenPacket : public Packet
{
public:
    static const int PKT_SIZE = 3;
    static bool check(const Packet& p);

public:
    SyncTokenPacket();
    SyncTokenPacket(const QVector<Endpoint>& dest);

    bool check() const;

private:
    void init();

};

}}}}}





#endif // SKINIMPLPKTS_SYNCTOKENPACKETV2_H
