#ifndef TUM_ICS_SKIN_CELL_DATA_SUBSCRIBER_H
#define TUM_ICS_SKIN_CELL_DATA_SUBSCRIBER_H

#include <ros/ros.h>
#include <tum_ics_skin_common/Cell/Data.h>
#include <tum_ics_skin_msgs/SkinCellDataArray.h>

#include <tum_ics_skin_common/CallbackCaller.h>

#include <QString>
#include <QVector>
#include <QMap>
#include <QMutex>

namespace tum_ics_skin_bridge{
namespace Cell{

class DataSubscriber :
        public tum_ics_skin_common::CallbackCaller<QVector< ::Skin::Cell::Data> >
{
private:
    typedef QVector< ::Skin::Cell::Data> DataBunch;

    ros::NodeHandle m_node;
    ros::Subscriber m_sub;

    QString m_topicName;
    int m_patchId;

    bool m_enabled;

public:
    // default cell id filter is all cell ids of subscribed topic
    DataSubscriber(const QString& topicName = "", int patchId=0);
    ~DataSubscriber();

    // default: empty ids = all cells
    // fails if already enabled
    bool create(const QString& topicName, int patchId=0);

    // without create: use subscriber with default settings
    void enable();
    void disable();

    // failes if not created
    void setEnabled(bool enable);

    bool isEnabled() const;

    const QString& topicName() const;
    int patchId() const;

private:
    void skinCellDataArrayCallback(const tum_ics_skin_msgs::SkinCellDataArray&);

};


}}

#endif // TUM_ICS_SKIN_CELL_DATA_SUBSCRIBER_H
