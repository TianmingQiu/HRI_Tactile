#ifndef TUM_ICS_SKIN_CELL_DATA_BANK_H
#define TUM_ICS_SKIN_CELL_DATA_BANK_H

#include <ros/ros.h>
#include <tum_ics_skin_common/Cell/Data.h>
#include <tum_ics_skin_common/CallbackProvider.h>

#include <tum_ics_skin_bridge/Cell/ActiveCellConfig.h>

#include <QString>
#include <QVector>
#include <QMap>
#include <QMutex>

namespace tum_ics_skin_bridge{
namespace Cell{

class DataBank :
        public tum_ics_skin_common::CallbackProvider<QVector< ::Skin::Cell::Data> >
{

private:
    QVector<int> m_ids;
    QVector< ::Skin::Cell::Data> m_data;    // same order as ids;
    QMap<int,int> m_cellIdMap;              // map: cellId -> ind;
    QMutex m_dataMutex;

    QVector<bool> m_dataChanged;    // flag if data has been updated since last read


    ActiveCellConfig m_config;

    QVector<bool> m_activeCell;     //!< cell is active flag
    QVector<bool> m_activeProx;     //!< prox is active flag
    QVector<bool> m_activeForce;    //!< force is active flag
    QVector<bool> m_activeTemp;     //!< temp is active flag

    int m_numOfActiveCells;
    int m_numOfActiveProx;
    int m_numOfActiveForce;
    int m_numOfActiveTemp;

public:
    // default cell id filter is all cell ids of subscribed topic
    DataBank();
    ~DataBank();

    /*!
     * \brief Set the active cell config to use.
     */
    void setConfig(const ActiveCellConfig& config);


    // default: empty = all cells, create memory on first data arrival
    // fails if already enabled
    void create(const QVector<int>& ids = QVector<int>());

    void update(const QVector< ::Skin::Cell::Data>& d);


    ::Skin::Cell::Data dataFromInd(int cellInd);    // resets updated state on call
    ::Skin::Cell::Data dataFromId(int cellId);      // resets updated state on call

    ::Skin::Cell::Data data(int cellInd);       // resets updated state on call

    QVector< ::Skin::Cell::Data> data();        // resets updated state on call
    QVector< ::Skin::Cell::Data> updatedData(); // resets updated states on call


    const ActiveCellConfig& config() const;

    int numberOfActiveCells() const;
    int numberOfActiveProxCells() const;
    int numberOfActiveForceCells() const;
    int numberOfActiveTempCells() const;

private:
    void callback(const QVector<Skin::Cell::Data> &);

    void updateActiveFlags(const ::Skin::Cell::Data& d, int ind);

};


}}

#endif // TUM_ICS_SKIN_CELL_DATA_BANK_H
