#ifndef TUM_ICS_DESCR_CONFIGFILEWRITER_H
#define TUM_ICS_DESCR_CONFIGFILEWRITER_H

#include <SkinCore/Cell/Organization.h>
#include <SkinCore/Config/Patch.h>
#include <SkinCore/Config/ConfigFileWriter.h>

#include <tum_ics_skin_descr/Patch/Extrinsics.h>
#include <tum_ics_skin_descr/Patch/DriverSettings.h>

namespace tum_ics_skin_descr{

class ConfigFileWriter : public ::Skin::ConfigFileWriter
{
private:
    typedef ::Skin::Cell::Organization Organization;
    typedef ::Skin::Patch Patch;
    typedef tum_ics_skin_descr::Patch::Extrinsics PatchExtrinsics;
    typedef tum_ics_skin_descr::Patch::DriverSettings PatchDriverSettings;

public:
    ConfigFileWriter(const QString& filename,
                     const QVector<Organization>& cells,
                     const QVector<PatchExtrinsics>& pe=QVector<PatchExtrinsics>());

    // if PatchExtrinsics are undefined then they are not written to file
    ConfigFileWriter(const QString& filename,
                     const Patch& p,
                     const PatchDriverSettings& pds = PatchDriverSettings::Undefined(),
                     const PatchExtrinsics& pe = PatchExtrinsics::Undefined());

    ConfigFileWriter(const QString& filename,
                     const QVector<Organization>& cells,
                     const QVector<PatchDriverSettings>& pds,
                     const QVector<PatchExtrinsics>& pe=QVector<PatchExtrinsics>());

    ~ConfigFileWriter();

private:
    void write(const QString& filename,
               const QVector<Organization>& cells,
               const QVector<PatchDriverSettings>& pds,
               const QVector<PatchExtrinsics>& pe);

    void writePatchDriverSettings(const PatchDriverSettings& pds);
    void writePatchExtrinsics(const PatchExtrinsics& pe);

    void writeTf(const QString& name, const Eigen::Affine3d&);

};

}

#endif // TUM_ICS_DESCR_CONFIGFILEWRITER_H
