#ifndef SKINMANAGERS_APPLICATION_BASE_LEDCMDHANDLER_H
#define SKINMANAGERS_APPLICATION_BASE_LEDCMDHANDLER_H

#include <SkinManagers/Application/ConsoleCmdHandler.h>
#include <SkinManagers/Application/Base/Application.h>

namespace Skin {
namespace Managers{
namespace Application{
namespace Base{

class LedCmdHandler : public ConsoleCmdHandler
{
private:
    Skin::Managers::Application::Base::Application* m_app;
public:
    LedCmdHandler(Skin::Managers::Application::Base::Application* app);
    virtual bool handleMessage(const QString &s);
    virtual QString cmdDescription() const;
};


}}}}

#endif // SKINMANAGERS_APPLICATION_BASE_LEDCMDHANDLER_H
