#ifndef SKINEVENTS_EVALUATIONS_EVALUATION_DATA_H
#define SKINEVENTS_EVALUATIONS_EVALUATION_DATA_H

#include <QVector>

namespace Skin{
namespace Events{
namespace Evaluations{

class EvaluationData
{
public:
    QVector<int> dataPktCnt;
    QVector<int> eventPktCnt;
    QVector<QVector<int> > eventCnt;
    QVector<QVector<int> > eventsPerPktCnt; // ind 0 <=> 1 event per packet

    int totalDataPktCnt;
    int totalEventPktCnt;
    int totalEventCnt;

private:
    int m_numOfCells;
    int m_numOfEventTypes;

public:
    EvaluationData(int numOfCells=0, int numOfEventTypes=0);
    EvaluationData(const EvaluationData& d);
    ~EvaluationData();

    EvaluationData& operator -=(const EvaluationData& other);

    void resize(int numOfCells, int numOfEventTypes);

    void reset();

    bool isEmpty() const;
    int numberOfCells() const;
    int numberOfEventTypes() const;

};


}}}


#endif // SKINEVENTS_EVALUATIONS_EVALUATION_DATA_H
