#ifndef TUM_ICS_SKIN_FULL_CONFIG_CALIB_AUTO_CONFIG_WIDGET_H
#define TUM_ICS_SKIN_FULL_CONFIG_CALIB_AUTO_CONFIG_WIDGET_H

#include <QWidget>
#include <QStatusBar>
#include <QComboBox>
#include <QLabel>
#include <QPushButton>
#include <QSpinBox>

#include <QElapsedTimer>

//This definition is needed with libboost 1.58
#ifndef Q_MOC_RUN
#include <tum_ics_skin_auto_config/ConfigGenerator.h>
#include <tum_ics_skin_descr/Patch/Extrinsics.h>

#include <tum_ics_skin_bridge/Cell/DataConnectionBanked.h>
#include <tum_ics_skin_bridge/Cell/LedColorClient.h>
#include <tum_ics_skin_bridge/Cell/IdsClient.h>

#include <tum_ics_skin_bridge/Cell/Debouncer.h>
#endif



namespace tum_ics_skin_full_config
{

namespace Ui {
class CalibAutoConfigWidget;
}

class CalibAutoConfigWidget : public QWidget
{
    Q_OBJECT

private:
    typedef tum_ics_skin_auto_config::ConfigGenerator ConfigGenerator;
    typedef ::Skin::Config SkinConfig;
    typedef tum_ics_skin_descr::Patch::Extrinsics PatchExtrinsics;
    typedef tum_ics_skin_bridge::Cell::DataConnectionBanked DataConn;
    typedef tum_ics_skin_bridge::Cell::LedColorClient ColorConn;
    typedef tum_ics_skin_bridge::Cell::IdsClient IdsConn;

    enum State
    {
        ReconIdle,
        ReconStart,
        ReconRunning,
        ReconPoseComplete,
        ReconNextPose,
        ReconComplete,
        ReconReset,
        SegStart,
        SegRunning,
        SegStop,
    };

    Ui::CalibAutoConfigWidget *ui;
    QStatusBar* m_sb;

    QComboBox* m_cbPrefix;
    QSpinBox* m_sbNumOfPoses;
    QPushButton* m_pbCapture;
    QLabel* m_lCurrPose;
    QPushButton* m_pbSave;
    QPushButton* m_pbLoad;

    QPushButton* m_pbSeg;
    QPushButton* m_pbDelete;
    QComboBox* m_cbSeg;

    ConfigGenerator m_configGen;
    SkinConfig m_config;
    State m_state;
    bool m_updateGui;
    QString m_defaultPath;

    DataConn m_dataConn;
    ColorConn m_colorConn;
    IdsConn m_idsConn;

    QVector<int> m_ids;
    QList<int> m_segs;

    tum_ics_skin_bridge::Cell::Debouncer m_debouncer;

    QElapsedTimer m_resetDelayTimer;

    int m_currSeg;

    Skin::SegmentMap m_map;

    QVector<QString> m_prefixes;
    QVector<PatchExtrinsics> m_patchExtrinsics;

public:
    explicit CalibAutoConfigWidget(QWidget *parent = 0);
    ~CalibAutoConfigWidget();

    bool init(QStatusBar* sb, const QString& defaultPath = ".");
    void setDefaultPath(const QString& path = ".");

    // call this function in the main while loop
    void update();

    QString prefix() const;
    const QVector<QString>& prefixes() const;

private:
    void updateGui();

    void updateLedColors();

    int currSeg();

    void status(const QString& msg);
    void warning(const QString& msg);
    void error(const QString& msg);

public slots:
    // sets the skin driver prefix and reset to idle mode
    void newSkinDriverPrefix(QString prefix);

private slots:
    void pbCaptureClicked();
    void pbSaveClicked();
    void pbLoadClicked();

    void cbSeg_currentIndexChanged(int index);
    void pbSegClicked();
    void pbDeleteClicked();

signals:
    void newSkinConfig(::Skin::Config config,
                       QString prefix,
                       QVector<tum_ics_skin_descr::Patch::Extrinsics > pe);

    // lock other GUIs
    void lockGui(bool enable);


};

}

#endif // TUM_ICS_SKIN_FULL_CONFIG_CALIB_AUTO_CONFIG_WIDGET_H
