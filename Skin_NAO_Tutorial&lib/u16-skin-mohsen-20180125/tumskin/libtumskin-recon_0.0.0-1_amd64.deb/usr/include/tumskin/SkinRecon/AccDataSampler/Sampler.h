/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINRECON_ACCDATASAMPLER_SAMPLER_H
#define SKINRECON_ACCDATASAMPLER_SAMPLER_H

#include <QObject>
#include <QVector>
#include <QMap>
#include <QElapsedTimer>

#include <Eigen/Eigen>

#include <SkinCore/Cell/Data.h>
#include <SkinRecon/AccDataSampler/Data.h>

namespace Skin{
namespace Reconstruction{
namespace AccDataSampler{

class Sampler : public QObject
{
    Q_OBJECT

private:
    QElapsedTimer m_timer;

    Data m_samples;

    int m_numOfPoses;
    int m_numOfCells;
    int m_numOfSamples;

    int m_pose;     // pose index

    bool m_started;
    bool m_samplingStarted;
    bool m_hasSamples;

public:
    Sampler(QObject* parent=0);
    ~Sampler();

private slots:
    void timeout();

public slots:
    void start(int numOfCells, int numOfPoses=1, int samples=16);
    void nextPose();
    void stop();

    void newDataBunch(QVector<Skin::Cell::Data> data);

signals:
    void started();
    void stopped();

    void finished();
    void samplingFailed();
    void poseFinished();

    void sampledData(Skin::Reconstruction::AccDataSampler::Data d);

};


}
}
}



#endif // SKINRECON_ACCDATASAMPLER_SAMPLER_H
