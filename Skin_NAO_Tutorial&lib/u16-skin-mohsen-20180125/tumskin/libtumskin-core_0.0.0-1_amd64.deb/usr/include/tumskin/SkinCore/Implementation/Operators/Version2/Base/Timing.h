/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINIMPLOPS_BASE_TIMING_H
#define SKINIMPLOPS_BASE_TIMING_H

#include <QVector>

namespace Skin{
namespace Implementation{
namespace Operators{
namespace Version2{
namespace Base{

// ALL timings are in micro seconds (us)

class Timing
{
public:
    static const QVector<int> StdTimingList;
    static const Timing StdTiming;

public:
    // timings in us
    int waitResetOff;
    int waitBootloaderStartup;
    int waitBootloaderNetConfig;
    int waitSyncTokenVanishing;
    int waitActivePortRxQuerrySetup;
    int waitActivePortQuerryTx;
    int waitActivePortRxReplySetup;
    int waitActivePortReplyTx;
    int waitMasterPortRxSetup;
    int waitMasterPortSetup;
    int waitIdDistributionAccomplishedBroadcast;
    int waitNearestNeighborExplorationMyIdRxSetup;
    int waitNearestNeighborExplorationMyIdTx;
    int timeoutSyncToken;
    int timeoutIdTokenConfirmation;
    int timeoutIdTokenReturn;
    int timeoutNearestNeighborListWait;

private:

public:
    Timing(const Timing& t = StdTiming);
    Timing(const QVector<int>& list);

    QVector<int> timingList() const;

private:
    void init(const QVector<int>& list = QVector<int>());



};


}
}
}
}
}

#endif // SKINIMPLOPS_BASE_TIMING_H
