/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINIMPL_INTELHEXFILEREADER_H
#define SKINIMPL_INTELHEXFILEREADER_H

#include <QString>
#include <QVector>

#include "DataBlock.h"


namespace Skin{
namespace Implementation{

class IntelHexFileReader
{

private:
    QString m_errorString;
    QVector<DataBlock> m_blocks;

public:
    IntelHexFileReader();
    IntelHexFileReader(const QString& filename,
                       int startWordAddr = 0x0,
                       int endWordAddr = 0xFFFFFF);

    ~IntelHexFileReader();

    bool hasValidData() const;

    const QVector<DataBlock>& dataBlocks() const;

    const QString& errorString() const;


private:
    void parseFile(const QString& filename,
                   int startWordAddr = 0x0,
                   int endWordAddr = 0xFFFFFF);
};


}
}


#endif // SKINIMPL_INTELHEXFILEREADER_H
