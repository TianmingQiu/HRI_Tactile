/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINIMPL_FTDINODE_H
#define SKINIMPL_FTDINODE_H

#include <QMetaType>
#include <QVector>

namespace Skin{
namespace Implementation{

class FtdiNode
{
public:
    static const QString StdDescriptor; // desc: SkinCellAdapter

    static const FtdiNode Undefined;    // undefined, empty
    static const FtdiNode StdNode;      // first valid node

    // some predefined nodes
    //  [0]:    sn: FTYPY7DO, desc: SkinCellAdapter, baudrate: 4000000
    //  [1]:    sn: FTYPY7N3, desc: SkinCellAdapter, baudrate: 4000000
    //  [2]:    sn: FTYPYBP7, desc: SkinCellAdapter, baudrate: 4000000
    static const QVector<FtdiNode> StdNodes;

    static const QVector<FtdiNode> AvailableNodes;  // all available nodes


private:
    QString m_serialNumber;
    QString m_description;
    int m_baudrate;

public:
    FtdiNode(const FtdiNode& s = Undefined);
    FtdiNode(const QString& sn,
                 const QString& desc=StdDescriptor,
                 int baudrate=4000000);

    ~FtdiNode();

    bool operator== (const FtdiNode& other) const;
    bool operator!= (const FtdiNode& other) const;

    const QString& serialNumber() const;
    const QString& description() const;
    int baudrate() const;

    QString toString() const;

};


}
}


#endif // SKINIMPL_FTDINODE_H
