#ifndef PATCHEXTRINSICSDIALOG_H
#define PATCHEXTRINSICSDIALOG_H

#include <QDialog>
#include <tum_ics_skin_descr/Patch/Extrinsics.h>

namespace tum_ics_skin_descr{
namespace Patch{

namespace Ui {
class PatchExtrinsicsDialog;
}

class ExtrinsicsDialog : public QDialog
{
    Q_OBJECT

public:
    static Extrinsics getExtrinsics(const Extrinsics& e = Extrinsics::Default(),
                                    QWidget *parent = 0);

private:
    Ui::PatchExtrinsicsDialog *m_ui;

    Extrinsics m_extrinsics;
    
public:
    explicit ExtrinsicsDialog(const Extrinsics& e = Extrinsics::Default(),
                              QWidget *parent = 0);
    ~ExtrinsicsDialog();

    void update();
    const Extrinsics& extrinsics();
    
private:


};

}}

#endif // PATCHEXTRINSICSDIALOG_H
