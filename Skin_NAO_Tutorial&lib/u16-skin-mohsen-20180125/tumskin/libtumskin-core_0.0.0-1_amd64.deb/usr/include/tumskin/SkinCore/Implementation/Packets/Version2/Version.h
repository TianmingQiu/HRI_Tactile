/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINIMPLPKTS_BOOTLOADER_VERSIONV2_H
#define SKINIMPLPKTS_BOOTLOADER_VERSIONV2_H

#include <SkinCore/Implementation/Packet.h>
#include <SkinCore/Implementation/Packets/Version2/PacketDefinitions.h>


namespace Skin{
namespace Implementation{
namespace Packets {
namespace Version2{

class Version
{
public:
    static const Version defaultVersion;
    static const Version highestVersion;

public:
    unsigned char mcuFamilyCode;                // must be 0x50
    unsigned char mcuDeviceId;                  // must be 0x4C
    unsigned char hardwareRevision;             // must be 0x01 or 0xFF (FF allows to flash anyway)
    unsigned char applicationVersion;           // can be anything


private:


public:
    Version();
    Version(const Version& v);
    Version(char mcuFamilyCode,
            char mcuDeviceId,
            char hardwareRevision,
            char applicationVersion);


    QString toString() const;
};

}}}}

#endif // SKINIMPLPKTS_BOOTLOADER_VERSIONV2_H
