/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINIMPLPKTS_MEMIDPACKETV2_H
#define SKINIMPLPKTS_MEMIDPACKETV2_H

#include <SkinCore/Implementation/Packet.h>

namespace Skin{
namespace Implementation{
namespace Packets {
namespace Version2{
namespace Commands{

class MemIdPacket : public Packet
{
public:
    enum Instruction
    {
        ClearId  = 0,
        StoreId  = 1,
    };

public:
    static const int PKT_SIZE = 20;
    static void setInstr(Packet& p, Instruction instr);

public:
    MemIdPacket();
    MemIdPacket(Instruction instr=ClearId,const QVector<Endpoint>& dest=QVector<Endpoint>());

    void setInstr(Instruction instr);

private:
    void init(Instruction instr=ClearId);

};

}}}}}

#endif // SKINIMPLPKTS_MEMIDPACKETV2_H
