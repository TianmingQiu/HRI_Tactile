/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINIMPLPKTS_PACKETDEFINITIONSV2_H
#define SKINIMPLPKTS_PACKETDEFINITIONSV2_H

namespace Skin{
namespace Implementation{
namespace Packets
{
    namespace Version1
    {
        const int END_OF_FRAME              = 0xAA;

        namespace ActivePortCalibration
        {
                const char PKT_HEADER            = 0xC0;
                const char SYNC_TOKEN            = 0x50;
        }
    }

    namespace Version2
    {
        const unsigned int ID_MAX            = 0x3FFF;       //14 bit (= 16383)
        const unsigned int ID_ALL            = ID_MAX;
        const unsigned int ID_NOT_CONNECTED  = 0x0000;
        const char END_OF_FRAME              = 0xAA;

        namespace Bootloader
        {
            const char PKT_HEADER           = 0xD0;
            const char CONNECT_CMD          = 0x44;
            const char JUMP_TO_APP_CMD      = 0x46;
            const char START_WRITE_CMD      = 0x45;
            const char NEW_START_WRITE_CMD  = 0x48;
            const char WRITE_DATA_CMD       = 0x41;
            const char END_WRITE_CMD        = 0x42;
            const int VERSION_MAX           = 0x00FFFFFF;
            const char GET_VERSION_CMD      = 0x47;
            const char VERSION_TOKEN        = 0x49;
        }

        namespace ActivePortCalibration
        {
            const char PKT_HEADER            = 0xC0;
            const char SYNC_TOKEN            = 0x40;
            const char QUERY_TOKEN           = 0x41;
            const char REPLY_TOKEN           = 0x42;
        }

        namespace MasterPortCalibration
        {
            const char PKT_HEADER                   = 0xC0;
            const char MASTER_PORT_TOKEN            = 0x53;
            const char MASTER_PORT_EXPLORE_TOKEN    = 0x53;
            const char MASTER_PORT_LOAD_TOKEN       = 0x55;
        }

        namespace IdDistribution
        {
            const char PKT_HEADER            = 0xC0;
            const char ID_PKT_HEADER         = 0xC1;
            const char CONFIRMATION_TOKEN    = 0x55;
            const char CONFIRMATION_ACCEPT   = 0x0A;
            const char CONFIRMATION_REFUSE   = 0x0B;
            const char ACCOMPLISHED_TOKEN    = 0x56;
        }

        namespace NearestNeighborExploration
        {
            const char PKT_HEADER                    = 0xC0;
            const char MY_ID_PKT_HEADER              = 0xC2;
            const char NEAREST_NEIGHBOR_LIST_TOKEN   = 0x59;
        }

        namespace Commands
        {
            const char LED_PKT_HEADER               = 0xC3;
            const char LED_PWM_PKT_HEADER           = 0xCA;

            const char GET_NEIGHBOR_LIST_PKT_HEADER = 0xC6;

            const char MEM_ID_PKT_HEADER            = 0xC4;
            const char MEM_ID_SET                   = 0x37;
            const char MEM_ID_CLEAR                 = 0x3c;

            const char MEM_OFFSETS_PKT_HEADER       = 0xC5;
            const char MEM_OFFSETS_SET              = 0x37;
            const char MEM_OFFSETS_CLEAR            = 0x3c;

            const char CHG_UDR_PKT_HEADER           = 0xC8;
            const char CHG_UDR_0Hz                  = 0x00;
            const char CHG_UDR_63Hz                 = 0x01;
            const char CHG_UDR_125Hz                = 0x02;
            const char CHG_UDR_250Hz                = 0x03;

            const char COLOR_FEEDBACK_PKT_HEADER    = 0xCC;
            const char COLOR_FEEDBACK_OFF           = 0x50;
            const char COLOR_FEEDBACK_STD           = 0x51;
            const char COLOR_FEEDBACK_SETTINGS      = 0x52;

            const char PING_PKT_HEADER              = 0xCB;
        }

        namespace Events
        {
            const char EVENTS_DATA_PKT_HEADER       = 0xE2;
        }

        namespace MasterPort
        {
            const char PKT_HEADER                   = 0xC7;
            const char CMD_MEM_STORE                = 0x50;
            const char CMD_MEM_READ                 = 0x51;
            const char CMD_CURR_VAL                 = 0x52;
            const char SUB_HEADER_VALUE             = 0x53;
        }

        namespace Clock
        {
            const char CLOCK_PKT_HEADER             = 0xF1;
            const char CLOCK_RESET                  = 0x50;
            const char CLOCK_SEND_VAL               = 0x51;
            const char CLOCK_VAL                    = 0x52;
        }

        namespace Data
        {
            const char SENSOR_DATA_PKT_HEADER       = 0xFF;
        }

    }
}
}
}

#endif // SKINIMPLPKTS_PACKETDEFINITIONSV2_H
