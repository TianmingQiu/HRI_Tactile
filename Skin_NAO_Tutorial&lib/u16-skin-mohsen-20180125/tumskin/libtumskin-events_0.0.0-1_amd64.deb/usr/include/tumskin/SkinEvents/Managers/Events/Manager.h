#ifndef SKINEVENTS_MANAGERS_EVENTS_MANAGER_H
#define SKINEVENTS_MANAGERS_EVENTS_MANAGER_H

#include <QObject>
#include <QTimer>
#include <QMap>
#include <Threads/Thread.h>

#include <SkinCore/Implementation/Packet.h>
#include <SkinManagers/Application/ConsoleCmdHandler.h>
#include <SkinManagers/Application/Base/Application.h>
#include <SkinCore/Cell/Events/Thresholds.h>
#include <SkinCore/Cell/Events/Flags.h>

#include <SkinEvents/Implementation/Packets/Version2/Events/CommandPacket.h>

namespace Skin{
namespace Managers{
namespace Events{


class Manager : public QObject
{
    Q_OBJECT

public:
    // standard thresholds
    // prox     = 0.0001;   7 ticks
    // force    = 0.001;    5 ticks
    // acc      = 0.02;     10 ticks
    // temp1    = 0.5;      2 ticks
    // temp2    = 0.5;      16 ticks
    static const Skin::Cell::Events::Thresholds StdThresholds;


    // prox[0]   = 0.0001
    // force[0]  = 0.005
    // force[1]  = 0.005
    // force[2]  = 0.005
    // acc[0]    = 0.04
    // acc[1]    = 0.04
    // acc[2]    = 0.04
    // temp[0]   = 1.0
    // temp[1]   = 0.5
    static const Skin::Cell::Events::Thresholds StdThresholds2;


    typedef Skin::Implementation::Packets::Version2::Events::CommandPacket::Command Command;

    static const Command EventsOn;        // turn event generator on
    static const Command EventsOff;       // turn event generator off
    static const Command GetConfig;       // get active event config
    static const Command GetThresh;       // get thresholds
    static const Command StoreThresh;     // store current thresholds to flash mem
    static const Command LoadThresh;      // load thresholds from flash mem

    static const int BroadcastId;         // to all cells

private:
    Skin::Managers::Application::Base::Application* m_app;
    QVector<ConsoleCmdHandler*> m_consoleCmdHandlers;

    QString             m_consoleCmdDescription;

    bool m_enabled;
    bool m_showInfo;

    QVector<Threads::Thread*>       m_threads;

    QMap<int,int>                               m_cellIdMap;
    QVector<Skin::Cell::Events::Flags>          m_activeEventsFlags;
    QVector<Skin::Cell::Events::Thresholds>     m_thresholds;

public:
    explicit Manager(Skin::Managers::Application::Base::Application* app,
                     QObject *parent = 0);

    bool isEnabled() const;
    const QMap<int,int>& cellIdMap() const;
    const QVector<Skin::Cell::Events::Flags>& activeEventsFlags() const;
    const QVector<Skin::Cell::Events::Thresholds>& thresholds() const;

    const QString& consoleCmdDescription() const;
    bool handleConsoleCmd(QString);

private:
    void setActiveEvents(Skin::Cell::Events::Flags f);

public slots:
    void sendCommand(Skin::Managers::Events::Manager::Command c,int id = BroadcastId);

    // broadcast always changes all flags according to input flags
    // single id allows setting and clearing of single flags
    void changeActiveEvents(Skin::Cell::Events::Flags f, bool enable = true, int id = BroadcastId);
    void changeActiveEvents(QVector<Skin::Events::Type> events, bool enable = true, int id = BroadcastId);

    void setThresholds(Skin::Cell::Events::Thresholds t, int id = BroadcastId);

private slots:
    void newNeighborList(QVector<Skin::Cell::Neighbors>);
    void newPacketBunch(QVector<Skin::Implementation::Packet>);

signals:
    void gotActiveEvents(Skin::Cell::Events::Flags f, int id);
    void gotThresholds(Skin::Cell::Events::Thresholds t, int id);
};


}}}


#endif // SKINEVENTS_MANAGERS_EVENTS_MANAGER_H
