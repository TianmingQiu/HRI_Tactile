/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINCORE_CELL_EVENTS_FLAGS_H
#define SKINCORE_CELL_EVENTS_FLAGS_H

#include <QString>
#include <QVector>
#include <SkinCore/Events/Flags.h>
#include <SkinCore/Cell/Events/Event.h>

namespace Skin{
namespace Cell{
namespace Events{

class Flags : public Skin::Events::Flags
{
public:
    static const Flags Prox;
    static const Flags Force1;
    static const Flags Force2;
    static const Flags Force3;
    static const Flags Acc1;
    static const Flags Acc2;
    static const Flags Acc3;
    static const Flags Temp1;
    static const Flags Temp2;

    static QVector<Skin::Events::Type>& convToEvents(QVector<Skin::Events::Type>& e,
                                                     const Flags& f);
    static QVector<Skin::Events::Type> convToEvents(const Flags& f);

    static Flags& convToFlags(Flags& f, const QVector<Skin::Events::Type>& e);
    static Flags convToFlags(const QVector<Skin::Events::Type>& e);

private:
    static QVector<Flags> flagMap;
    static QVector<Skin::Events::Type> eventMap;

private:

public:
    Flags(const Skin::Events::Flags& flags = NoFlags);
    Flags(const Flags& flags);
    Flags(int mask);
    Flags(const QVector<Skin::Events::Type>& events);

    QVector<Skin::Events::Type> toEvents() const;

    QString toString() const;
};

}}}

#endif // SKINCORE_CELL_EVENTS_FLAGS_H
