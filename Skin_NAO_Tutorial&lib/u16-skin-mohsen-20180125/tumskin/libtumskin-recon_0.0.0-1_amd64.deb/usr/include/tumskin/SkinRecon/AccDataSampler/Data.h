/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINRECON_ACCDATASAMPLER_DATA_H
#define SKINRECON_ACCDATASAMPLER_DATA_H

#include <QObject>
#include <QVector>
#include <QMap>
#include <QElapsedTimer>
#include <QMetaType>

#include <Eigen/Eigen>

namespace Skin{
namespace Reconstruction{
namespace AccDataSampler{

class Data
{
private:
    static const QVector<Eigen::Vector3d> defaultVec;

private:
    int m_numOfSamples;

    QMap<int,int> m_cellIdMap;    // map cell id to index
    QVector<int> m_cellIdList;    // list of cell ids

    // 3d array:
    //      first dimension:    pose index, ordered index 0 = pose 1
    //      second dimension:   cell index, not ordered, map exits
    //      third dimension:    sample index, ordered
    QVector< QVector< QVector<Eigen::Vector3d> > > m_samples;

    // notes:
    // - the first and second dimensions of the array have defined sizes
    // - the cells are ordered according to the map for each pose
    // - the samples (third dim) are not fixed


public:
    Data();
    Data(const Data& d);
    ~Data();

    void addSample(int id, int pose, const Eigen::Vector3d& d);

    void clear();

    int numberOfPoses() const;
    int numberOfCells() const;
    int numberOfSamples() const;

    const QVector<int>& cellIdList() const;

    // vector of all samples of a pose of one cell
    const QVector<Eigen::Vector3d>& samples(int id, int pose=1) const;

    Eigen::Vector3d gravityVector(int id, int pose=1) const;

};


}
}
}

Q_DECLARE_METATYPE(Skin::Reconstruction::AccDataSampler::Data)
Q_DECLARE_METATYPE(QVector<Skin::Reconstruction::AccDataSampler::Data>)

#endif // SKINRECON_ACCDATASAMPLER_DATA_H
