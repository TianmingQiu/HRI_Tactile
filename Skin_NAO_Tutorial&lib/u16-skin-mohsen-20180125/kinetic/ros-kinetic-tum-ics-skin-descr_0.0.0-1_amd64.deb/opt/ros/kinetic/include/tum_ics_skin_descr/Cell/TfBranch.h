#ifndef TUM_ICS_SKIN_DESCR_CELL_TF_BRANCH_H
#define TUM_ICS_SKIN_DESCR_CELL_TF_BRANCH_H

#include <QString>
#include <tum_ics_tfs/TfBranch.h>

namespace tum_ics_skin_descr{
namespace Cell{

class TfBranch : public tum_ics_tfs::TfBranch
{
public:
    static TfBranch Default();

private:
    int m_cellId;

public:
    TfBranch(int cellId = 0,
             const QString& name = "default",
             const QString& baseFrame = "/world",
             const QString& nameSpace = "Default");


    TfBranch(int cellId,
             const tum_ics_tfs::TfBranch& tfb);

    TfBranch(const TfBranch& tfb);

    ~TfBranch();

    void setCellId(int cellId);

    int cellId() const;

    QString toString() const;

private:

};

}}

#endif // TUM_ICS_SKIN_DESCR_CELL_TF_BRANCH_H
