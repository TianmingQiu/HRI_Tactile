/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKIN_CONFIG_H
#define SKIN_CONFIG_H

#include <QVector>
#include <QMetaType>
#include <QMap>

#include <Eigen/Eigen>

#include <SkinCore/Cell/Neighbors.h>
#include <SkinCore/Cell/Organization.h>

#include "Patch.h"
#include "Segment.h"

namespace Skin{


class Config
{
public:
    static const Config Undefined;  // undefined config (std constructor)

    static Config load(const QString& filePath);
    static bool save(const QString& filePath, const Config& c);

private:
    QMap<int,int> m_cellIdMap;          // map: cell id -> cell ind
    QMap<int,int> m_patchIdMap;         // map: patch id -> patch ind
    QMap<int,int> m_segmentIdMap;       // map: segment id -> segment ind

    QVector<Segment>            m_segments;
    QVector<Patch>              m_patches;
    QVector<Cell::Organization> m_cells;

public:
    Config();   // undefined
    Config(const Config& c);

    Config(const Patch& p);
    Config(const Segment& s);


    Config(const QVector<Segment>& segments);
    Config(const QVector<Patch>& patches);
    Config(const QVector<Cell::Organization>& cells);

    ~Config();

    bool operator== (const Config& other) const;
    bool operator!= (const Config& other) const;

    // ignored if patch with given id is not present
    bool changeRootCellPos(int patchId, const Eigen::Vector3d& pos);
    bool changeRootCellRot(int patchId, const Eigen::Matrix3d& rot);

    // returns -1 if not present
    int indexOfCell(int cellId) const;
    int indexOfPatch(int patchId) const;
    int indexOfSegment(int segmentId) const;

    bool hasCell(int cellId) const;
    bool hasPatch(int patchId) const;
    bool hasSegment(int segmentId) const;

    bool isUndefined() const;

    // returns undefined if cell is not existent
    const Cell::Organization& cell(int cellId) const;
    const Patch& patch(int patchId) const;
    const Segment& segment(int segmentId) const;


    int numberOfCells() const;
    int numberOfPatches() const;
    int numberOfSegments() const;

    const QVector<Segment>& segments() const;
    const QVector<Patch>& patches() const;
    const QVector<Cell::Organization>& cells() const;

    bool save(const QString& filePath = "patch.xml") const;
};

}

Q_DECLARE_METATYPE(Skin::Config)
Q_DECLARE_METATYPE(QVector<Skin::Config>)

#endif // SKIN_CONFIG_H
