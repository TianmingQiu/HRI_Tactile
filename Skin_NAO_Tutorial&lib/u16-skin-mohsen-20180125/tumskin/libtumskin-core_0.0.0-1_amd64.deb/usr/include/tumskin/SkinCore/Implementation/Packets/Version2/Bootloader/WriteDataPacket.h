/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINIMPLPKTS_WRITEDATAPACKETV2_H
#define SKINIMPLPKTS_WRITEDATAPACKETV2_H

#include <SkinCore/Implementation/Packet.h>
#include <SkinCore/Implementation/DataBlock.h>

namespace Skin{
namespace Implementation{
namespace Packets {
namespace Version2{
namespace Bootloader{

class WriteDataPacket : public Packet
{
public:

    // to check ack
    static bool check(const Packet& p);

    // input data in bytes, 64 instructions,
    //      512 bytes in byte addressing space
    //      128 words, 128 16bit word memory locations
    // structure (byte addressing):
    //      0x00    LSB of data or instruction
    //      0x01    MSB of data or instruction
    //      0x02    instruction only, must stay zero for data
    //      0x03    always zero
    static const int DATA_SIZE              = 384; // number of bytes (compressed to 3 bytes per instruction)

    // the header inside the packet which will contain the
    // address and size of the data to write
    static const int HEADER_SIZE            = 8;
    static const int CKS_SIZE               = 1;

    // the unencoded payload size of the packet (header,data,cks)
    static const int PAYLOAD_SIZE           = DATA_SIZE+HEADER_SIZE+CKS_SIZE;

    // size of payload after 8bit to 7 bit encoding
    static const int ENCODED_PAYLOAD_SIZE   = (PAYLOAD_SIZE/7+1)*8;

    // number of 8byte bundles, which encode 7 normal bytes in 8 7bit bytes
    static const int NUM_OF_BUNDLES         = (PAYLOAD_SIZE/7+1);

    // overhead because of packet header, end bytes, and end of packet
    static const int PACKET_OVERHEAD        = 4;

    // the complete packet size
    static const int PKT_SIZE = ENCODED_PAYLOAD_SIZE + PACKET_OVERHEAD;

    static const int PKT_ACK_SIZE           = 4;

public:
    WriteDataPacket(int wordAddress = 0,
                    const QByteArray& data = QByteArray(),
                    const QVector<Endpoint>& dest = QVector<Endpoint>());

    WriteDataPacket(const DataBlock& db,
                    const QVector<Endpoint>& dest = QVector<Endpoint>());

    // data must not be bigger than DATA_SIZE
    // data is unencoded data to write to flash where one instruction
    // has 3 bytes and occupies 2 word addresses
    // if the data block is smaller than DATA_SIZE the data block
    // will be padded with 0xFF
    void setDataBlock(int wordAddress = 0,
                      const QByteArray& data = QByteArray());

    void setDataBlock(const DataBlock& db = DataBlock());


private:
    void init(int wordAddress = 0,
              const QByteArray& data = QByteArray());

    QByteArray encodeData(const QByteArray& data);

};

}}}}}





#endif // SKINIMPLPKTS_WRITEDATAPACKETV2_H
