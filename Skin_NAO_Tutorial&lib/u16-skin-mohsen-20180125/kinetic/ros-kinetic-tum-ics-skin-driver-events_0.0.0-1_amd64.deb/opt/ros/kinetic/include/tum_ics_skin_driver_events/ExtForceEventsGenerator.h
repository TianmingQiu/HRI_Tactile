#ifndef TUM_ICS_SKIN_DRIVER_EVENTS_EXTFORCE_EVENTS_GENERATOR_H
#define TUM_ICS_SKIN_DRIVER_EVENTS_EXTFORCE_EVENTS_GENERATOR_H

#include <tum_ics_skin_common_events/Cell/ExtForce.h>

namespace tum_ics_skin_driver_events{

class ExtForceEventsGenerator
{
private:
    typedef tum_ics_skin_common_events::Cell::ExtForce ExtForce;

    typedef ::Skin::Cell::Events::Event Event;
    typedef QVector<Event> EventBunch;

    QMap<int,int> m_cellIdMap; // map: id -> ind

    QVector<ExtForce> m_extForce;
    bool m_initialized;

public:
    ExtForceEventsGenerator();

    void init(QVector<int> cellIds);

    EventBunch& generate(EventBunch& eb);

private:

};

}

#endif // TUM_ICS_SKIN_DRIVER_EVENTS_EXTFORCE_EVENTS_GENERATOR_H
