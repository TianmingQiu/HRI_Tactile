#ifndef TUM_ICS_SKIN_CELL_LEDCOLORCLIENT_H
#define TUM_ICS_SKIN_CELL_LEDCOLORCLIENT_H

#include <ros/ros.h>
#include <tum_ics_skin_common/Cell/LedColor.h>

namespace tum_ics_skin_bridge{
namespace Cell{

class LedColorClient
{
public:
    static const int BroadcastCellId;

private:
    ros::NodeHandle                 m_node;
    QString m_srvName;

public:
    LedColorClient(const QString& srvName = "setSkinCellLedColor");
    ~LedColorClient();

    void setServiceName(const QString& srvName);

    // note: driver can handle only 1 color cmd per 2 ms;
    // everything else is queued
    bool setLedColor(const ::Skin::Cell::LedColor& c,
                     int id = tum_ics_skin_common::Cell::LedColor::BroadcastId);

    bool setLedColor(const QVector< ::Skin::Cell::LedColor>& c, const QVector<int>& ids);
    bool setLedColor(::Skin::Cell::LedColor c, const QVector<int>& ids);

};


}}

#endif // TUM_ICS_SKIN_CELL_LEDCOLORCLIENT_H
