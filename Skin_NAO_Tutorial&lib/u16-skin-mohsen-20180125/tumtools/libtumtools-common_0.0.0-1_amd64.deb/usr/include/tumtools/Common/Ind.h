#ifndef TUM_TOOLS_COMMON_IND_H
#define TUM_TOOLS_COMMON_IND_H

namespace Tum{
namespace Tools{
namespace Common{

class Ind
{
private:
    int m_ind;
public:
    Ind(int ind) : m_ind(ind){}
    Ind(const Ind& ind) : m_ind(ind.m_ind){}

    operator int&()
    {
        return m_ind;
    }

    operator const int&() const
    {
        return m_ind;
    }
};


}}}

#endif // TUM_TOOLS_COMMON_IND_H
