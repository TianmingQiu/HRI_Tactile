/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINIMPLENDPOINT_H
#define SKINIMPLENDPOINT_H

#include <QMetaType>

namespace Skin{
namespace Implementation{

class Endpoint
{
public:
    static const int ALL_PORTS                  = 0xFFFFFFFF;
    static const int NO_PORTS                   = 0x00000000;

private:
    int m_node;     // starts at 1
    int m_ports;    // 32 bit port mask

public:
    Endpoint();
    Endpoint(const Endpoint& ep);
    Endpoint(int node);
    Endpoint(int node, int port);
    ~Endpoint();

    bool operator== (const Endpoint& other) const;
    bool operator!= (const Endpoint& other) const;

    void setNode(int node);

    void setAllPorts();
    void clearAllPorts();

    void setPort(int port);     // port id starts at 1
    void clearPort(int port);   // port id starts at 1

    void setPorts(int portMask=ALL_PORTS);
    void clearPorts(int portMask=ALL_PORTS);

    int node() const;   // id of node, starts at 1
    int port() const;   // id of lowest active port, 0 if non is active

    int ports() const;  // returns port mask of active ports

    bool isPortSet(int port) const; // port id starts at 1

    void clear();

    QString toString() const;

};


}
}


Q_DECLARE_METATYPE(Skin::Implementation::Endpoint)



#endif // SKINIMPLENDPOINT_H
