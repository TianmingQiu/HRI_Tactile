#ifndef TUM_ICS_SKIN_EVENTS_CELL_EVENTS_EVENTS_H
#define TUM_ICS_SKIN_EVENTS_CELL_EVENTS_EVENTS_H

#include <ros/ros.h>
#include <tum_ics_skin_msgs_events/SkinCellEventConfig.h>
#include <tum_ics_skin_common_events/Events/Type.h>

#include <SkinCore/Cell/Events/Events.h>

#include <QString>
#include <QVector>

namespace tum_ics_skin_common_events{
namespace Cell{
namespace Events{

// same as defined in SkinCore/Cell/Events/Events.h
const tum_ics_skin_common_events::Events::Type Proximity    = tum_ics_skin_common_events::Events::Type(::Skin::Cell::Events::Proximity);
const tum_ics_skin_common_events::Events::Type Force1       = tum_ics_skin_common_events::Events::Type(::Skin::Cell::Events::Force1);
const tum_ics_skin_common_events::Events::Type Force2       = tum_ics_skin_common_events::Events::Type(::Skin::Cell::Events::Force2);
const tum_ics_skin_common_events::Events::Type Force3       = tum_ics_skin_common_events::Events::Type(::Skin::Cell::Events::Force3);
const tum_ics_skin_common_events::Events::Type Acc1         = tum_ics_skin_common_events::Events::Type(::Skin::Cell::Events::Acc1);
const tum_ics_skin_common_events::Events::Type Acc2         = tum_ics_skin_common_events::Events::Type(::Skin::Cell::Events::Acc2);
const tum_ics_skin_common_events::Events::Type Acc3         = tum_ics_skin_common_events::Events::Type(::Skin::Cell::Events::Acc3);
const tum_ics_skin_common_events::Events::Type Temp1        = tum_ics_skin_common_events::Events::Type(::Skin::Cell::Events::Temp1);
const tum_ics_skin_common_events::Events::Type Temp2        = tum_ics_skin_common_events::Events::Type(::Skin::Cell::Events::Temp2);

// new, created in skin events driver, later also in cells!
const tum_ics_skin_common_events::Events::Type ExtForce     = tum_ics_skin_common_events::Events::Type(10,"extForce");

const QVector<tum_ics_skin_common_events::Events::Type> AllEvents =
        QVector<tum_ics_skin_common_events::Events::Type>()
        << Proximity
        << Force1
        << Force2
        << Force3
        << Acc1
        << Acc2
        << Acc3
        << Temp1
        << Temp2
        << ExtForce;
}}}

#endif // TUM_ICS_SKIN_EVENTS_CELL_EVENTS_EVENTS_H
