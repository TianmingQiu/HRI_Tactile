/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINCELLNEIGHBORS_H
#define SKINCELLNEIGHBORS_H

#include <QVector>
#include <QMetaType>
#include <QTextStream>

namespace Skin{
namespace Cell {

class Neighbors
{
private:
    int m_id;                       // cell id starts at one
    QVector<int> m_neighborIds;     // ordered neighbor ids, pos 0 == port 1, contains cell ids of neighbors

public:
    Neighbors();
    Neighbors(const Neighbors& neighbors);
    Neighbors(int id, int nId1, int nId2, int nId3, int nId4);
    Neighbors(int id, const QVector<int>& neighborIds);
    ~Neighbors();

    bool operator== (const Neighbors& other) const;
    bool operator!= (const Neighbors& other) const;

    int id() const;

    // id is in the range 1...4
    int neighbor(int portId) const;

    const QVector<int>& neighbors() const;

    QString toString() const;

};

}
}

QTextStream& operator << (QTextStream& s, const Skin::Cell::Neighbors&);
QTextStream& operator >> (QTextStream& s, Skin::Cell::Neighbors&);

Q_DECLARE_METATYPE(Skin::Cell::Neighbors)
Q_DECLARE_METATYPE(QVector<Skin::Cell::Neighbors>)


#endif // SKINCELLNEIGHBORS_H
