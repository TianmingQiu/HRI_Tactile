#ifndef TUM_ICS_TFS_TF_BRANCH_H
#define TUM_ICS_TFS_TF_BRANCH_H

#include <QString>

namespace tum_ics_tfs{

class TfBranch
{
public:
    static TfBranch Default();

private:
    QString m_name;
    QString m_baseFrame;    // name of the base frame of the marker
    QString m_nameSpace;    // name of the tf namespace

public:
    TfBranch(const QString& name = "default",
            const QString& baseFrame = "/world",
            const QString& nameSpace = "Default");

    TfBranch(const QString& name,
            const TfBranch& base);

    TfBranch(const TfBranch& tfb);

    ~TfBranch();

    void setName(const QString& name);

    void setBaseFrame(const QString& baseFrame);
    void setBaseFrame(const TfBranch& base);

    void setNameSpace(const QString& nameSpace);

    const QString& name() const;
    const QString& baseFrame() const;
    const QString& nameSpace() const;

    QString toString() const;

protected:

private:

};

}

#endif // TUM_ICS_TFS_TF_BRANCH_H
