/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINIMPLPKTS_VERSIONPACKETV2_H
#define SKINIMPLPKTS_VERSIONPACKETV2_H

#include <SkinCore/Implementation/Packet.h>
#include <SkinCore/Implementation/Packets/Version2/Version.h>

namespace Skin{
namespace Implementation{
namespace Packets {
namespace Version2{
namespace Bootloader{

class VersionPacket : public Packet
{
public:
    static const int PKT_SIZE = 7;
    static bool check(const Packet& p);

    static Version getVersion(const Packet& p);

public:
    VersionPacket();
    VersionPacket(const QVector<Endpoint>& dest);

private:
    void init();

};

}}}}}

#endif // SKINIMPLPKTS_VERSIONPACKETV2_H
