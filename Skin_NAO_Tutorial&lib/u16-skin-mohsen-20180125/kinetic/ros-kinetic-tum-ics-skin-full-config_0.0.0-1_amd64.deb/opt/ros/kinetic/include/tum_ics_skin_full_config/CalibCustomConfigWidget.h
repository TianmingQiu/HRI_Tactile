#ifndef TUM_ICS_SKIN_FULL_CONFIG_CALIB_CUSTOM_CONFIG_WIDGET_H
#define TUM_ICS_SKIN_FULL_CONFIG_CALIB_CUSTOM_CONFIG_WIDGET_H



#include <QWidget>
#include <QStatusBar>
#include <QComboBox>
#include <QSpinBox>
#include <QPushButton>

//This definition is needed with libboost 1.58
#ifndef Q_MOC_RUN
#include <SkinCore/Config/Config.h>
#include <SkinViz/Simple/Viz.h>

#include <tum_ics_skin_bridge/Cell/DataConnectionBanked.h>
#include <tum_ics_skin_bridge/Cell/LedColorClient.h>
#include <tum_ics_skin_bridge/Cell/Debouncer.h>


#include <tum_ics_skin_descr/Patch/Extrinsics.h>
#endif

namespace tum_ics_skin_full_config
{

namespace Ui {
class CalibCustomConfigWidget;
}

class CalibCustomConfigWidget : public QWidget
{
    Q_OBJECT

private:
    typedef tum_ics_skin_bridge::Cell::DataConnectionBanked DataConn;
    typedef tum_ics_skin_bridge::Cell::LedColorClient ColorConn;
    typedef ::Skin::Config SkinConfig;
    typedef tum_ics_skin_descr::Patch::Extrinsics PatchExtrinsics;

    enum State
    {
        UndefinedPatch,
        SelectPatch,
        ConfigPatch,
        SelectPatchCellsStart,
        SelectPatchCellsRunning,
        SelectPatchCellsStop,
        SelectRootCellStart,
        SelectRootCellRunning,
        SelectRootCellStop,
        CompletePatch
    };

    Ui::CalibCustomConfigWidget *ui;

    QStatusBar* m_sb;

    QComboBox* m_cbSelectPatch;
    QSpinBox* m_sbNewPatchId;

    QPushButton* m_pbSelectCells;
    QPushButton* m_pbSelectRootCell;

    QPushButton* m_pbSave;

    Skin::Viz::Simple::Viz* m_viz;

    ::Skin::Config m_config;
    QString m_prefix;
    QVector<tum_ics_skin_descr::Patch::Extrinsics> m_patchExtrinsics;

    // current input patch
    Skin::Patch m_patch;

    // output patch
    Skin::Patch m_patchOut;
    tum_ics_skin_descr::Patch::Extrinsics m_patchExtrinsicsOut;

    tum_ics_skin_bridge::Cell::Debouncer m_debouncer;

    DataConn m_dataConn;
    ColorConn m_colorConn;

    State m_state;
    QString m_defaultPath;

    QList<int> m_selectedCellIds;
    int m_rootCellId;

public:
    explicit CalibCustomConfigWidget(QWidget *parent = 0);
    ~CalibCustomConfigWidget();

    bool init(QStatusBar* sb, const QString& defaultPath = ".");
    void setDefaultPath(const QString& path = ".");

    // call this function in the main while loop
    void update();

private:
    void status(const QString& msg);
    void warning(const QString& msg);
    void error(const QString& msg);

    void updateGui();
    void updatePatchConn();
    void updatePatchViz();
    void updateOutputPatch();
    void updatePatchVizData(const QVector<Skin::Cell::Data> &data);

public slots:
    // reset to undefined or select patch
    void newSkinConfig(::Skin::Config config,
                       QString prefix,
                       QVector<tum_ics_skin_descr::Patch::Extrinsics> pe);

//    // reset config, set patch, set to Patch config or Patch Undefined
//    void customSkinPatch(::Skin::Patch patch, QString prefix);

private slots:
    void cbSelectPatch_currentIndexChanged(int index);
    void sbNewPatchId_valueChanged(int val);

    void pbSelectCellsClicked();
    void pbSelectRootCellClicked();
    void pbSaveClicked();

signals:
    void newSkinPatch(::Skin::Patch patch,
                      QString prefix,
                      tum_ics_skin_descr::Patch::Extrinsics pe);

    // lock other GUIs
    void lockGui(bool enable);

};

}

#endif // TUM_ICS_SKIN_FULL_CONFIG_CALIB_CUSTOM_CONFIG_WIDGET_H
