#ifndef SKINCORE_OPERATORSV2_BASE_TASKHANDLERS_TASKHANDLER_H
#define SKINCORE_OPERATORSV2_BASE_TASKHANDLERS_TASKHANDLER_H

#include <SkinCore/Implementation/Operators/TaskHandler.h>
#include <SkinCore/Implementation/Operators/Version2/Base/Operator.h>

namespace Skin{
namespace Implementation{
namespace Operators{
namespace Version2{
namespace Base{

class TaskHandler : public Skin::Implementation::Operators::TaskHandler
{

protected:
    Skin::Implementation::Operators::Version2::Base::Operator* m_op;
    Skin::Implementation::Interface** m_intf;
    const Skin::Implementation::Operators::Version2::Base::Timing* m_timings;

public:
    TaskHandler(
            Skin::Implementation::Operators::Version2::Base::Operator* op,
            Skin::Implementation::Interface** intf,
            Skin::Implementation::Operators::Version2::Base::Timing* timings);
};


}}}}}

#endif // SKINCORE_OPERATORSV2_BASE_TASKHANDLERS_TASKHANDLER_H
