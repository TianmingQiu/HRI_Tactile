#ifndef SKINEVENTS_MANAGERS_EVENTS_THRESHOLDSCMDHANDLER_H
#define SKINEVENTS_MANAGERS_EVENTS_THRESHOLDSCMDHANDLER_H

#include <QStringList>

#include <SkinManagers/Application/ConsoleCmdHandler.h>
#include <SkinEvents/Managers/Events/Manager.h>
#include <SkinCore/Cell/Events/Events.h>

namespace Skin {
namespace Managers{
namespace Events{

class ThresholdsCmdHandler : public ConsoleCmdHandler
{
public:

private:
    static const QStringList ArgList;

    Skin::Managers::Application::Base::Application* m_app;
    Skin::Managers::Events::Manager* m_mgr;

public:
    ThresholdsCmdHandler(
            Skin::Managers::Application::Base::Application* app,
            Skin::Managers::Events::Manager* mgr);

    virtual bool handleMessage(const QString &s);
    virtual QString cmdDescription() const;

private:
    bool getThresholds(Skin::Cell::Events::Thresholds& t, int id = Manager::BroadcastId);
    bool setThreshold(Skin::Cell::Events::Thresholds& t, const QString& arg, double val);
};


}}}

#endif // SKINEVENTS_MANAGERS_EVENTS_THRESHOLDSCMDHANDLER_H
