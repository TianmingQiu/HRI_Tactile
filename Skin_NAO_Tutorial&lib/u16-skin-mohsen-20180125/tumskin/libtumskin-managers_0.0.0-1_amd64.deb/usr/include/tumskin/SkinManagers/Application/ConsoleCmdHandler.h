#ifndef SKINMANAGERS_CONSOLECOMMANDHANDLER_H
#define SKINMANAGERS_CONSOLECOMMANDHANDLER_H

#include <QString>

class ConsoleCmdHandler
{
public:
    virtual bool handleMessage(const QString& s) = 0;
    virtual ~ConsoleCmdHandler() = 0;
    virtual QString cmdDescription() const = 0;
};

inline ConsoleCmdHandler::~ConsoleCmdHandler(){}

#endif // SKINMANAGERS_CONSOLECOMMANDHANDLER_H
