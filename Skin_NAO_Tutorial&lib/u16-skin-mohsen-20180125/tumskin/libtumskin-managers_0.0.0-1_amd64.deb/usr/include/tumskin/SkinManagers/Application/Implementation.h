#ifndef SKINMANAGERS_APPLICATION_IMPLEMENTATION_H
#define SKINMANAGERS_APPLICATION_IMPLEMENTATION_H

#include <QObject>
#include <SkinCore/Implementation/Interface.h>
#include <SkinCore/Implementation/Operators/Version2/Base/Operator.h>

namespace Skin{
namespace Managers{
namespace Application{

typedef Skin::Implementation::Interface IntfBase;
typedef Skin::Implementation::Operators::Version2::Base::Operator OpBase;

// test if type T is derived from type B
template<class T, class B> struct Derived_from {
    static void constraints(T* p) { B* pb = p; }
    Derived_from() { void(*p)(T*) = constraints; }
};

template<class Op, class Intf>
class Implementation : public Op
{

public:
    static Op* create(bool driveEventLoop = false)
    {
        Op* p = new Implementation();
        p->enableEventLoopProcessing(driveEventLoop);
        return p;
    }

private:
    Intf* m_intf;

public:
    Implementation(QObject* parent = 0) : Op(parent)
    {
        Derived_from<Intf,IntfBase>();
        Derived_from<Op,OpBase>();

        m_intf = new Intf(this);

        Op::setInterface(m_intf);

        QString name = Op::name();
        Op::setName(m_intf->name() + ", " + name);

        QObject::connect(m_intf,SIGNAL(error(Skin::Implementation::Interface::InterfaceError)),
                         this,SLOT(handleInterfaceError(Skin::Implementation::Interface::InterfaceError)));

        QObject::connect(this,SIGNAL(error(Skin::Implementation::Operator::OperatorError)),
                         this,SLOT(handleOperatorError(Skin::Implementation::Operator::OperatorError)));
    }

    ~Implementation(){}

};



}}}





#endif // SKINMANAGERS_APPLICATION_IMPLEMENTATION_H
