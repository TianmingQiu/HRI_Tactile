/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINEVENTS_PACKETSV2_EVENTS_CONFIGPACKETV2_H
#define SKINEVENTS_PACKETSV2_EVENTS_CONFIGPACKETV2_H

#include <SkinCore/Implementation/Packet.h>
#include <SkinCore/Implementation/Packets/Version2/PacketDefinitions.h>
#include <SkinCore/Cell/Events/Flags.h>
#include <SkinCore/Cell/Events/Events.h>
#include <SkinCore/Events/Type.h>

namespace Skin{
namespace Implementation{
namespace Packets {
namespace Version2{
namespace Events{


class ConfigPacket : public Packet
{

public:
    static const int PKT_SIZE = 20;

    static bool check(const Packet& p);

    static Skin::Cell::Events::Flags& getActiveEventFlags(Skin::Cell::Events::Flags& f, const Packet& p);
    static Skin::Cell::Events::Flags getActiveEventFlags(const Packet& p);

    static QVector<Skin::Events::Type>& getActiveEvents(QVector<Skin::Events::Type>& events,const Packet& p);
    static QVector<Skin::Events::Type> getActiveEvents(const Packet& p);

    static void setActiveEvents(Packet& p, const Skin::Cell::Events::Flags& f);
    static void setActiveEvents(Packet& p, const QVector<Skin::Events::Type>& events);

private:

public:
    ConfigPacket(const Skin::Cell::Events::Flags& f,
                 int id=ID_ALL,
                 const QVector<Endpoint>& dest=QVector<Endpoint>());

    ConfigPacket(const QVector<Skin::Events::Type>& events = Skin::Cell::Events::AllEvents,
                 int id=ID_ALL,
                 const QVector<Endpoint>& dest=QVector<Endpoint>());

    void setActiveEvents(const Skin::Cell::Events::Flags& f);
    void setActiveEvents(const QVector<Skin::Events::Type>& events);

private:
    void init();


};

}}}}}

#endif // SKINEVENTS_PACKETSV2_EVENTS_CONFIGPACKETV2_H
