/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKININTFFTDI_FTDIDRIVER_H
#define SKININTFFTDI_FTDIDRIVER_H

#include <QElapsedTimer>
#include <QTimer>
#include <QVector>

#include <Ftdi/WinTypes.h>
#include <Ftdi/ftd2xx.h>

#include <SkinCore/Implementation/FtdiNode.h>

namespace Skin{
namespace Implementation{
namespace Interfaces{

class FtdiDriver
{

public:
    enum FtdiDriverError
    {
        NoError = 0,
        DeviceNotFoundError,
        PermissionError,
        OpenError,
        NotOpenError,
        WriteError,
        ReadError,
        CBusBitBangError,
        UnknownError
    };

    enum OpenMode
    {
        OpenByIndex = 0,        // use ftdi device index
        OpenBySerialNumber,     // use ftdi device serial number
        OpenByDescription       // use ftdi description
    };

private:
    bool                            m_opened;

    int                             m_index;
    QString                         m_serialNumber;
    QString                         m_description;
    OpenMode                        m_openMode;
    int                             m_baudrate;

    FT_HANDLE                       m_handle;

    // upper bits in/out mode bits (1 = out, 0 = in, for cbus 6,7,8,9)
    // lower bits for pin out values
    UCHAR                           m_mask; // mask for CBUS io

    FtdiDriver::FtdiDriverError     m_error;
    QString                         m_errorString;

public:
    static QVector<FtdiNode> getAvailableDevices(
            const QVector<FtdiNode>& nodes=FtdiNode::AvailableNodes);

    static QVector<FtdiNode> getUnavailableDevices(
            const QVector<FtdiNode>& nodes);

    static QString getDeviceInfoString();
    static QList<FT_DEVICE_LIST_INFO_NODE> getDeviceInfoList();

    static QString deviceTypeToString(ULONG type);
    static bool flagsDeviceIsOpened(ULONG flags);
    static bool flagsDeviceIsHighSpeedDevice(ULONG flags);


public:
    explicit FtdiDriver();

    bool setDeviceIndex(int index);
    bool setSerialNumber(const QString& serialNumber);
    bool setDescription(const QString& description);
    bool setBaudrate(int baudrate);

    bool open(const FtdiNode& n);
    bool open(FtdiDriver::OpenMode mode);
    void close();

    bool isOpened() const;

    bool enablePower(bool enable);
    bool enableLed(bool enable);

    bool writeData(const QByteArray& data);
    bool readData(QByteArray& data);

    void clearError();
    FtdiDriver::FtdiDriverError error() const;
    QString errorString();

protected:
    void handleError(FtdiDriver::FtdiDriverError error);
    void handleError(FtdiDriver::FtdiDriverError error, const QString& details);
    QString errorToString(FtdiDriver::FtdiDriverError error);


};

}
}
}

#endif // SKININTFFTDI_FTDIDRIVER_H
