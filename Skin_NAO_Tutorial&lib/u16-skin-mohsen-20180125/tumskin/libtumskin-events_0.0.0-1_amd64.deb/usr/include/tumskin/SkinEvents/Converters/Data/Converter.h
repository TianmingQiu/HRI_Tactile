#ifndef SKINEVENTS_CONVERTERS_DATA_CONVERTER_H
#define SKINEVENTS_CONVERTERS_DATA_CONVERTER_H

#include <QObject>
#include <QTimer>
#include <QMap>

#include <Threads/Thread.h>

#include <SkinCore/Cell/Data.h>
#include <SkinCore/Implementation/Packet.h>
#include <SkinManagers/Application/Base/Application.h>

namespace Skin{
namespace Events{
namespace Converters{
namespace Data{


class Converter : public QObject
{
    Q_OBJECT

private:
    Skin::Managers::Application::Base::Application* m_app;

    int m_numOfCells;
    QVector<Skin::Cell::Data> m_data;
    QMap<int,int> m_cellIdMap;

    QVector<bool> m_dataPend;
    QVector<Skin::Cell::Data> m_dataBuf;
    int m_dataInd;

    Threads::Thread m_thread;

public:
    explicit Converter(Skin::Managers::Application::Base::Application* app,
                       QObject *parent = 0);

    ~Converter();

private:

private slots:
    void newNumberOfCells(int);
    void newEventDataPacketBunch(QVector<Skin::Implementation::Packet>);

public slots:

signals:
    void newDataBunch(QVector<Skin::Cell::Data>);
};


}}}}


#endif // SKINEVENTS_CONVERTERS_DATA_CONVERTER_H
