/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINCORE_CELL_EVENTS_H
#define SKINCORE_CELL_EVENTS_H

#include <QVector>
#include <QMetaType>

#include <SkinCore/Events/Type.h>

namespace Skin{
namespace Cell{
namespace Events{

// std defs for low level events of skin cell v2
const Skin::Events::Type Proximity  = Skin::Events::Type(1,"prox[0]");
const Skin::Events::Type Force1     = Skin::Events::Type(2,"froce[0]");
const Skin::Events::Type Force2     = Skin::Events::Type(3,"force[1]");
const Skin::Events::Type Force3     = Skin::Events::Type(4,"force[2]");
const Skin::Events::Type Acc1       = Skin::Events::Type(5,"acc[0]");
const Skin::Events::Type Acc2       = Skin::Events::Type(6,"acc[1]");
const Skin::Events::Type Acc3       = Skin::Events::Type(7,"acc[2]");
const Skin::Events::Type Temp1      = Skin::Events::Type(8,"temp[0]");
const Skin::Events::Type Temp2      = Skin::Events::Type(9,"temp[1]");

const QVector<Skin::Events::Type> AllEvents = QVector<Skin::Events::Type>()
        << Proximity
        << Force1
        << Force2
        << Force3
        << Acc1
        << Acc2
        << Acc3
        << Temp1
        << Temp2;

}}}


#endif // SKINCORE_CELL_EVENTS_H
