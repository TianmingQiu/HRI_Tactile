#!/bin/bash

numOfPings=5
ipAddrNet24="192.168.4"


ind=0
ipAddrList[$((ind++))]="${ipAddrNet24}.70"
ipAddrList[$((ind++))]="${ipAddrNet24}.71"
ipAddrList[$((ind++))]="${ipAddrNet24}.72"

driverPrefix="rossws && roslaunch tum_ics_skin_driver_events skin_driver_tsu3_"
ind=0
driverList[$((ind++))]="70p1"
driverList[$((ind++))]="70p2"
driverList[$((ind++))]="70p3"
driverList[$((ind++))]="70p4"

driverList[$((ind++))]="71p1"
driverList[$((ind++))]="71p2"
driverList[$((ind++))]="71p3"
driverList[$((ind++))]="71p4"

driverList[$((ind++))]="72p1"
driverList[$((ind++))]="72p2"
driverList[$((ind++))]="72p3"
driverList[$((ind++))]="72p4"


len=${#ipAddrList[@]}
for (( i=0; i<len; i++ ))
do
    ipAddr=${ipAddrList[${i}]}
    echo "Test connection '${ipAddr}'"

    ping -q -i 0.2 -c$numOfPings $ipAddr > /dev/null
    if [ $? -eq 0 ]
    then
	    echo "Connection is ok."
    else 
        echo "ERROR: Couldn't connect to '${ipAddr}'."
        exit -1
    fi

done


len=${#driverList[@]}
for (( i=0; i<len; i++ ))
do
    driver=${driverList[${i}]}

    # kill screen
    screen -X -S "$driver" quit

    # create screen
    screen -d -m -S "$driver"

    cmd="${driverPrefix}${driver}.launch"
    echo $cmd

    screen -r "$driver" -X stuff $"${cmd} ^M"

    sleep 1
done

screen -ls


