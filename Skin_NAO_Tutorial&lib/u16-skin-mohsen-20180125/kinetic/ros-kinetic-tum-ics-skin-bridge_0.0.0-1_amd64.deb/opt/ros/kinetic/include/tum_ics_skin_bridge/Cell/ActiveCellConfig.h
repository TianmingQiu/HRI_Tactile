#ifndef TUM_ICS_SKIN_BRIDGE_ACTIVE_CELL_CONFIG_H
#define TUM_ICS_SKIN_BRIDGE_ACTIVE_CELL_CONFIG_H

#include <QString>

namespace tum_ics_skin_bridge{
namespace Cell{


class ActiveCellConfig
{
public:

    /*!
     * \brief Default config:
     *
     *  - prox thresh:      0.02
     *  - force thresh:     0.02
     *  - temp thresh low:  32.5
     *  - temp thresh high: 36.0
     *  - temp enbaled:     false
     */
    static ActiveCellConfig Default();

    /*!
     * \brief Load pcl config from parameter file.
     *
     * Falls back to default config if loading fails.
     */
    static ActiveCellConfig load(const QString& param = "~active_cell_config", bool* ok = 0);

private:
    double m_proxThresh;
    double m_forceThresh;
    double m_tempThreshLow;
    double m_tempThreshHigh;
    bool m_tempEnabled;

public:
    /*!
     * \brief Default constructor.
     *
     * Sets default config;
     */
    ActiveCellConfig();
    ActiveCellConfig(const ActiveCellConfig& c);


    ActiveCellConfig(const QString& param);

    ~ActiveCellConfig();

    void setProxThresh(double prox);
    void setForceThresh(double force);

    void setTempThreshLow(double temp);
    void setTempThreshHigh(double temp);
    void setTempThreshs(double tempLow, double tempHigh);
    void setTempEnabled(bool enabled);


    double proxThresh() const;
    double forceThresh() const;
    double tempThreshLow() const;
    double tempThreshHigh() const;
    bool tempEnabled() const;

    QString toString() const;

private:

};

}}

#endif // TUM_ICS_SKIN_BRIDGE_ACTIVE_CELL_CONFIG_H
