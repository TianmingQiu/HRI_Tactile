#ifndef SKINADDITIONS_MASTERPORTS_H
#define SKINADDITIONS_MASTERPORTS_H


#include <QObject>
#include <QTimer>
#include <QThread>
#include <QMutex>
#include <QElapsedTimer>
#include <QFile>

#include <SkinCore/Cell/MasterPort.h>
#include <SkinCore/Cell/Neighbors.h>
#include <SkinManagers/Application/Base/Application.h>
#include <SkinCore/Implementation/Packets/Version2/PacketDefinitions.h>

namespace Skin {
namespace Additions{

class MasterPorts : public QObject
{
    Q_OBJECT

public:

private:

public:

private:
    typedef bool (MasterPorts::*cmd_handler_func)(const QString& s);
    QVector<cmd_handler_func> m_cmdHandlers;
    QString             m_consoleCmdDescription;

    Skin::Managers::Application::Base::Application* m_app;

    QTimer              m_timer;
    bool                m_started;
    QElapsedTimer       m_time;
    int                 m_timeout;

    QVector<Skin::Cell::Neighbors>  m_neighs;
    QVector<int>                    m_rootIds;  // root cell ids for connection trees
    QVector<Skin::Cell::MasterPort> m_mps;

    QMap<int,int>       m_neighMap;      // map: cell id -> neigh ind, id list ind
    QMap<int,int>       m_mpMap;         // map: cell id -> mp ind

    QVector<int>        m_ids;
    int                 m_currInd;

    QMutex              m_mpMutex;
    QVector<QThread*>   m_threads;


public:
    explicit MasterPorts(Skin::Managers::Application::Base::Application* app,
                        QObject *parent = 0);

    const QString& consoleCmdDescription() const;
    bool handleConsoleCmd(QString);

private:
    bool handleMasterPortsCommands(const QString& s);

    bool requestMasterPorts();
    bool collectMasterPorts(const QVector<Skin::Implementation::Packet>& pkts);

    bool saveGraphviz();
    bool saveMasterPorts();
    bool saveNeighborList();

private slots:
    void handleTimer();
    void newNeighborList(QVector<Skin::Cell::Neighbors>);
    void newPacketBunch(QVector<Skin::Implementation::Packet> pkts);

public slots:
    void start(int timeout); // in ms
    void stop();

signals:
    void newMasterPortList(QVector<Skin::Cell::MasterPort>);

};

}}




#endif // SKINADDITIONS_MASTERPORTS_H
