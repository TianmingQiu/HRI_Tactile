#ifndef TUM_ICS_TFS_TF_CONTAINER_H
#define TUM_ICS_TFS_TF_CONTAINER_H

#include <QString>

#include <tum_ics_tfs/TfBranch.h>
#include <tum_ics_tfs/TfConversions.h>

namespace tum_ics_tfs{

class TfContainer : public TfBranch
{
public:
    static TfContainer Default();

private:
    tf::Transform   m_tf;

public:
    TfContainer(const QString& name,
                const QString& baseFrame,
                const QString& nameSpace);

    TfContainer(const QString& name,
                const QString& baseFrame,
                const tf::Transform& tf     = tf::Transform::getIdentity(),
                const QString& nameSpace    = "Default");

    TfContainer(const QString& name,
                const QString& baseFrame,
                const Eigen::Affine3d& tf,
                const QString& nameSpace    = "Default");

    TfContainer(const TfBranch& tfBranch    = TfBranch::Default(),
                const tf::Transform& tf     = tf::Transform::getIdentity());

    TfContainer(const TfBranch& tfBranch,
                const Eigen::Affine3d& tf);

    TfContainer(const TfContainer& tfc);

    ~TfContainer();


    void setTfBranch(const TfBranch& tfBranch);


    // set transformations with respect to base frame
    void setPose(const TfContainer& tf);

    void setPose(const Eigen::Affine3d& tf);

    void setPose(const Eigen::Matrix3d& rot,
                 const Eigen::Vector3d& pos);

    void setPose(const Eigen::Quaterniond& q,
                 const Eigen::Vector3d& pos);

    void setPose(const tf::Transform& tf);

    void setPose(const tf::Quaternion& q,
                 const tf::Vector3& pos);

    void setPose(const geometry_msgs::Pose& pose);


    void setPos(const Eigen::Vector3d& pos);
    void setPos(const tf::Vector3& pos);

    void setRot(const Eigen::Matrix3d& rot);

    void setQuaternion(const Eigen::Quaterniond& q);
    void setQuaternion(const tf::Quaternion& q);



    const TfBranch& tfBranch() const;

    const tf::Transform& poseTf() const;
    tf::Vector3 posTf() const;
    tf::Quaternion quaternionTf() const;

    Eigen::Affine3d poseEigen() const;
    Eigen::Vector3d posEigen() const;
    Eigen::Matrix3d rotEigen() const;
    Eigen::Quaterniond quaternionEigen() const;

    geometry_msgs::Pose poseMsg() const;

    // stamped on call
    tf::StampedTransform stampedTf(const ros::Time& t = ros::Time::now()) const;

    QString toString() const;

private:

};

}

#endif // TUM_ICS_TFS_TF_CONTAINER_H
