#ifndef TUM_ICS_SKIN_CELL_DATA_CONNECTION_BANKED_H
#define TUM_ICS_SKIN_CELL_DATA_CONNECTION_BANKED_H

#include <tum_ics_skin_bridge/Cell/DataConnection.h>
#include <tum_ics_skin_bridge/Cell/DataBank.h>

#include <QString>
#include <QVector>
#include <QMap>
#include <QMutex>

namespace tum_ics_skin_bridge{
namespace Cell{

class DataConnectionBanked  :
        public Cell::DataConnection,
        public Cell::DataBank
{

private:

public:
    // default cell id filter is all cell ids of subscribed topic
    // takes the namespace prefix of the topic for calling services
    DataConnectionBanked(const QString& topicName = "", int patchId=0);
    ~DataConnectionBanked();

    // -> if data pub is not shared then data pub is created,
    //      otherwise only subscribe topic
    // -> fails if already enabled
    bool create(const QString& topicName,
                int patchId,
                const QVector<int>& ids = QVector<int>(),
                bool shared = false);

    bool create(const QString& topicName,
                const QVector<int>& ids = QVector<int>(),
                bool shared = false);

    bool create(const QString& topicName,
                bool shared);

    bool create(const QVector<int>& ids,
                bool shared = false);

private:


};


}}

#endif // TUM_ICS_SKIN_CELL_DATA_CONNECTION_H
