/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINRECON_SKINGRAPH_EDGEPROPERTIES_H
#define SKINRECON_SKINGRAPH_EDGEPROPERTIES_H


#include <Eigen/Eigen>
#include <SkinRecon/SkinGraph/Edge.h>

namespace Skin{
namespace Reconstruction{
namespace SkinGraph{

struct EdgeProperties
{
    int srcCellId;          // starts at 1
    int destCellId;         // starts at 1

    int srcPortId;          // 1-4
    int destPortId;         // 1-4

    double weight;          // increases with estimation error
    Eigen::Matrix3d rot;    // rotation along connection between skin cell ports

public:
    EdgeProperties(int srcCellId=0,
                   int destCellId=0,
                   int srcPortId=0,
                   int destPortId=0,
                   int weight=1,
                   const Eigen::Matrix3d& rot=Eigen::Matrix3d::Identity());

    EdgeProperties(const Edge&e,
                   int srcPortId=0,
                   int destPortId=0,
                   int weight=1,
                   const Eigen::Matrix3d& rot=Eigen::Matrix3d::Identity());

    EdgeProperties(const EdgeProperties& p);
    ~EdgeProperties();

    Edge edge() const;
};


}
}
}



#endif // SKINRECON_SKINGRAPH_EDGEPROPERTIES_H
