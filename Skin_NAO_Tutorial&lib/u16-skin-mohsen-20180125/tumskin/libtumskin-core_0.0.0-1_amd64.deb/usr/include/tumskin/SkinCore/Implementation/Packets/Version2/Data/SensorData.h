/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINIMPLPKTS_SENSORDATAV2_H
#define SKINIMPLPKTS_SENSORDATAV2_H

#include <SkinCore/Cell/Data.h>

#include <SkinCore/Implementation/Packet.h>
#include <SkinCore/Implementation/Packets/Version2/PacketDefinitions.h>

#include <SkinCore/Implementation/Packets/Version2/Data/RawSensorData.h>

namespace Skin{
namespace Implementation{
namespace Packets {
namespace Version2{
namespace Data{

class RawSensorData;

class SensorData
{
public:
    static double convToProx(unsigned int rawProx);
    static double convToForce(unsigned int rawForce);
    static double convToAcc(int rawAcc);
    static double convToTemp1(int rawTemp1);
    static double convToTemp2(int rawTemp2);

    static Skin::Cell::Data& convToData(Skin::Cell::Data& d, const SensorData& sd);

    static SensorData& convToSensorData(SensorData& sd, const Skin::Cell::Data& d);
    static SensorData& convToSensorData(SensorData& sd, const RawSensorData& rsd);

    double prox;
    double force[3];
    double acc[3];
    double temp[2];

private:


public:
    SensorData();
    SensorData(const SensorData& d);
    SensorData(const RawSensorData& d);
    SensorData(const Skin::Cell::Data& d);
    SensorData(const Packet& p);

    SensorData abs() const;

    Skin::Cell::Data toData() const;

    QString toString() const;
};

}}}}}

#endif // SKINIMPLPKTS_SENSORDATAV2_H
