#ifndef TUM_ICS_SKIN_EVENTS_CELL_EVENTS_EVENTSCONFIGVECTOR_H
#define TUM_ICS_SKIN_EVENTS_CELL_EVENTS_EVENTSCONFIGVECTOR_H

#include <tum_ics_skin_common_events/Cell/Events/EventsConfig.h>

#include <QString>
#include <QVector>

namespace tum_ics_skin_common_events{
namespace Cell{
namespace Events{

class EventsConfigVector : public QVector<EventsConfig>
{
private:
    typedef tum_ics_skin_common_events::Events::Type EventsType;
    typedef tum_ics_skin_msgs_events::SkinCellEventConfig ConfigMsg;

private:

public:
    // empty vector means: all events on all skin cells
    EventsConfigVector(const QVector<EventsConfig>& ecs = QVector<EventsConfig>());

    EventsConfigVector(const QVector<int> ids, const QVector<EventsType>& e = AllEvents);
    EventsConfigVector(const std::vector<ConfigMsg>& msgs);

    operator std::vector<ConfigMsg>() const;

};


}}}

#endif // TUM_ICS_SKIN_EVENTS_CELL_EVENTS_EVENTSCONFIGVECTOR_H
