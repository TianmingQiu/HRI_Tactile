#ifndef SKININTFDNODE_DNODECOMPLETEINTFV2V0_H
#define SKININTFDNODE_DNODECOMPLETEINTFV2V0_H

#include <QUdpSocket>
#include <QHostAddress>
#include <QTimer>
#include <QByteArray>
#include <Threads/Thread.h>
#include <QVector>
#include <SkinIntfDNode/Implementation/Interfaces/Version2V0/DNode/Complete/Port.h>
#include <SkinCore/Implementation/Interface.h>

namespace Skin{
namespace Implementation{
namespace Interfaces{
namespace Version2V0{
namespace DNode{
namespace Complete{


class Interface : public Skin::Implementation::Interface
{
    Q_OBJECT

public:

    static const int TYPE;
    static const QString NAME;
    static const int INIT_TIMEOUT;
private :
    Threads::Thread* m_port_thread;
    Port* m_dnode_port;

public :
    explicit Interface(QObject* parent = 0);

    ~Interface();
    bool setNode(const IntfNode& node);
    bool setNodes(const QVector<IntfNode>& nodes);
    bool init();
    bool deinit();
    int type() const;
    QString name() const;
    bool isInitialized() const;
    bool hasPendingPackets();
    bool enablePower(bool enable);
    bool readPacket(Packet& p);
    bool writePacket(const Packet& p);
    bool flushRx();
    QString errorToString(InterfaceError error);
    qint64 getTime();
    void clearError();
    InterfaceError error() const;
    QString errorString();


signals :
    void portInit();
    void portDeinit();
    void deletePort();

};

}}}}}}

#endif // SKININTFDNODE_DNODECOMPLETEINTFV2V0_H
