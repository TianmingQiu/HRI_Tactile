#ifndef TUM_ICS_SKIN_CALLBACK_CALLER_H
#define TUM_ICS_SKIN_CALLBACK_CALLER_H

#include <boost/function.hpp>
#include <boost/bind.hpp>

#include <tum_ics_skin_common/CallbackHandle.h>
#include <tum_ics_skin_common/CallbackProvider.h>

#include <QMutex>

namespace tum_ics_skin_common{

template<class D>
class CallbackCaller
{
private:
    typedef boost::function<void (const D &)> Callback;
    QMutex m_mutex;
    QVector<Callback> m_callbacks;

public:
    CallbackCaller(){}
    ~CallbackCaller(){}

    void call(const D& d)
    {
        m_mutex.lock();
        for(int i=0; i<m_callbacks.size(); i++)
        {
            m_callbacks[i](d);
        }
        m_mutex.unlock();
    }

    CallbackHandle<D> add(Callback callback)
    {
        m_mutex.lock();
        CallbackHandle<D> h(this,m_callbacks.size());
        m_callbacks.append(callback);
        m_mutex.unlock();
        return h;
    }

    CallbackHandle<D> add(CallbackProvider<D>* h)
    {
        return add(&CallbackProvider<D>::callback,h);
    }

    template<class T>
    CallbackHandle<D> add(void(T::*fp)(const D &), T* obj)
    {
        return add(boost::bind(fp,obj,_1));
    }

    template<class T>
    CallbackHandle<D> add(void(*fp)(const D &), T* obj)
    {
        return add(boost::bind(fp,obj,_1));
    }

    void remove(const CallbackHandle<D>& h)
    {
        remove(h.handle());
    }

private:
    void remove(int handle)
    {
        m_mutex.lock();
        m_callbacks.remove(handle);
        m_mutex.unlock();
    }

};

}

#endif // TUM_ICS_SKIN_CALLBACK_CALLER_H
