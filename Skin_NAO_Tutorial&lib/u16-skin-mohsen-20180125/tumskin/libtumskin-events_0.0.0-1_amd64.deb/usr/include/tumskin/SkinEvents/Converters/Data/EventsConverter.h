#ifndef SKINEVENTS_CONVERTERS_DATA_EVENTSCONVERTER_H
#define SKINEVENTS_CONVERTERS_DATA_EVENTSCONVERTER_H

#include <QObject>
#include <QTimer>
#include <QMap>

#include <Threads/Thread.h>

#include <SkinCore/Cell/Data.h>
#include <SkinCore/Implementation/Packet.h>
#include <SkinManagers/Application/Base/Application.h>
#include <SkinEvents/Converters/Event/Unpacker.h>

namespace Skin{
namespace Events{
namespace Converters{
namespace Data{


class EventsConverter : public QObject
{
    Q_OBJECT

private:
    Skin::Managers::Application::Base::Application* m_app;
    Skin::Events::Converters::Event::Unpacker* m_eventUnpacker;
    Threads::Thread m_thread;

    int m_numOfCells;
    QVector<Skin::Cell::Data> m_data;
    QMap<int,int> m_cellIdMap;          // map: cell id -> ind
    QMap<int,int> m_eventTypeIdMap;     // map: event type -> data ind
    QVector<bool> m_dataPend;
    QVector<Skin::Cell::Data> m_dataBuf;
    int m_dataInd;

     bool m_enabled;

public:
    explicit EventsConverter(Skin::Managers::Application::Base::Application* app,
                           Skin::Events::Converters::Event::Unpacker* eventUnpacker,
                           QObject *parent = 0);

     ~EventsConverter();

     void enable();
     void disable();

     bool isEnabled() const;

private:
    Skin::Cell::Data& update(Skin::Cell::Data& d, const Skin::Cell::Events::Event& e);

private slots:
    void newNumberOfCells(int);
    void newEventBunch(QVector<Skin::Cell::Events::Event>);

public slots:

signals:
    void newDataBunch(QVector<Skin::Cell::Data>);
};


}}}}


#endif // SKINEVENTS_CONVERTERS_DATA_EVENTSCONVERTER_H
