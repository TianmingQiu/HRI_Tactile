#ifndef TUM_ICS_SKIN_EVENTS_CELL_EXTFORCE_H
#define TUM_ICS_SKIN_EVENTS_CELL_EXTFORCE_H

#include <SkinCore/Cell/Data.h>
#include <SkinCore/Cell/Events/Event.h>
#include <Eigen/Eigen>

#include <QString>
#include <QVector>

namespace tum_ics_skin_common_events{
namespace Cell{

class ExtForce
{
private:
    typedef ::Skin::Cell::Data Data;
    typedef ::Skin::Cell::Events::Event Event;

public:
    struct Settings
    {
        double proxThresh;
        double forceThresh;
        double proxGain;
        double forceGain;
        double extForceThresh;
        double extForceDiffThresh;
        bool proxEnabled;
        bool forceEnabled;
    };

    //    double proxThresh = 0.05;
    //    double forceThresh = 0.08;
    //    double proxGain = 1.7510;
    //    double forceGain = 0.9740;
    //    double extForceThresh = 0.02;
    //    double extForceDiffThresh = 0.0001;
    //    bool proxEnabled = true;
    //    bool forceEnabled = true;
    static Settings DefaultSettings();
    static QString toString(const Settings& s);

private:
    Settings m_settings;
    double m_extForce;

    double m_prevExtForce; // for event gen.
    bool m_newEvent;

    double m_prox;
    Eigen::Vector3d m_force;

    int m_patchId;
    int m_cellId;
    qint64 m_ts;

    Event m_event;

public:
    // update and calculates
    ExtForce(const Settings& s = DefaultSettings());
    ExtForce(const Data& data, const Settings& s = DefaultSettings());

    // only updates
    ExtForce(const Event& event, const Settings& s = DefaultSettings());

    // updates the local force and prox vals
    void update(const Data& d);
    void update(const Event& e);

    // calcs the new ext force
    double calc();
    double calc(const Data& data);

    // updated after calc
    bool newEvent() const;

    // returns last calculated extForce
    operator double() const;
    operator const Event&() const;
};


}}

#endif // TUM_ICS_SKIN_EVENTS_CELL_EXTFORCE_H
