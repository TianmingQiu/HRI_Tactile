/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINCORE_OPERATORSV2_BASE_OPERATOR_H
#define SKINCORE_OPERATORSV2_BASE_OPERATOR_H

#include <SkinCore/Implementation/Operator.h>
#include <SkinCore/Implementation/Interface.h>
#include <SkinCore/Implementation/Packets/Version2/Packets.h>
#include <SkinCore/Implementation/Operators/Version2/Base/Timing.h>

#include <SkinCore/Implementation/IntfNode.h>
#include <SkinCore/Implementation/Operators/TaskHandler.h>

#include <QVector>
#include <QTimer>

namespace Skin{
namespace Implementation{
namespace Operators{
namespace Version2{
namespace Base{

class Operator : public Skin::Implementation::Operator
{
    Q_OBJECT

public:


protected:
    Interface* m_intf;
    Base::Timing m_timing;                // timing configuration
    QString m_name;
    IntfNode m_node;

    QVector<TaskHandler*> m_tasks;

    QVector<Endpoint> m_eps;            // active interface nodes and their active ports

    int m_num;                          // number of connected skin cells
    Neighbors m_neighbors;
    QVector<Neighbors> m_nneList;

    bool m_driveEventLoop;
    bool m_connected;
    bool m_ledPwmColorAvailable;

    OperatorError m_error;
    QString m_errorString;


public:
    Operator(QObject* parent = 0,
             Interface* interface = 0);

    ~Operator();

private:

public:
    void setInterface(Interface* interface);
    void setTiming(const Timing& timing);
    void setName(const QString& name);

    void enableEventLoopProcessing(bool enable);

    bool setNode(const IntfNode& n);
    bool setNodes(const QVector<IntfNode>& nodes);

    const Timing& timing() const;
    bool driveEventLoop() const;

    const QString& name() const;

    int numberOfCells() const;
    bool isConnected() const;

    qint64 getTime();

    void clearError();
    Operator::OperatorError error() const;
    QString errorString();

    void handleError(OperatorError error);
    void handleError(OperatorError error, const QString& details);
    QString errorToString(OperatorError error);

protected:
    void setStdStartup();
    void enablePower(bool enable);

public slots:
    void connect();
    void disconnect();

    void sendMemoryCommand(Skin::Implementation::Operator::MemoryCommand cmd);
    void changeLedColor(Skin::Cell::LedColor color,int id=Packets::Version2::ID_ALL);
    void sendPacket(Skin::Implementation::Packet p);

protected slots:
    void handleInterfaceError(Skin::Implementation::Interface::InterfaceError error);
    void handleOperatorError(Skin::Implementation::Operator::OperatorError error);

private slots:
    virtual void parseInterfacePacket();


};

}}}}}

#endif // SKINCORE_OPERATORSV2_BASE_OPERATOR_H
