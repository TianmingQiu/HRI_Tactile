#ifndef TUM_ICS_SKIN_CELL_NEIGHBORSCLIENT_H
#define TUM_ICS_SKIN_CELL_NEIGHBORSCLIENT_H

#include <ros/ros.h>
#include <tum_ics_skin_common/Cell/Neighbors.h>

namespace tum_ics_skin_bridge{
namespace Cell{

class NeighborsClient
{
public:
    static const int BroadcastCellId;

private:
    ros::NodeHandle                 m_node;
    ros::ServiceClient              m_getNeighborsClient;

public:
    NeighborsClient();
    ~NeighborsClient();

    // std service name is: 'getSkinCellNeighbors'

    // broadcast id is rejected
    bool getNeighbors(::Skin::Cell::Neighbors& neigh, int id);

    bool getNeighbors(QVector< ::Skin::Cell::Neighbors>& neigh,
                      const QVector<int>& ids = QVector<int>());

    // empty ids vector means all
    bool getNeighbors(
            QVector< ::Skin::Cell::Neighbors>& neigh,
            const QString& srvName,
            const QVector<int>& ids = QVector<int>());

};


}}

#endif // TUM_ICS_SKIN_CELL_NEIGHBORSCLIENT_H
