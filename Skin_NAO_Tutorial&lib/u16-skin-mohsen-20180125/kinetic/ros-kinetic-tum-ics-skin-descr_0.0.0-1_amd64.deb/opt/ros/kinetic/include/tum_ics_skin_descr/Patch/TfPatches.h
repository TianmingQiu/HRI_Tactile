#ifndef TTUM_ICS_SKIN_DESCR_PATCH_TF_PATCHES_H
#define TTUM_ICS_SKIN_DESCR_PATCH_TF_PATCHES_H

#include <tum_ics_skin_descr/Patch/TfPatch.h>

namespace tum_ics_skin_descr{
namespace Patch{

class TfPatches
{
public:

private:
    QVector<TfPatch*> m_patches;

    QString m_markerNameSpace;
    QString m_cellTfNameBase;

public:
    TfPatches(const QString& markerNameSpace = "SkinCellMarkers",
              const QString& cellTfNameBase = "/sensor_");

    ~TfPatches();

    // false when one failed; automatically skips failed ones
    // overloads existing ones; be careful because former points become invalid
    bool load(const QVector<QString>& filePaths);


    // NOTE: the patches are owned by this class and also destroyed by
    //  this class
    const QVector<TfPatch*>& patches();

private:
    void cleanup();

};

}}



#endif // TTUM_ICS_SKIN_DESCR_PATCH_TF_PATCHES_H
