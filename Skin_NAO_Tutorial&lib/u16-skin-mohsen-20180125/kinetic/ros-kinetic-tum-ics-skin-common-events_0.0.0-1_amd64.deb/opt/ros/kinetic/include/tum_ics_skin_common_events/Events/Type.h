#ifndef TUM_ICS_SKIN_EVENTS_TYPE_H
#define TUM_ICS_SKIN_EVENTS_TYPE_H

#include <ros/ros.h>
#include <tum_ics_skin_msgs_events/EventType.h>

#include <SkinCore/Events/Type.h>

#include <QString>
#include <QVector>

namespace tum_ics_skin_common_events{
namespace Events{

class Type :
       public ::Skin::Events::Type
{
private:
    typedef tum_ics_skin_msgs_events::EventType TypeMsg;

public:
    static Type fromMsg(const TypeMsg& m);

    static TypeMsg toMsg(const ::Skin::Events::Type& t);
    static TypeMsg& toMsg(TypeMsg& m, const ::Skin::Events::Type& t);

    static TypeMsg toMsg();

private:

public:
    Type(int id = 0, const QString& name = "");
    Type(const ::Skin::Events::Type& t);
    Type(const TypeMsg& m);
    Type(const Type& t);

    operator TypeMsg() const;

    TypeMsg msg() const;
    TypeMsg& msg(TypeMsg& m) const;

};

}
}

#endif // TUM_ICS_SKIN_EVENTS_TYPE_H
