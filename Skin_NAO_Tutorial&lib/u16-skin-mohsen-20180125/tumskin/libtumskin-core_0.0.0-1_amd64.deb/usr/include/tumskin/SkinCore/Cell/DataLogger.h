/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKIN_CELL_DATALOGGER_H
#define SKIN_CELL_DATALOGGER_H

#include <QObject>
#include <QFile>
#include <QMutex>
#include <QMap>

#include "MultiFileLogger.h"
#include "Data.h"

namespace Skin{
namespace Cell{

class DataLogger : public QObject
{
    Q_OBJECT


private:
    MultiFileLogger     m_log;
    bool                m_started;
    QMap<int,int>       m_cellIdMap;    // map cell id to index of file vector
    QMutex              m_mutex;
    int                 m_numOfCells;

public:
    DataLogger(const QString& path);


private:
    void log(const Data& d);

public slots:
    void start();
    void stop();

    void newNumberOfCells(int);
    void newDataBunch(QVector<Skin::Cell::Data> d);

signals:
    void stopped();
    void started();

};


}}






#endif // SKIN_CELL_DATALOGGER_H
