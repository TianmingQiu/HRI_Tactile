/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINIMPLPKTS_STARTWRITEPACKETV2_H
#define SKINIMPLPKTS_STARTWRITEPACKETV2_H

#include <SkinCore/Implementation/Packet.h>
#include <SkinCore/Implementation/Packets/Version2/PacketDefinitions.h>

namespace Skin{
namespace Implementation{
namespace Packets {
namespace Version2{
namespace Bootloader{

class StartWritePacket : public Packet
{
public:
    static const int PKT_SIZE = 8;

public:
    StartWritePacket();
    StartWritePacket(int num = 0,
                     int version = VERSION_MAX,
                     const QVector<Endpoint>& dest=QVector<Endpoint>());

    void setVersion(int version);       // 24bit, default to 0xFFFFFF
    void setNumberOfPackets(int num);   // number of write packets

private:
    void init(int num = 0, int version = 0xFFFFFF);



};

}}}}}





#endif // SKINIMPLPKTS_STARTWRITEPACKETV2_H
