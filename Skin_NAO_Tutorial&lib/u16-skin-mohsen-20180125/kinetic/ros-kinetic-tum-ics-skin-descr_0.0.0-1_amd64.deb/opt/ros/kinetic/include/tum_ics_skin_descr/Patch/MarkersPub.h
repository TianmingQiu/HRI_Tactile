#ifndef TUM_ICS_SKIN_DESCR_PATCH_MARKERS_PUB_H
#define TUM_ICS_SKIN_DESCR_PATCH_MARKERS_PUB_H

#include <tum_ics_skin_descr/Patch/Markers.h>

namespace tum_ics_skin_descr{
namespace Patch{

class MarkersPub
{
private:
    typedef QVector< ::Skin::Cell::Data> DataBunch;

protected:
    ros::NodeHandle m_node;
    ros::Publisher m_pub;

    Patch::Markers* m_markers;

public:
    MarkersPub(Markers* m = 0);
    virtual ~MarkersPub();

    void setMarkers(Markers* m);

    // publish markers
    void publish(const ros::Duration& dur=ros::Duration(),
                 const QString& ns="");

private:

};

}}



#endif // TUM_ICS_SKIN_DESCR_PATCH_MARKERS_PUB_H
