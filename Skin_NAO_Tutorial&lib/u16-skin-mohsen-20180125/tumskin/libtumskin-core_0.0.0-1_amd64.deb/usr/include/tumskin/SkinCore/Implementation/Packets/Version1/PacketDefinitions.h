/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINIMPLPKTS_PACKETDEFINITIONSV1_H
#define SKINIMPLPKTS_PACKETDEFINITIONSV1_H

namespace Skin{
namespace Implementation{
namespace Packets{
namespace Version1
{
    const int END_OF_FRAME              = 0xAA;

    namespace ActivePortCalibration
    {
            const char PKT_HEADER            = 0xC0;
            const char SYNC_TOKEN            = 0x50;
    }

}
}
}
}


#endif // SKINIMPLPKTS_PACKETDEFINITIONSV1_H
