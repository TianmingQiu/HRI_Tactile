#ifndef SKINCORE_OPERATORSV2_BASE_TASKHANDLERS_DISTRIBUTEIDSHANDLER_H
#define SKINCORE_OPERATORSV2_BASE_TASKHANDLERS_DISTRIBUTEIDSHANDLER_H

#include <SkinCore/Implementation/Operators/Version2/Base/TaskHandler.h>
#include <SkinCore/Implementation/Operators/Version2/Base/Operator.h>

namespace Skin{
namespace Implementation{
namespace Operators{
namespace Version2{
namespace Base{
namespace TaskHandlers{

class DistributeIdsHandler : public
        Skin::Implementation::Operators::Version2::Base::TaskHandler
{

private:
    QVector<Endpoint>* m_eps;
    int* m_num;

public:
    DistributeIdsHandler(
            Skin::Implementation::Operators::Version2::Base::Operator* op,
            Skin::Implementation::Interface** intf,
            Skin::Implementation::Operators::Version2::Base::Timing* timings,
            QVector<Endpoint>* eps,
            int* numberOfCells);

    virtual bool handleTask();
};


}}}}}}


#endif // SKINCORE_OPERATORSV2_BASE_TASKHANDLERS_DISTRIBUTEIDSHANDLER_H
