#ifndef SKINMANAGERS_RECON_H
#define SKINMANAGERS_RECON_H


#include <QObject>

#include <SkinManagers/Application/Base/Application.h>

#include <SkinCore/Config/Config.h>
#include <SkinRecon/AccDataSampler/Data.h>
#include <SkinRecon/AccDataSampler/Sampler.h>
#include <SkinRecon/Recon.h>

namespace Skin {
namespace Managers{

using namespace Skin::Cell;
using namespace Skin::Reconstruction::AccDataSampler;

class Recon : public QObject
{
    Q_OBJECT

private:

public:


private:
    typedef bool (Recon::*cmd_handler_func)(const QString& s);
    QVector<cmd_handler_func> m_cmdHandlers;
    QString                 m_consoleCmdDescription;

    Skin::Managers::Application::Base::Application* m_app;
    Sampler                     m_sampler;
    Skin::Reconstruction::Recon m_recon;

    int                     m_numberOfCells;
    int                     m_pose;

    bool                    m_started;
    bool                    m_failed;
    bool                    m_nextPose;

    QVector<QThread*>       m_threads;



public:
    explicit Recon(Skin::Managers::Application::Base::Application* app,
                        QObject *parent = 0);

    const QString& consoleCmdDescription() const;
    bool handleConsoleCmd(QString);

    bool started() const;

    bool nextPose() const;
    int pose() const;

    bool autoRecon();

private:
    bool handleReconCommands(const QString& s);

private slots:
    void newNumberOfCells(int);

    void reconFailed();
    void reconRequestNextPose();
    void reconFinished();

public slots:
    void start(int numOfPoses=1, int samples=16);
    void acquireNextPose();

    void newDataBunch(QVector<Skin::Cell::Data> data);

signals:
    void failed();
    void requestNextPose();
    void finished();

    void newSkinConfig(Skin::Config);
};

}}




#endif // SKINMANAGERS_RECON_H
