#ifndef SKINADDITIONS_COLORSHOW_H
#define SKINADDITIONS_COLORSHOW_H


#include <QObject>
#include <QTimer>
#include <QThread>
#include <QMutex>

#include <SkinCore/Cell/Neighbors.h>
#include <SkinManagers/Application/Base/Application.h>
#include <SkinCore/Implementation/Packets/Version2/PacketDefinitions.h>

namespace Skin {
namespace Additions{

class ColorShow : public QObject
{
    Q_OBJECT

public:
    enum Mode
    {
        Broadcast = 0,
        GrowingTree
    };

private:

public:

private:
    typedef bool (ColorShow::*cmd_handler_func)(const QString& s);
    QVector<cmd_handler_func> m_cmdHandlers;
    QString             m_consoleCmdDescription;

    Skin::Managers::Application::Base::Application* m_app;

    QTimer              m_timer;
    bool                m_started;

    QVector<int>        m_idList;   // sorted ids
    int m_colorInd;
    int m_idInd;
    Mode m_mode;

    QMutex              m_colorMutex;
    QVector<QThread*>   m_threads;

public:
    explicit ColorShow(Skin::Managers::Application::Base::Application* app,
                        QObject *parent = 0);

    const QString& consoleCmdDescription() const;
    bool handleConsoleCmd(QString);

private:
    bool handleColorShowCommands(const QString& s);

    void broadcastShow();
    void growingTreeShow();

    void updateColor(int id = Skin::Implementation::Packets::Version2::ID_ALL);

private slots:
    void handleTimer();
    void newNeighborList(QVector<Skin::Cell::Neighbors>);

public slots:
    void start(Skin::Additions::ColorShow::Mode m, int delay);
    void stop();

signals:


};

}}




#endif // SKINADDITIONS_COLORSHOW_H
