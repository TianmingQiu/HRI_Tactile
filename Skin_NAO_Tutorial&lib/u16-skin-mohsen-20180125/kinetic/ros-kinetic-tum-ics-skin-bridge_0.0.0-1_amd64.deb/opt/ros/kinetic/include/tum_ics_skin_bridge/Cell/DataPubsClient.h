#ifndef TUM_ICS_SKIN_CELL_DATAPUBSCLIENT_H
#define TUM_ICS_SKIN_CELL_DATAPUBSCLIENT_H

#include <ros/ros.h>
#include <QString>
#include <QVector>

namespace tum_ics_skin_bridge{
namespace Cell{

class DataPubsClient
{
public:

private:
    ros::NodeHandle m_node;
    QString m_fullTopicName;    // the complete topic path
    QString m_namespace;        // the topic prefix
    QString m_topicName;        // the topic name without prefix

public:
    // takes the topic prefix as prefix for the service calls
    //  to the skin driver
    DataPubsClient(const QString& topicName = "");
    ~DataPubsClient();

    // default: empty = all cells
    // note: if a publisher with the same name already exists
    //          then this publisher is overwritten!
    bool create(const QString& topicName, const QVector<int>& ids = QVector<int>());
    bool create(const QVector<int>& ids = QVector<int>());

    // enables/disables publisher
    bool enable();
    bool disable();

    bool setEnabled(bool enable);

private:
    QString getMsgNamespace(const QString& fullMsgName);
    QString getMsgName(const QString& fullMsgName);

};


}}

#endif // TUM_ICS_SKIN_CELL_DATAPUBSCLIENT_H
