#ifndef TUM_ICS_TFS_INTERACTIVE_TF_H
#define TUM_ICS_TFS_INTERACTIVE_TF_H

#include <QString>
#include <QMutex>

#include <interactive_markers/interactive_marker_server.h>
#include <tum_ics_tfs/TfContainerPub.h>

namespace tum_ics_tfs{

class InteractiveTf
{
public:

private:
    interactive_markers::InteractiveMarkerServer m_server;
    TfContainerPub m_tf;    // tf of the iTf
    QMutex m_mutex;

public:
    InteractiveTf(const QString& name,
                  const QString& baseFrame,
                  double scale = 1.0,
                  const QString& nameSpace  = "Default");

    InteractiveTf(const QString& name,
                  const QString& baseFrame,
                  const tf::Transform& tf   = tf::Transform::getIdentity(),
                  double scale = 1.0,
                  const QString& nameSpace  = "Default");

    InteractiveTf(const QString& name,
                  const QString& baseFrame,
                  const Eigen::Affine3d& tf,
                  double scale = 1.0,
                  const QString& nameSpace  = "Default");

    InteractiveTf(const TfBranch& tfBranch  = TfBranch::Default(),
                  const tf::Transform& tf   = tf::Transform::getIdentity(),
                  double scale = 1.0);

    InteractiveTf(const TfBranch& tfBranch,
                  const Eigen::Affine3d& tf,
                  double scale = 1.0);

    InteractiveTf(const TfContainer& tfc,
                  double scale = 1.0);

    ~InteractiveTf();


    // publish stamped tf
    void publish(const ros::Time& t = ros::Time::now());

    TfContainer tf();

private:
    void createInteractiveMarker(const QString& baseFrame,
                                 geometry_msgs::Pose pose, double scale);


    void processFeedback(
            const visualization_msgs::InteractiveMarkerFeedbackConstPtr &feedback);

};

}

#endif // TUM_ICS_TFS_INTERACTIVE_TF_H
