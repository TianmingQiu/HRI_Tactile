/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINCORE_EVENTS_EVENTBASE_H
#define SKINCORE_EVENTS_EVENTBASE_H

#include <QVector>
#include <QMetaType>

#include <SkinCore/Events/Type.h>

namespace Skin{
namespace Events{

class EventBase
{
public:

private:
    // event address for comparison and localization
    Type m_type;            // type id, optionally type name

    // value of the event
    double m_value;         // normalized value (-1 ... 1) or (0 ... 1)
    qint64 m_ts;            // timestamp in ns

public:
    // undefined event
    EventBase(const Type& t = Type(),
          double val = 0,
          qint64 ts = -1);

    EventBase(const EventBase& e);
    ~EventBase();

    operator const Type& () const;

    // only check type id
    bool operator== (const EventBase& other) const;
    bool operator!= (const EventBase& other) const;

    // for QMap
    bool operator< (const EventBase& other) const;

    void setValue(double value = 0.0, qint64 ts = -1);

    const Type& type() const;
    const QString& name() const;
    double value() const;
    qint64 ts() const;

    QString toString() const;

private:


};

}}

QTextStream& operator << (QTextStream& s, const Skin::Events::EventBase& e);
QTextStream& operator >> (QTextStream& s, Skin::Events::EventBase& e);


Q_DECLARE_METATYPE(Skin::Events::EventBase)
Q_DECLARE_METATYPE(QVector<Skin::Events::EventBase>)

#endif // SKINCORE_EVENTS_EVENTBASE_H
