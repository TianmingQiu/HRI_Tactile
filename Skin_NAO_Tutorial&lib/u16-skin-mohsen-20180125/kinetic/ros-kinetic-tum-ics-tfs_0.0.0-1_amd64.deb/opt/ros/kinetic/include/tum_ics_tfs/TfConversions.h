#ifndef TUM_ICS_TFS_TF_CONVERSIONS_H
#define TUM_ICS_TFS_TF_CONVERSIONS_H

#include <QString>
#include <tf_conversions/tf_eigen.h>

namespace tum_ics_tfs{

class TfConversions
{
public:
    static Eigen::Vector3d toPosEigen(const Eigen::Affine3d& tf);
    static Eigen::Vector3d toPosEigen(const tf::Vector3& pos);
    static Eigen::Vector3d toPosEigen(const tf::Transform& tf);
    static Eigen::Vector3d toPosEigen(const geometry_msgs::Pose& pose);


    static Eigen::Matrix3d toRotEigen(const Eigen::Affine3d& tf);
    static Eigen::Matrix3d toRotEigen(const Eigen::Quaterniond& q);
    static Eigen::Matrix3d toRotEigen(const tf::Quaternion& q);
    static Eigen::Matrix3d toRotEigen(const tf::Transform& tf);
    static Eigen::Matrix3d toRotEigen(const geometry_msgs::Pose& pose);


    static Eigen::Quaterniond toQuaternionEigen(const Eigen::Affine3d& tf);
    static Eigen::Quaterniond toQuaternionEigen(const Eigen::Matrix3d& rot);
    static Eigen::Quaterniond toQuaternionEigen(const tf::Quaternion& q);
    static Eigen::Quaterniond toQuaternionEigen(const tf::Transform& tf);
    static Eigen::Quaterniond toQuaternionEigen(const geometry_msgs::Pose& pose);


    static Eigen::Affine3d toPoseEigen(const Eigen::Matrix3d& rot,
                                       const Eigen::Vector3d& pos);

    static Eigen::Affine3d toPoseEigen(const Eigen::Quaterniond& q,
                                       const Eigen::Vector3d& pos);

    static Eigen::Affine3d toPoseEigen(const tf::Quaternion& q,
                                       const tf::Vector3& pos);

    static Eigen::Affine3d toPoseEigen(const tf::Transform& tf);
    static Eigen::Affine3d toPoseEigen(const geometry_msgs::Pose& pose);


    static tf::Vector3 toPosTf(const Eigen::Affine3d& tf);
    static tf::Vector3 toPosTf(const Eigen::Vector3d& pos);
    static tf::Vector3 toPosTf(const tf::Transform& tf);
    static tf::Vector3 toPosTf(const geometry_msgs::Pose& pose);


    static tf::Quaternion toQuaternionTf(const Eigen::Affine3d& tf);
    static tf::Quaternion toQuaternionTf(const Eigen::Matrix3d& rot);
    static tf::Quaternion toQuaternionTf(const Eigen::Quaterniond& q);
    static tf::Quaternion toQuaternionTf(const tf::Transform& tf);
    static tf::Quaternion toQuaternionTf(const geometry_msgs::Pose& pose);


    static tf::Transform toPoseTf(const Eigen::Affine3d& tf);

    static tf::Transform toPoseTf(const Eigen::Matrix3d& rot,
                                  const Eigen::Vector3d& pos);

    static tf::Transform toPoseTf(const Eigen::Quaterniond& q,
                                  const Eigen::Vector3d& pos);

    static tf::Transform toPoseTf(const tf::Quaternion& q,
                                  const tf::Vector3& pos);

    static tf::Transform toPoseTf(const geometry_msgs::Pose& pose);


    static geometry_msgs::Quaternion toQuaternionMsg(const Eigen::Affine3d& tf);
    static geometry_msgs::Quaternion toQuaternionMsg(const Eigen::Matrix3d& rot);
    static geometry_msgs::Quaternion toQuaternionMsg(const Eigen::Quaterniond& q);
    static geometry_msgs::Quaternion toQuaternionMsg(const tf::Quaternion& q);
    static geometry_msgs::Quaternion toQuaternionMsg(const tf::Transform& tf);



    static geometry_msgs::Pose toPoseMsg(const Eigen::Affine3d& tf);

    static geometry_msgs::Pose toPoseMsg(const Eigen::Matrix3d& rot,
                                         const Eigen::Vector3d& pos);

    static geometry_msgs::Pose toPoseMsg(const Eigen::Quaterniond& q,
                                         const Eigen::Vector3d& pos);

    static geometry_msgs::Pose toPoseMsg(const tf::Transform& tf);

    static geometry_msgs::Pose toPoseMsg(const tf::Quaternion& q,
                                         const tf::Vector3& pos);


    static QString toString(const Eigen::MatrixXd& m);
    static QString toString(const Eigen::Affine3d& tf);
    static QString toString(const Eigen::Quaterniond& q);


    // Euler: Z, Y, X => yaw, roll, pitch
    static Eigen::Vector3d toRPYEigenRad(const Eigen::Affine3d& tf);
    static Eigen::Vector3d toRPYEigenRad(const Eigen::Matrix3d& rot);
    static Eigen::Vector3d toRPYEigenRad(const Eigen::Quaterniond& q);
    static Eigen::Vector3d toRPYEigenRad(const tf::Transform& tf);
    static Eigen::Vector3d toRPYEigenRad(const tf::Quaternion& q);
    static Eigen::Vector3d toRPYEigenRad(const geometry_msgs::Pose& pose);

    static Eigen::Vector3d toRPYEigenDeg(const Eigen::Affine3d& tf);
    static Eigen::Vector3d toRPYEigenDeg(const Eigen::Matrix3d& rot);
    static Eigen::Vector3d toRPYEigenDeg(const Eigen::Quaterniond& q);
    static Eigen::Vector3d toRPYEigenDeg(const tf::Transform& tf);
    static Eigen::Vector3d toRPYEigenDeg(const tf::Quaternion& q);
    static Eigen::Vector3d toRPYEigenDeg(const geometry_msgs::Pose& pose);

    static Eigen::Matrix3d rotEigenFromRPYEigenRad(const Eigen::Vector3d& rpy);
    static Eigen::Matrix3d rotEigenFromRPYEigenDeg(const Eigen::Vector3d& rpy);



    static Eigen::Affine3d& setPos(Eigen::Affine3d& tf,
                                   const Eigen::Vector3d& pos);

    static Eigen::Affine3d& setPos(Eigen::Affine3d& tf,
                                   const tf::Vector3& pos);

    static Eigen::Affine3d& setRot(Eigen::Affine3d& tf,
                                   const Eigen::Matrix3d& rot);

    static Eigen::Affine3d& setQuaternion(Eigen::Affine3d& tf,
                                   const Eigen::Quaterniond& q);

    static Eigen::Affine3d& setQuaternion(Eigen::Affine3d& tf,
                                   const tf::Quaternion& q);


    static Eigen::Affine3d setPos(const Eigen::Affine3d& tf,
                                  const Eigen::Vector3d& pos);

    static Eigen::Affine3d setPos(const Eigen::Affine3d& tf,
                                  const tf::Vector3& pos);

    static Eigen::Affine3d setRot(const Eigen::Affine3d& tf,
                                  const Eigen::Matrix3d& rot);

    static Eigen::Affine3d setQuaternion(const Eigen::Affine3d& tf,
                                         const Eigen::Quaterniond& q);

    static Eigen::Affine3d setQuaternion(const Eigen::Affine3d& tf,
                                         const tf::Quaternion& q);



    static tf::Transform& setPos(tf::Transform& tf,
                                   const Eigen::Vector3d& pos);

    static tf::Transform& setPos(tf::Transform& tf,
                                   const tf::Vector3& pos);

    static tf::Transform& setRot(tf::Transform& tf,
                                   const Eigen::Matrix3d& rot);

    static tf::Transform& setQuaternion(tf::Transform& tf,
                                   const Eigen::Quaterniond& q);

    static tf::Transform& setQuaternion(tf::Transform& tf,
                                   const tf::Quaternion& q);

public:

private:
    TfConversions();

};

}

#endif // TUM_ICS_TFS_TF_CONVERSIONS_H
