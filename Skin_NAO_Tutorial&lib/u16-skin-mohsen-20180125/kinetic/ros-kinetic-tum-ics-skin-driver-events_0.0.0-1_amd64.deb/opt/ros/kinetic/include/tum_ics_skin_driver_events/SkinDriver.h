#ifndef TUM_ICS_SKIN_DRIVER_EVENTS_SKIN_DRIVER_H
#define TUM_ICS_SKIN_DRIVER_EVENTS_SKIN_DRIVER_H

#include <QApplication>
#include <QHostAddress>
#include <QObject>
#include <QVector>
#include <QStringList>

//This definition is needed with libboost 1.58
#ifndef Q_MOC_RUN
#include <SkinManagers/Application/Standard/Application.h>
#include <SkinManagers/Recon/Recon.h>

#include <SkinAdditions/UpdateRate/UpdateRate.h>
#include <SkinAdditions/ColorFeedback/ColorFeedback.h>
#include <SkinAdditions/NeighborTest/NeighborTest.h>

#include <SkinEvents/Managers/Events/Manager.h>
#include <SkinEvents/Converters/Data/Converter.h>
#include <SkinEvents/Converters/Event/Unpacker.h>
#include <SkinEvents/Converters/Data/EventsConverter.h>

#include <tum_ics_skin_driver/RosUpdate.h>
#include <tum_ics_skin_driver_events/RosSkin.h>
#include <tum_ics_skin_driver_events/MainConsole.h>
#endif

namespace tum_ics_skin_driver_events{

class SkinDriver
{

private:
    typedef Skin::Managers::Application::Standard::Application Application;

    MainConsole     m_console;
    QApplication*   m_qapp;

    Skin::Managers::Application::Standard::Application  m_app;

    Skin::Additions::UpdateRate                         m_updateRate;
    Skin::Additions::ColorFeedback                      m_colorFeedback;
    Skin::Additions::NeighborTest                       m_neighborTest;

    Skin::Managers::Events::Manager                     m_events;

    Skin::Events::Converters::Event::Unpacker           m_eventsUnpacker;
    Skin::Events::Converters::Data::EventsConverter     m_eventsConverter;

    tum_ics_skin_driver::RosUpdate m_up;
    RosSkin m_rs;

    QStringList m_args;

    Skin::Implementation::IntfNode       m_node;
    Skin::Managers::Application::Type   m_type;
    int m_udr;

    bool m_isTSU;
    int m_minArgs;
    int m_uRateIndx;
    int m_versionIndx;

public:
    SkinDriver(QApplication* app);

    Application* app();

    bool init();
    int exec();

private:
    bool getIntfNode();
    bool getAppType();
    bool getUpdateRate();

    // TODO: unclean way: fix this in the future
    void loadEventThresholdsParam();

};

}

#endif // TUM_ICS_SKIN_DRIVER_EVENTS_SKIN_DRIVER_H
