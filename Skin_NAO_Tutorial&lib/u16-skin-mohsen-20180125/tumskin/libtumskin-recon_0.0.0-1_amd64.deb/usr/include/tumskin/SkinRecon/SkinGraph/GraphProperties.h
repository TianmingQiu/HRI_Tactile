/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINRECON_SKINGRAPH_GRAPHPROPERTIES_H
#define SKINRECON_SKINGRAPH_GRAPHPROPERTIES_H


#include <QVector>

namespace Skin{
namespace Reconstruction{
namespace SkinGraph{

struct GraphProperties
{
    int             numberOfPatches;
    QVector<int>    patchRootCellIds; // ordered vector, at index 0: root cellID of patch 1
    QVector<double> patchShortestAccumulatedPaths;

public:
    GraphProperties();
    GraphProperties(const GraphProperties& p);
    ~GraphProperties();

};


}
}
}



#endif // SKINRECON_SKINGRAPH_GRAPHPROPERTIES_H
