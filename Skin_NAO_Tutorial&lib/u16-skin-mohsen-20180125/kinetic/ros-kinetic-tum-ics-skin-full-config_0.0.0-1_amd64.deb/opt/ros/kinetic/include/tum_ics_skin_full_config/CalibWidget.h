#ifndef TUM_ICS_SKIN_FULL_CONFIG_CALIB_WIDGET_H
#define TUM_ICS_SKIN_FULL_CONFIG_CALIB_WIDGET_H

#include <QWidget>
#include <QStatusBar>

//This definition is needed with libboost 1.58
#ifndef Q_MOC_RUN
#include <tum_ics_skin_full_config/CalibAutoConfigWidget.h>
#include <tum_ics_skin_full_config/CalibCustomConfigWidget.h>
#include <tum_ics_skin_full_config/CalibExtTfWidget.h>
#endif

namespace tum_ics_skin_full_config
{

namespace Ui {
class CalibWidget;
}

class CalibWidget : public QWidget
{
    Q_OBJECT

private:
    Ui::CalibWidget *ui;

    CalibAutoConfigWidget* m_wAutoConfig;
    CalibCustomConfigWidget* m_wCustomConfig;
    CalibExtTfWidget* m_wExtTf;

    QStatusBar* m_sb;

public:
    explicit CalibWidget(QWidget *parent = 0);
    ~CalibWidget();

    bool init(QStatusBar* sb, const QString& defaultPath=".");

    void setDefaultPath(const QString& path=".");

    void update();

    CalibAutoConfigWidget* autoConfigWidget();
    CalibCustomConfigWidget* customConfigWidget();
    CalibExtTfWidget* extTfWidget();

};

}

#endif // TUM_ICS_SKIN_FULL_CONFIG_CALIB_WIDGET_H
