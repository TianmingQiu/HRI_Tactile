#ifndef SKINIMPLS_UPDATER_H
#define SKINIMPLS_UPDATER_H


#include <QObject>
#include <QThread>

#include <SkinCore/Implementation/Updaters/Version2/StdUpdater.h>

namespace Skin {
namespace Managers{
namespace Updater{

namespace UpsV2 = Skin::Implementation::Updaters::Version2;

class Updater : public QObject
{
    Q_OBJECT

public:
    enum UpdaterType
    {
        SingleIntfTsu    = 0,
        SingleIntfFtdi,
        MultiIntfTsu,       // -> down from here: NOT supported
        MultiIntfFtdi
    };

private:
    typedef bool (Updater::*cmd_handler_func)(const QString& s);
    QVector<cmd_handler_func> m_cmdHandlers;

    QString                         m_consoleCmdDescription;
    UpdaterType                     m_currUpdaterType;


    UpsV2::StdUpdater*              m_currUpdater;
    QList<UpsV2::StdUpdater*>       m_updaters;

    QVector<QThread*>               m_threads;

public:
    explicit Updater(QObject *parent = 0);

    UpdaterType type() const;
    bool isProgramming() const;

    UpsV2::StdUpdater* updater();

    const QString& consoleCmdDescription() const;
    bool handleConsoleCmd(QString);

private:
    void connectUpdater(Skin::Implementation::Programmer* prog);
    void disconnectUpdater(Skin::Implementation::Programmer* prog);

    bool handleInterfaceCommands(const QString& s);
    bool handleUpdaterCommands(const QString& s);

private slots:


public slots:
    void switchUpdater(Skin::Managers::Updater::Updater::UpdaterType t);
    void program();

signals:
    void programFailed(void);
    void programmed(void);

};

}}}

#endif // SKINIMPLS_UPDATER_H
