#ifndef SKINCORE_OPERATORSV2V2_BASE_TASKHANDLERS_EXPLORENEARESTNEIGHBORSHANDLER_H
#define SKINCORE_OPERATORSV2V2_BASE_TASKHANDLERS_EXPLORENEARESTNEIGHBORSHANDLER_H

#include <SkinCore/Implementation/Operators/Version2/Base/TaskHandler.h>
#include <SkinCore/Implementation/Operators/Version2/Base/Operator.h>

namespace Skin{
namespace Implementation{
namespace Operators{
namespace Version2V2{
namespace Base{
namespace TaskHandlers{

class ExploreNearestNeighborsHandler : public
        Skin::Implementation::Operators::Version2::Base::TaskHandler
{

private:

public:
    ExploreNearestNeighborsHandler(
            Skin::Implementation::Operators::Version2::Base::Operator* op,
            Skin::Implementation::Interface** intf,
            Skin::Implementation::Operators::Version2::Base::Timing* timings);

    virtual bool handleTask();
};

}}}}}}

#endif // SKINCORE_OPERATORSV2V2_BASE_TASKHANDLERS_EXPLORENEARESTNEIGHBORSHANDLER_H
