#ifndef SKINMANAGERS_UPDATER_IMPLEMENTATION_H
#define SKINMANAGERS_UPDATER_IMPLEMENTATION_H

#include <QObject>
#include <SkinCore/Implementation/Interface.h>
#include <SkinCore/Implementation/Updaters/Version2/StdUpdater.h>

namespace Skin{
namespace Managers{
namespace Updater{

typedef Skin::Implementation::Interface IntfBase;
typedef Skin::Implementation::Updaters::Version2::StdUpdater UpBase;

// test if type T is derived from type B
template<class T, class B> struct Derived_from {
    static void constraints(T* p) { B* pb = p; }
    Derived_from() { void(*p)(T*) = constraints; }
};

template<class Up, class Intf>
class Implementation : public Up
{

public:
    static Up* create()
    {
        Up* p = new Implementation();
        return p;
    }

private:
    Intf* m_intf;

public:
    Implementation(QObject* parent = 0) : Up(parent)
    {
        Derived_from<Intf,IntfBase>();
        Derived_from<Up,UpBase>();

        m_intf = new Intf(this);

        Up::setInterface(m_intf);

        QString name = Up::name();
        Up::setName(m_intf->name() + ", " + name);

        QObject::connect(m_intf,SIGNAL(error(Skin::Implementation::Interface::InterfaceError)),
                         this,SLOT(handleInterfaceError(Skin::Implementation::Interface::InterfaceError)));

        QObject::connect(this,SIGNAL(error(Skin::Implementation::Programmer::ProgrammerError)),
                         this,SLOT(handleProgrammerError(Skin::Implementation::Programmer::ProgrammerError)));
    }

    ~Implementation(){}
};



}}}





#endif // SKINMANAGERS_UPDATER_IMPLEMENTATION_H
