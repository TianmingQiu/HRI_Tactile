/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINIMPLPKTS_PINGPACKETV2_H
#define SKINIMPLPKTS_PINGPACKETV2_H

#include <SkinCore/Implementation/Packet.h>
#include <SkinCore/Implementation/Packets/Version2/PacketDefinitions.h>

namespace Skin{
namespace Implementation{
namespace Packets {
namespace Version2{
namespace Commands{

class PingPacket : public Packet
{

public:
    static bool check(const Packet& p);
    static qint64 getStartTimeStamp(const Packet& p);

    static const int PKT_SIZE = 20;
    static Packet& setId(Packet& p, int id);


public:
    PingPacket(int id=ID_ALL,
               const QVector<Endpoint>& dest=QVector<Endpoint>());

    PingPacket(qint64 ts, int id=ID_ALL,
               const QVector<Endpoint>& dest=QVector<Endpoint>());

    void setId(int id);
    void setStartTimeStamp(qint64 ts);
    qint64 getStartTimeStamp();

private:
    void init(qint64 ts=0, int id=0);

};

}}}}}

#endif // SKINIMPLPKTS_PINGPACKETV2_H
