#ifndef TUM_ICS_SKIN_DRIVER_EVENTS_EVENT_PUB_MANAGER_H
#define TUM_ICS_SKIN_DRIVER_EVENTS_EVENT_PUB_MANAGER_H

#include <QVector>
#include <QMap>
#include <QMutex>

//This definition is needed with libboost 1.58
#ifndef Q_MOC_RUN
#include <ros/ros.h>
#include <tum_ics_skin_msgs_events/createSkinCellEventPub.h>
#include <tum_ics_skin_msgs_events/enableSkinCellEventPub.h>

#include <tum_ics_skin_driver_events/EventPublisher.h>
#endif

namespace tum_ics_skin_driver_events{

class EventPubManager
{
private:
    typedef tum_ics_skin_common_events::Cell::Events::EventsConfig EventsConfig;

private:
    ros::NodeHandle m_node;
    ros::ServiceServer              m_createSkinCellEventPubSrv;
    ros::ServiceServer              m_enableSkinCellEventPubSrv;

    QVector<int> m_ids;             // ids of all available cells
    bool m_initialized;

    QVector<EventPublisher*>        m_eventPubs;
    QMap<QString,int>               m_eventPubMap;   // map: str -> pub

    QMutex                          m_eventPubsMutex;

public:
    EventPubManager();
    ~EventPubManager();

    void init(const QVector<int>& ids);

    // publish data
    void publish(const QVector<Skin::Cell::Events::Event>&);

private:
    bool createSkinCellEventPubCallback(
            tum_ics_skin_msgs_events::createSkinCellEventPub::Request &req,
            tum_ics_skin_msgs_events::createSkinCellEventPub::Response &res);

    bool enableSkinCellEventPubCallback(
            tum_ics_skin_msgs_events::enableSkinCellEventPub::Request &req,
            tum_ics_skin_msgs_events::enableSkinCellEventPub::Response &res);


};

}



#endif // TUM_ICS_SKIN_DRIVER_EVENTS_EVENT_PUB_MANAGER_H
