#! /bin/bash
sudo \cp -rvf ft232H.rules /etc/udev/rules.d/ft232H.rules
sudo udevadm trigger 
sudo reload udev 

