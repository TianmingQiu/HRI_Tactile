#ifndef TUM_ICS_SKIN_DRIVER_EVENTS_IP_ENDPOINT_PRIVATE_H
#define TUM_ICS_SKIN_DRIVER_EVENTS_IP_ENDPOINT_PRIVATE_H

#include <qglobal.h>

#include <QString>
#include <QVector>
#include <QStringList>

namespace tum_ics_skin_driver_events{

class IpEndpoint;

/*!
 * \brief The private class for the IpEndpoint class.
 */
class IpEndpointPrivate
{
public:
    /*!
      \brief The macro for simple access to the public class.
    */
    Q_DECLARE_PUBLIC(IpEndpoint)

    /*!
     * \brief The pointer to the public class.
    */
    IpEndpoint* q_ptr;

public:
    static bool parseIpEndpoint(
            quint32& ipAddr,
            quint16& port,
            const QString& ipEndpointStr,
            bool *ok = 0)
    {
        bool okTemp = false;
        if(ok == 0)
        {
            ok = &okTemp;
        }

        *ok = false;

        QStringList sl = ipEndpointStr.split(":",QString::SkipEmptyParts);

        if(sl.size() != 2)
        {
            return false;
        }

        // fall back to default
        ipAddr = 0;
        port = 0;

        bool ipAddrOk;
        quint32 newIpAddr = parseIpAddr(sl.at(0),&ipAddrOk);
        if(!ipAddrOk)
        {
            return false;
        }

        bool portOk;
        quint16 newPort = parsePort(sl.at(1),&portOk);
        if(!portOk)
        {
            return false;
        }

        ipAddr = newIpAddr;
        port = newPort;

        *ok = true;
        return true;
    }

    static quint32 parseIpAddr(const QString& ipAddrStr, bool* ok=0)
    {
        bool okTemp = false;
        if(ok == 0)
        {
            ok = &okTemp;
        }

        *ok = false;

        QStringList sl = ipAddrStr.split(".",QString::SkipEmptyParts);
        if(sl.size() != 4)
        {
            return 0;
        }

        QVector<uint> ipAddrBytes;
        for(int i=0; i<sl.size(); i++)
        {
            bool byteOk;
            uint byte = sl.at(i).toUInt(&byteOk);
            if(!byteOk)
            {
                return 0;
            }

            if(byte > 255)
            {
                return 0;
            }
            ipAddrBytes << byte;
        }

        quint32 newIpAddr = 0;
        newIpAddr |= ipAddrBytes.at(0) << 24;
        newIpAddr |= ipAddrBytes.at(1) << 16;
        newIpAddr |= ipAddrBytes.at(2) << 8;
        newIpAddr |= ipAddrBytes.at(3) << 0;

        *ok = true;
        return newIpAddr;
    }

    static quint16 parsePort(const QString& port, bool* ok=0)
    {
        bool okTemp = false;
        if(ok == 0)
        {
            ok = &okTemp;
        }

        *ok = false;

        bool portOk;
        uint newPort = port.toUInt(&portOk);
        if(!portOk)
        {
            return 0;
        }

        if(newPort > 65535)
        {
            return 0;
        }

        *ok = true;
        return newPort;
    }

public:
    quint32 ipAddr;     //!< the bytes of the ip address; highest byte at MSByte
    quint16 port;

public:
    /*!
     * \brief Default constructor.
     * \param q is the public class of this private class.
     */
    IpEndpointPrivate(IpEndpoint* q) :
        q_ptr(q),
        ipAddr(0),
        port(0)
    {
    }

    /*!
     * \brief Constructor.
     */
    IpEndpointPrivate(IpEndpoint* q, quint32 ipAddr, quint16 port) :
        q_ptr(q),
        ipAddr(ipAddr),
        port(port)
    {
    }

    /*!
     * \brief Constructor.
     */
    IpEndpointPrivate(IpEndpoint* q, const QString& ipAddrStr, quint16 port) :
        q_ptr(q),
        ipAddr(parseIpAddr(ipAddrStr)),
        port(port)
    {
    }

    /*!
     * \brief Constructor.
     */
    IpEndpointPrivate(IpEndpoint* q, const QString& ipEndpointStr) :
        q_ptr(q)
    {
        parseIpEndpoint(ipAddr,port,ipEndpointStr);
    }

    /*!
     * \brief Copy constructor.
     */
    IpEndpointPrivate(IpEndpoint* q, const IpEndpoint& other) :
        q_ptr(q),
        ipAddr(other.d_func()->ipAddr),
        port(other.d_func()->port)
    {
    }

    /*!
     * \brief Assignment operator.
     */
    IpEndpointPrivate& operator=(const IpEndpointPrivate& other)
    {
        if(this == &other)
        {
            return *this;
        }

        ipAddr = other.ipAddr;
        port = other.port;

        return *this;
    }

};

}

#endif // TUM_ICS_SKIN_DRIVER_EVENTS_IP_ENDPOINT_PRIVATE_H
