#ifndef TUM_ICS_SKIN_FULL_CONFIG_CALIB_SKIN_DRIVER_WIDGET_H
#define TUM_ICS_SKIN_FULL_CONFIG_CALIB_SKIN_DRIVER_WIDGET_H

#include <QWidget>

#include <QComboBox>
#include <QPushButton>
#include <QStatusBar>


namespace tum_ics_skin_full_config
{

namespace Ui {
class CalibSkinDriverWidget;
}

class CalibSkinDriverWidget : public QWidget
{
    Q_OBJECT

private:
    Ui::CalibSkinDriverWidget *ui;

    QComboBox* m_cbPrefix;
    QStatusBar* m_sb;

public:
    explicit CalibSkinDriverWidget(QWidget *parent = 0);
    ~CalibSkinDriverWidget();

    bool init(QStatusBar* sb);

    QString prefix() const;
};

}

#endif // TUM_ICS_SKIN_FULL_CONFIG_CALIB_SKIN_DRIVER_WIDGET_H
