/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKININTFFTDI_FTDIMULTIINTERFACEV2V0_H
#define SKININTFFTDI_FTDIMULTIINTERFACEV2V0_H

#include <SkinCore/Implementation/Interface.h>
#include <SkinIntfFtdi/Implementation/Interfaces/FtdiPort/FtdiPort.h>
#include <SkinCore/Implementation/IntfNode.h>
#include <SkinCore/Implementation/IntfNodes.h>

#include <QElapsedTimer>
#include <QTimer>

namespace Skin{
namespace Implementation{
namespace Interfaces{
namespace Version2V0{
namespace Ftdi{
namespace MultiInterface{


class FtdiInterface : public Interface
{
    Q_OBJECT

private:
    static const int ALIVE_INTERVAL        = 100;      // ms
    static const int TYPE;
    static const QString NAME;

private:
    QVector<FtdiNode> m_usrNodes;

    QVector<FtdiNode> m_nodes;
    QVector<FtdiPort*> m_ports;

    bool            m_ledToggleFlag;
    bool            m_initialized;

    QElapsedTimer   m_timer;

    InterfaceError  m_error;
    QString         m_errorString;


    QTimer*         m_aliveTimer;
    QMutex          m_portMutex;

    int             m_lastReadInd;  // for round robin to avoid greedy reads

public:
    explicit FtdiInterface(QObject* parent = 0);
    ~FtdiInterface();

    bool setNode(const IntfNode& node = FtdiNode::StdNode);
    bool setNodes(const QVector<IntfNode>& nodes = IntfNodes(FtdiNode::AvailableNodes));

    bool init();
    bool deinit();

    int type() const;
    QString name() const;

    bool isInitialized() const;
    bool hasPendingPackets();

    bool enablePower(bool enable);

    bool readPacket(Packet& p);
    bool writePacket(const Packet& p);

    bool flushRx();

    qint64 getTime();

    void clearError();
    Interface::InterfaceError error() const;
    QString errorString();


private:
    void updateAvailableConns();

    bool initConns();
    void deinitConns();

    void writeData(const TimestampedData& data);
    void writeData(int ind, const TimestampedData& data);

    void handleError(InterfaceError error);
    void handleError(InterfaceError error, const QString& details);
    QString errorToString(InterfaceError error);


signals:

private slots:
    void sendAlive();

};

}
}
}
}
}
}



#endif // SKININTFFTDI_FTDIMULTIINTERFACEV2V0_H
