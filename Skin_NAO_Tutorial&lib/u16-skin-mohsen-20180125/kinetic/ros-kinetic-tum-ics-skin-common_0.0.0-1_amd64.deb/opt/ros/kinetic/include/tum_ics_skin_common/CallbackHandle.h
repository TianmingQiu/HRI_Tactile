#ifndef TUM_ICS_SKIN_CALLBACK_HANDLE_H
#define TUM_ICS_SKIN_CALLBACK_HANDLE_H

#include <tum_ics_skin_common/CallbackCaller.h>

// TODO: this class should NOT be a template class

namespace tum_ics_skin_common{

template<class D> class CallbackCaller;


template<class D>
class CallbackHandle
{
public:
    CallbackCaller<D>* m_caller;
    int m_handle;

public:
    CallbackHandle() :
        m_caller(0),
        m_handle(0)
    {

    }

    CallbackHandle(CallbackCaller<D>* caller, int handle) :
        m_caller(caller),
        m_handle(handle)
    {

    }

    CallbackHandle(const CallbackHandle& cb) :
        m_caller(cb.m_caller),
        m_handle(cb.m_handle)
    {

    }

    ~CallbackHandle(){}

    int handle() const
    {
        return m_handle;
    }

    void shutdown()
    {
        if(m_caller == 0)
        {
            return;
        }

        m_caller->remove(*this);
    }

};

}

#endif // TUM_ICS_SKIN_CALLBACK_HANDLE_H
