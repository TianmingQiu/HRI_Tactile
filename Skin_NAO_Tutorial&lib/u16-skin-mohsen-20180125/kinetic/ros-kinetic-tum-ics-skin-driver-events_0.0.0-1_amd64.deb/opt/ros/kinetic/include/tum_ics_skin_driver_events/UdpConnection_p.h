#ifndef TUM_ICS_TOOLS_UDP_CONNECTION_PRIVATE_H
#define TUM_ICS_TOOLS_UDP_CONNECTION_PRIVATE_H

#include <qglobal.h>
#include <QObject>

// needs: SET(QT_USE_QTNETWORK TRUE)"
#include <QUdpSocket>
#include <QElapsedTimer>
#include <QTimer>
#include <QTime>

#include <tum_ics_skin_driver_events/IpEndpoint.h>

namespace tum_ics_skin_driver_events{

class UdpConnection;

/*!
 * \brief The private class for the UdpConnection class.
 */
class UdpConnectionPrivate
{
public:
    /*!
      \brief The macro for simple access to the private class.
    */
    Q_DECLARE_PUBLIC(UdpConnection)

    /*!
     * \brief The pointer to the public class.
    */
    UdpConnection* const q_ptr;

public:

public:
    QUdpSocket*     sock;

    IpEndpoint local;
    IpEndpoint client;

    bool            opened;

public:
    /*!
     * \brief Default constructor.
     * \param q is the public class of this private class.
     */
    UdpConnectionPrivate(UdpConnection* q) :
        q_ptr(q),
        sock(new QUdpSocket(q)),
        opened(false)
    {
    }

    /*!
     * \brief Deconstructor.
     */
    ~UdpConnectionPrivate()
    {
        delete sock;
    }

private:
    /*!
     * \brief Not copyable.
     */
    UdpConnectionPrivate(UdpConnection* q, const UdpConnectionPrivate& other);

    /*!
     * \brief Not assignable.
     */
    UdpConnection& operator=(const UdpConnection& other);
};

}

#endif // TUM_ICS_TOOLS_UDP_CONNECTION_PRIVATE_H
