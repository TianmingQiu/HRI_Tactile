/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINIMPLPKTS_RAWSENSORDATAV2_H
#define SKINIMPLPKTS_RAWSENSORDATAV2_H

#include <SkinCore/Implementation/Packet.h>
#include <SkinCore/Implementation/Packets/Version2/PacketDefinitions.h>

#include <SkinCore/Implementation/Packets/Version2/Data/SensorData.h>



namespace Skin{
namespace Implementation{
namespace Packets {
namespace Version2{
namespace Data{

class SensorData;

class RawSensorData
{
public:
    static unsigned int convToRawProx(double prox);
    static unsigned int convToRawForce(double force);
    static int convToRawAcc(double acc);
    static int convToRawTemp1(double temp1);
    static int convToRawTemp2(double temp2);

    static Skin::Cell::Data& convToData(Skin::Cell::Data& d, const RawSensorData& rsd);

    static RawSensorData& convToRawSensorData(RawSensorData& rsd, const Skin::Cell::Data& d);
    static RawSensorData& convToRawSensorData(RawSensorData& rsd, const SensorData& sd);

    unsigned int prox;
    unsigned int force[3];
    int acc[3];
    int temp[2];

private:


public:
    RawSensorData();
    RawSensorData(const RawSensorData& d);
    RawSensorData(const SensorData& d);
    RawSensorData(const Skin::Cell::Data& d);
    RawSensorData(const Packet& p);

    RawSensorData abs() const;

    Cell::Data toData() const;

    QString toString() const;
};

}}}}}

#endif // SKINIMPLPKTS_DATA_RAWSENSORDATAV2_H
