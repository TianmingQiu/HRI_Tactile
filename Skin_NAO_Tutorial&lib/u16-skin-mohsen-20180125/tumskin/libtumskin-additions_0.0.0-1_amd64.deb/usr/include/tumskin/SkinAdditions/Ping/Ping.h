#ifndef SKINADDITIONS_PING_H
#define SKINADDITIONS_PING_H


#include <QObject>
#include <QTimer>

#include <SkinManagers/Application/Base/Application.h>
#include <SkinCore/Implementation/Packets/Version2/PacketDefinitions.h>

namespace Skin {
namespace Additions{

using namespace Skin::Cell;
using namespace Skin::Managers;

class Ping : public QObject
{
    Q_OBJECT

private:

public:


private:
    typedef bool (Ping::*cmd_handler_func)(const QString& s);
    QVector<cmd_handler_func> m_cmdHandlers;
    QString             m_consoleCmdDescription;

    Skin::Managers::Application::Base::Application* m_app;

    bool                m_started;
    QTimer              m_timer;

    int                 m_id;

public:
    explicit Ping(Skin::Managers::Application::Base::Application* app,
                        QObject *parent = 0);

    const QString& consoleCmdDescription() const;
    bool handleConsoleCmd(QString);

private:
    bool handlePingCommands(const QString& s);

private slots:
    void handlePingTimer();
    void newPacketBunch(QVector<Skin::Implementation::Packet>);

public slots:
    void start(int id=Skin::Implementation::Packets::Version2::ID_ALL);
    void stop();

    void sendPing(int id=Skin::Implementation::Packets::Version2::ID_ALL);

signals:


};

}}




#endif // SKINADDITIONS_PING_H
