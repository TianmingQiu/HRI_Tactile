#ifndef TUM_ICS_SKIN_AUTO_CONFIG_CONFIG_GENERATOR_H
#define TUM_ICS_SKIN_AUTO_CONFIG_CONFIG_GENERATOR_H

#include <ros/ros.h>
#include <tum_ics_skin_bridge/Cell/NeighborsClient.h>
#include <tum_ics_skin_auto_config/DataSampler.h>

#include <SkinRecon/Simple/Recon.h>

#include <QString>
#include <QVector>
#include <QMap>
#include <QMutex>


namespace tum_ics_skin_auto_config{

class ConfigGenerator :
        private DataSampler,
        private ::Skin::Recon::Simple::Recon
{
private:
    typedef ::Skin::Config Config;
    typedef ::Skin::SegmentMap SegmentMap;
    typedef ::Skin::Cell::Neighbors Neighbors;

    tum_ics_skin_bridge::Cell::NeighborsClient m_neighsClient;

    QString m_dataTopicName;
    QString m_neighSrvName;

    int                                 m_numOfPoses;
    int                                 m_samplesPerCell;
    SegmentMap                          m_segMap;
    QVector<Neighbors>   m_neighs;
    bool                                m_complete;
    bool                                m_error;

public:
    ConfigGenerator(int poseTimeout = -1);

    ~ConfigGenerator();

    // specify path or file path
    bool saveDialog(const QString& configFilePath = QString());

    // does simple 1 pose recon; blocks until finished
    bool recon(int samplesPerCell=16,
               const SegmentMap& segMap = SegmentMap());

    // std topic name: 'dataSampler'
    // std service name for neighbors 'getSkinCellNeighbors'

    // start: init and start sampling; if already started then:
    //      stop -> reinit -> start
    bool start(int numOfPoses=1,
               int samplesPerCell=16,
               const SegmentMap& segMap = SegmentMap());

    bool start(const QString& dataTopicName,
               const QString& neighSrvName,
               int numOfPoses=1,
               int samplesPerCell=16,
               const SegmentMap& segMap = SegmentMap());


    bool restart();

    // update processing states
    bool update();

    // recon complete
    bool complete() const;

    // recon error; recon aborted
    bool error() const;

    // === lets use some stuff from the sub class ===
    using DataSampler::nextPose;

    // get the current pose
    using DataSampler::currentPose;
    using DataSampler::currentPoseInd;

    // pose complete
    using DataSampler::poseComplete;

    // the skin config
    using ::Skin::Recon::Simple::Recon::config;

private:

};

}

#endif // TUM_ICS_SKIN_AUTO_CONFIG_CONFIG_GENERATOR_H
