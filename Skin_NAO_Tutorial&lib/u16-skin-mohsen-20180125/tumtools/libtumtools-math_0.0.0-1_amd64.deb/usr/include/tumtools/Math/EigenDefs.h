#ifndef TUM_EIGENDEFS_H
#define TUM_EIGENDEFS_H

#include <Math/MathDefs.h>
#include <Eigen/Eigen>

namespace Tum{

// redeclaration of typedefs are ok as long as they alias the same type
typedef Eigen::Matrix<double,1,1> Vector1d; //needed for getSpline5 for a scalar value
typedef Eigen::Matrix<double,2,1> Vector2d;
typedef Eigen::Matrix<double,3,1> Vector3d;
typedef Eigen::Matrix<double,4,1> Vector4d;
typedef Eigen::Matrix<double,5,1> Vector5d;
typedef Eigen::Matrix<double,6,1> Vector6d;
typedef Eigen::Matrix<double,7,1> Vector7d;
typedef Eigen::Matrix<double,8,1> Vector8d;
typedef Eigen::Matrix<double,9,1> Vector9d;
typedef Eigen::Matrix<double,10,1> Vector10d;
typedef Eigen::Matrix<double,11,1> Vector11d;
typedef Eigen::Matrix<double,12,1> Vector12d;
typedef Eigen::Matrix<double,13,1> Vector13d;
typedef Eigen::Matrix<double,14,1> Vector14d;
typedef Eigen::Matrix<double,15,1> Vector15d;

typedef Eigen::Matrix<int,1,1> Vector1i;
typedef Eigen::Matrix<int,2,1> Vector2i;
typedef Eigen::Matrix<int,3,1> Vector3i;
typedef Eigen::Matrix<int,4,1> Vector4i;
typedef Eigen::Matrix<int,5,1> Vector5i;
typedef Eigen::Matrix<int,6,1> Vector6i;
typedef Eigen::Matrix<int,7,1> Vector7i;
typedef Eigen::Matrix<int,8,1> Vector8i;
typedef Eigen::Matrix<int,9,1> Vector9i;
typedef Eigen::Matrix<int,10,1> Vector10i;

typedef Eigen::Matrix<double,1,1> Matrix1d;
typedef Eigen::Matrix<double,2,2> Matrix2d;
typedef Eigen::Matrix<double,3,3> Matrix3d;
typedef Eigen::Matrix<double,4,4> Matrix4d;
typedef Eigen::Matrix<double,5,5> Matrix5d;
typedef Eigen::Matrix<double,6,6> Matrix6d;
typedef Eigen::Matrix<double,7,7> Matrix7d;
typedef Eigen::Matrix<double,8,8> Matrix8d;
typedef Eigen::Matrix<double,9,9> Matrix9d;
typedef Eigen::Matrix<double,10,10> Matrix10d;


using namespace Eigen;

typedef Eigen::Matrix<double,STD_DOF,1> VectorDOFd;
typedef Eigen::Matrix<int,STD_DOF,1> VectorDOFi;

typedef Eigen::Matrix<double,STD_DOF,STD_DOF> MatrixDOFd;
typedef Eigen::Matrix<double,STD_DOF,81> MatrixRegressor;
typedef Eigen::Matrix<double,81,1> VectorRegressor;
typedef Eigen::Matrix<double,3,STD_DOF> MatrixJvd;
typedef Eigen::Matrix<double,6,STD_DOF> MatrixJd;
typedef Eigen::Matrix<double,STD_DOF,6> MatrixIJd;

typedef QVector<Vector1d> VVector1d;
typedef QVector<Vector2d> VVector2d;
typedef QVector<Vector3d> VVector3d;
typedef QVector<Vector4d> VVector4d;

typedef QVector<Vector6d> VVector6d;
typedef QVector<VectorDOFd> VVectorDOFd;

typedef QVector<Vector12d> VVector12d;

typedef QVector<Matrix4d> VMatrix4d;

typedef QVector<Matrix6d> VMatrix6d;
typedef QVector<MatrixDOFd> VMatrixDOFd;

typedef QVector<Affine3d> VAffine3d;

}


#endif // TUM_EIGENDEFS_H
