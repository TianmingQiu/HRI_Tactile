/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKIN_CONFIGLOADER_H
#define SKIN_CONFIGLOADER_H

#include <QVector>
#include <QMetaType>
#include <QMap>

#include <QFile>
#include <QDir>
#include <QXmlStreamWriter>

#include <Eigen/Eigen>

#include <SkinCore/Config/Config.h>
#include <SkinCore/Cell/Neighbors.h>
#include <SkinCore/Cell/Organization.h>

namespace Skin{

using namespace Cell;

class ConfigLoader : public QObject
{
    Q_OBJECT

public:

private:
    QVector<Organization> m_cells;
    QString m_filename;

public:
    ConfigLoader(const QString& filename="skin.xml",QObject* parent=0);
    ~ConfigLoader();

private:

public slots:
    void newNeighborList(QVector<Skin::Cell::Neighbors> nl); // check if valid config is available
    void newSkinConfig(Skin::Config skin); // store new config

signals:
    void loadedSkinConfig(Skin::Config skin);


};

}


#endif // SKIN_CONFIGLOADER_H
