#ifndef TUM_ICS_SKIN_DESCR_PATCH_TF_MARKER_DATA_PATCH_H
#define TUM_ICS_SKIN_DESCR_PATCH_TF_MARKER_DATA_PATCH_H

#include <tum_ics_skin_descr/Patch/TfMarkerPatch.h>
#include <tum_ics_skin_bridge/Cell/DataConnection.h>
#include <tum_ics_skin_bridge/Cell/DataBank.h>
#include <tum_ics_skin_bridge/Cell/LedColorClient.h>

namespace tum_ics_skin_descr{
namespace Patch{

/*!
 * \brief A functional class which provides kinematic chains, tfs, markers, and sensor
 *        data and access to LED colors of a group of skin cells, which is named skin patch.
 *
 * This class derives from TfPatch, TfPatchPub and TfMarkerPatch and extends their
 * functionality with access to the sensor data of skin cells and their LED color.
 * The TfPatch class provides methods for loading the intrinsics and extrinsics of the
 * skin patch of a given skin patch configuration file and combines this information to
 * kinematic chains from each skin cell to the specified base frame. The TfPatchPub
 * class provides methods to publish tfs for the skin cells of the patch.
 * The TfMarkerPatch provides methods to create vizualization markers for showing the skin
 * cells in rviz. The TfMarkerDataPatch instantiates the DataConnection class to get
 * skin data from the skin driver, the DataBank class to store skin data locally and the
 * LedColorClient class to send LED color change requests to the skin driver.
 */
class TfMarkerDataPatch :
        public TfMarkerPatch
{
private:
    typedef ::Skin::Cell::Organization Organization;
    typedef ::Skin::Cell::Data Data;
    typedef ::Skin::Patch Patch;
    typedef tum_ics_skin_descr::Patch::DriverSettings PatchDriverSettings;
    typedef tum_ics_skin_descr::Patch::Extrinsics PatchExtrinsics;
    typedef tum_ics_skin_bridge::Cell::ActiveCellConfig ActiveCellConfig;

    tum_ics_skin_bridge::Cell::DataBank m_dataBank;
    tum_ics_skin_bridge::Cell::DataConnection m_dataConnection;
    tum_ics_skin_bridge::Cell::LedColorClient m_ledConn;

    bool m_autoUpdateMarkersEnabled;

public:
    /*!
     * \brief Default constructor.
     * \param markerNameSpace is the namespace for skin cell visualization markers in ROS.
     * \param cellTfNameBase is the name base for cell tfs in ROS.
     */
    TfMarkerDataPatch(const QString& markerNameSpace = "SkinCellMarkers",
                      const QString& cellTfNameBase = "/sensor_");

    ~TfMarkerDataPatch();

    /*!
     * \brief Set the active cell config to use.
     */
    void setConfig(const ActiveCellConfig& config);


    /*!
     * \brief Loads the patch configuration from a patch configuration .xml file.
     * \param filePath is the path to the patch configuration .xml file to load.
     * \param patchId is the patch id of the patch which is loaded from the
     *        configuration .xml file. Setting the patchId to zero means to load
     *        the first patch from the patch configuration .xml file.
     * \return True on success, False on error.
     */
    bool load(const QString& filePath, int patchId = 0);


    /*!
     * \brief Opens a open file dialog to get the patch configuration from a
     *        patch configuration .xml file.
     * \param filePath is the path to the patch configuration .xml file to load.
     * \param patchId is the patch id of the patch which is loaded from the
     *        configuration .xml file. Setting the patchId to zero means to load
     *        the first patch from the patch configuration .xml file.
     * \return True on success, False on error.
     */
    bool loadDialog(const QString& path = QString(), int patchId = 0);


    /*!
     * \brief Creates a patch from a low level Skin::Patch.
     * \param patch is the input low level patch.
     * \param pe are the patch extrinsics for the low level patch.
     * \return True on success, False on error.
     */
    bool create(const Patch& patch,
                const PatchExtrinsics& pe = PatchExtrinsics::Default());

    /*!
     * \brief Creates a patch from a low level Skin::Patch.
     * \param patch is the input low level patch.
     * \param pds are the skin driver setting for the low level patch.
     * \param pe are the patch extrinsics for the low level patch.
     * \return True on success, False on error.
     */
    bool create(const Patch& patch,
                const PatchDriverSettings& pds,
                const PatchExtrinsics& pe = PatchExtrinsics::Default());

    /*!
     * \brief Create by copying the configuration from a TfPatch class.
     * \param patch is the given TfPatch class which provides the patch configuration for this class.
     * \return True on success, False on error.
     */
    bool create(const TfPatch& patch);


    /*!
     * \brief Gets the number of skin cells in the patch.
     */
    int	numberOfCells() const;

    /*!
     * \brief Get the array index for the given cell id.
     *
     * NOTE: Indices always start at 0, are consecutive and positive. Ids start at 1,
     * are not necessarily consecutive but always positive.
     *
     * \param id is the skin cell id.
     * \return The array index for the given cell id. The index is -1 on error.
     */
    int index(int id) const;

    /*!
     * \brief Get the index for a given cell name.
     *
     * The cell name is the tf frame name of a skin cell and is a combination
     * patch id, skin cell id and cellBaseName.
     *
     * \param cellName is the tf name of a skin cell.
     * \return The array index for the given cell id. The index is -1 on error.
     */
    int indexOfCell(const QString &cellName) const;

    /*!
     * \brief Get the array index for the given cell id.
     *
     * NOTE: Indices always start at 0, are consecutive and positive. Ids start at 1,
     * are not necessarily consecutive but always positive.
     *
     * \param id is the skin cell id.
     * \return The array index for the given cell id. The index is -1 on error.
     */
    int indexOfCellId (int cellId) const;

    /*!
     * \brief Get the base frame name of the skin patch.
     *
     * The skin patch is usually attached to a robot link which is
     * specified by the name of the ROS TF.
     *
     * \return The name of the base frame of the skin patch.
     */
    const QString& baseFrame() const;

    /*!
     * \brief Get the array of skin cell ids.
     *
     * The array is ordered in such a way that a skin cell index
     * refers to an array element which belongs to that skin cell.
     * \return An ordered array of skin cell ids of all skin cells in this patch.
     */
    QVector<int> cellIds() const;

    /*!
     * \brief Get the array of homogenous transformations of cell coordinate frames
     *        with respect to the base coorinate frame.
     *
     * The array is ordered in such a way that a skin cell index
     * referes to an array element which contains the transformation from that
     * skin cell coordinate frame to the base coordinate frame.
     * \return An ordered array of homogenous transformations which represent the
     * skin cell coordinate frames with respect to the base coordinate frame.
     */
    const QVector<Eigen::Affine3d>& tf_cell_base() const;

    /*!
     * \brief Publish the ROS tfs and markers to visualize the skin patch in rviz.
     * \param dur is the duration for displaying a marker until the marker is
     *        updated. The default value means infinite duration. Specify a
     *        finite value if you want the markers to disappear after you stop
     *        publishing.
     */
    void publish(const ros::Duration &dur=ros::Duration(),const QString& ns="");


    /*!
     * \brief Create a data connection to the skin driver to get skin information.
     * \param dataTopicName is the topic name (with namespace path) which should be
     *        used to convey skin information from the driver to this class.
     *        NOTE: An empty topic name creates the default topic name 'patch<patch id>'.
     *        If the skin driver settings are undefined, then skin data topic doesn't
     *        have any namespace prefix.
     * \param shared defines, whether the connection shares a skin data topic or not.
     *        If shared, then the topic is only subscribed to and NOT created in the
     *        skin driver.
     * \return A flag which is true on success and false on error.
     */
    bool createDataConnection(const QString& dataTopicName = "", bool shared = false);

    /*!
     * \brief Create a data connection to the skin driver to get skin information.
     *
     * This function uses the default topic name.
     * \param shared defines, whether the connection shares a skin data topic or not.
     *        If shared, then the topic is only subscribed to and NOT created in the
     *        skin driver.
     * \return A flag which is true on success and false on error.
     */
    bool createDataConnection(bool shared);

    /*!
     * \brief Enables the data connection to the skin driver.
     *
     * NOTE: The data connection to the skin driver has to be created first, before
     * you can enable it. The call of this function has no effect if the connection is
     * not owned by this patch but shared.
     */
    void enableDataConnection();

    /*!
     * \brief Disables the data connection to the skin driver.
     */
    void disableDataConnection();

    /*!
     * \brief Enables the automatic update of skin cell visualization markers.
     *
     * If enabled, then the skin cell visualization markers of this patch are updated
     * when new skin data is available.
     *
     * NOTE: By default the automatic update of markers is ENABLED.
     */
    void enableAutoUpdateMarkers();

    /*!
     * \brief Disables the automatic update of skin cell visualization markers.
     *
     * NOTE: For performance reasons disable the auto update for markers
     * when markers are not used.
     */
    void disableAutoUpdateMarkers();

    /*!
     * \brief Updates the skin data bank and visualization markers of this patch with the given skin data.
     *
     * The skin data bank stores the most recent sensor data of all the skin cells
     * of this patch. If there is an enabled data connection to the skin driver then
     * this function gets called automatically internally whenever there is new
     * skin data available
     * \param d is a vector of new skin cell data for updating skin cell sensor signals
     *        in the data bank.
     */
    void update(const QVector< ::Skin::Cell::Data>& d);

    /*!
     * \brief Updates the skin data bank of this patch with the given skin data.
     *
     * The skin data bank stores the most recent sensor data of all the skin cells
     * of this patch. If there is an enabled data connection to the skin driver then
     * this function gets called automatically internally whenever there is new
     * skin data available.
     * \param d is a vector of new skin cell data for updating skin cell sensor signals
     *        in the data bank.
     */
    void updateDataBank(const QVector< ::Skin::Cell::Data>& d);

    /*!
     * \brief Updates the skin markers of this patch with the given skin data.
     *
     * The skin markers are visualization markers to represent skin cells of this
     * patch in rviz. If there is an enabled data connection to the skin driver then
     * this function gets called automatically internally whenever there is new
     * skin data available.
     * \param d is a vector of new skin cell data for updating skin cell sensor signals
     *        in the data bank.
     */
    void updateMarkers(const QVector< ::Skin::Cell::Data>& d);

    /*!
     * \brief Gets the sensor data of a skin cell for a given skin cell index.
     *
     * NOTE: The call of this function resets the updated state of the called skin cell data.
     *
     * NOTE: This function has to locks a mutex on each call.
     *
     * \param cellInd is the index of the skin cell of which we want to get the skin cell data.
     *        NOTE: Indices always start at 0, are consecutive and positive. Ids start at 1,
     *        are not necessarily consecutive but always positive. Indexes can be used to
     *        loop over skin cells while the skin cell id is the unique and should be used
     *        when addressing a specific known skin cell.
     * \return The skin cell sensor data of the specified skin cell.
     */
    ::Skin::Cell::Data dataFromInd(int cellInd);

    /*!
     * \brief Gets the sensor data of a skin cell for a given skin cell id.
     *
     * NOTE: The call of this function resets the updated state of the called skin cell data.
     *
     * NOTE: This function has to locks a mutex on each call.
     *
     * \param cellId is the id of the skin cell of which we want to get the skin cell data.
     *        NOTE: Indices always start at 0, are consecutive and positive. Ids start at 1,
     *        are not necessarily consecutive but always positive. Indexes can be used to
     *        loop over skin cells while the skin cell id is unique and should be used
     *        when addressing a specific known skin cell.
     * \return The skin cell sensor data of the specified skin cell.
     */
    ::Skin::Cell::Data dataFromId(int cellId);

    /*!
     * \brief Gets the sensor data of a skin cell for a given skin cell index.
     *
     * Identical to the dataFromInd function.
     */
    ::Skin::Cell::Data data(int cellInd);

    /*!
     * \brief Gets an array with skin cell data of all the cells of the skin patch.
     *
     * NOTE: This array is indexed in the same way as the skin cells of this patch.
     * \return An array of skin cell sensor data.
     */
    QVector< ::Skin::Cell::Data> data();

    /*!
     * \brief Gets an array with skin cell data which has changed since the last call.
     *
     * NOTE: This array is NOT indexed in the same way as the skin cells of this patch.
     * \return An array of skin cell sensor data.
     */
    QVector< ::Skin::Cell::Data> updatedData();

    /*!
     * \brief Get the used active cell config.
     *
     * \return The currently used active cell config.
     */
    const ActiveCellConfig& config() const;

    /*!
     * \brief Get the number of active cells.
     *
     * The number of active cells. An active cell has at least an active
     * proximity, force or temperature sensor.
     *
     * \return The number of active cells.
     */
    int numberOfActiveCells() const;

    /*!
     * \brief Get the number of cells with an active proximity sensor.
     * \return The number of active cells.
     */
    int numberOfActiveProxCells() const;

    /*!
     * \brief Get the number of cells with an active force sensor.
     * \return The number of active cells.
     */
    int numberOfActiveForceCells() const;

    /*!
     * \brief Get the number of cells with an active temp sensor.
     * \return The number of active cells.
     */
    int numberOfActiveTempCells() const;


    /*!
     * \brief Sets the LED color of all the skin cells in this patch to a desired color.
     *
     * NOTE: The skin driver can only handle 1 color change every 2 ms. Faster calls
     * result in queued commands.
     *
     * \param c is the desired LED color of the skin cells.
     * \return A flag which is true on success and false on error.
     */
    bool setLedColor(const ::Skin::Cell::LedColor& c);

    /*!
     * \brief Sets the LED color of a specified skin cell to a desired color.
     *
     * NOTE: The skin driver can only handle 1 color change every 2 ms. Faster calls
     * result in queued commands.
     *
     * \param c is the desired LED color of the skin cell.
     * \param id is the id of the skin cell which needs to change color.
     * \return A flag which is true on success and false on error.
     */
    bool setLedColor(const ::Skin::Cell::LedColor& c, int id);

    /*!
     * \brief Sets the LED color of specified skin cells to a desired color.
     *
     * NOTE: The skin driver can only handle 1 color change every 2 ms. Faster calls
     * result in queued commands.
     * \param c is the desired LED color of the skin cells.
     * \param id is the id of the skin cells which need to change color.
     * \return A flag which is true on success and false on error.
     */
    bool setLedColor(const ::Skin::Cell::LedColor& c, const QVector<int>& ids);


    /*!
     * \brief Gives access to the callback caller of the patch.
     *
     * The callback caller is driven by the DataConnection used by the patch.
     */
    tum_ics_skin_common::CallbackCaller<QVector< ::Skin::Cell::Data> >* callbackCaller();

private:
    void initLedColorClient();

    void callback(const QVector< ::Skin::Cell::Data> &);

};

}}


#endif // TUM_ICS_SKIN_DESCR_PATCH_TF_MARKER_DATA_PATCH_H
