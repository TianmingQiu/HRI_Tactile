#ifndef TUM_ICS_SKIN_FULL_CONFIG_CALIB_DH_MAINWINDOW_H
#define TUM_ICS_SKIN_FULL_CONFIG_CALIB_DH_MAINWINDOW_H

#include <QMainWindow>
#include <QCloseEvent>

//This definition is needed with libboost 1.58
#ifndef Q_MOC_RUN
#include <tum_ics_skin_full_config/CalibWidget.h>
#include <tum_ics_skin_full_config/CalibDhTfWidget.h>
#endif

namespace tum_ics_skin_full_config
{

namespace Ui {
class CalibDhMainWindow;
}

class CalibDhMainWindow : public QMainWindow
{
    Q_OBJECT

private:
    Ui::CalibDhMainWindow *ui;

    CalibWidget* m_wCalib;

    CalibAutoConfigWidget* m_wAutoConfig;
    CalibCustomConfigWidget* m_wCustomConfig;
    CalibExtTfWidget* m_wExtTf;
    CalibDhTfWidget* m_wCalibDh;

    bool m_closed;

public:
    explicit CalibDhMainWindow(QWidget *parent = 0);
    ~CalibDhMainWindow();

    void setDefaultPath(const QString& path=".");

    void update();


    bool isClosed() const;

private:
    void showEvent(QShowEvent* e);
    void hideEvent(QHideEvent* e);
    void closeEvent(QCloseEvent* e);

};

}

#endif // TUM_ICS_SKIN_FULL_CONFIG_CALIB_DH_MAINWINDOW_H
