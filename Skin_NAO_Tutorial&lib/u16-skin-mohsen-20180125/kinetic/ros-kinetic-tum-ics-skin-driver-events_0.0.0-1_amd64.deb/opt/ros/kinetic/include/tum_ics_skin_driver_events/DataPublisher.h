#ifndef TUM_ICS_SKIN_DRIVER_EVENTS_DATA_PUBLISHER_H
#define TUM_ICS_SKIN_DRIVER_EVENTS_DATA_PUBLISHER_H

#include <QVector>
#include <QMap>

//This definition is needed with libboost 1.58
#ifndef Q_MOC_RUN
#include <SkinCore/Cell/Data.h>
#include <tum_ics_skin_msgs_events/SkinCellData.h>

#include <ros/ros.h>
#endif

namespace tum_ics_skin_driver_events{

class DataPublisher
{
public:
    static tum_ics_skin_msgs_events::SkinCellData convData(const Skin::Cell::Data& d);

private:
    ros::NodeHandle m_node;
    ros::Publisher  m_pub;

    QVector<int> m_ids;
    QString m_name;
    bool m_enabled;

public:
    DataPublisher(const QString& name, const QVector<int>& ids);
    ~DataPublisher();

    void setEnabled(bool enable);

    const QString& name() const;

    // publish data
    void publish(const QVector<Skin::Cell::Data>& data);

};

}

#endif // TUM_ICS_SKIN_DRIVER_EVENTS_DATA_PUBLISHER_H
