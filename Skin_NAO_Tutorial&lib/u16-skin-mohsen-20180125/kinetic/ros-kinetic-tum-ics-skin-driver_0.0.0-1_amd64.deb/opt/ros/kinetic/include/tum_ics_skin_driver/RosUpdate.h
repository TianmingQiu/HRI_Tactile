#ifndef TUM_ICS_SKIN_DRIVER_ROS_UPDATE_H
#define TUM_ICS_SKIN_DRIVER_ROS_UPDATE_H

#include <QObject>
#include <QTimer>
#include <QVector>

//This definition is needed with libboost 1.58
#ifndef Q_MOC_RUN
#include <ros/ros.h>
#include <Threads/Thread.h>
#endif

namespace tum_ics_skin_driver{

class RosUpdate : public Threads::Thread
{
    Q_OBJECT

private:
    int m_usleepIntv;
    bool m_quit;

public:
    explicit RosUpdate(int sampleRate = 250, QObject* parent = 0);

private:
    void run();

private slots:

public slots:
    void quit();

signals:
    void finished();

};

}


#endif // TUM_ICS_SKIN_DRIVER_ROS_UPDATE_H
