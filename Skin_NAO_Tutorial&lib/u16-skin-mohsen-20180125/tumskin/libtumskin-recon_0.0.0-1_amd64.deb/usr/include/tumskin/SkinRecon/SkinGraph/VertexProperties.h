/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINRECON_SKINGRAPH_VERTEXPROPERTIES_H
#define SKINRECON_SKINGRAPH_VERTEXPROPERTIES_H


#include <Eigen/Eigen>

namespace Skin{
namespace Reconstruction{
namespace SkinGraph{

struct VertexProperties
{
    int patchId;
    int cellId;
    int predCellId;             // predecessor cell id (parent cell in shortest path)

    double dist;                // distance to root cell, added weights

    bool hasPose;               // has orientation and position in space

    // pose
    Eigen::Vector3d pos;        // position, includes origin
    Eigen::Matrix3d rot;        // rotation, includes rotation of origin

public:
    VertexProperties();
    VertexProperties(int cellId);
    VertexProperties(const VertexProperties& p);
    ~VertexProperties();
};


}
}
}



#endif // SKINRECON_SKINGRAPH_VERTEXPROPERTIES_H
