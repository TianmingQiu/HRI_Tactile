/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINIMPLPKTS_SENSORDATAPACKETV2_H
#define SKINIMPLPKTS_SENSORDATAPACKETV2_H

#include <SkinCore/Implementation/Packet.h>
#include <SkinCore/Cell/Data.h>

#include <SkinCore/Implementation/Packets/Version2/Data/SensorData.h>
#include <SkinCore/Implementation/Packets/Version2/Data/RawSensorData.h>

namespace Skin{
namespace Implementation{
namespace Packets {
namespace Version2{
namespace Data{

class SensorDataPacket : public Packet
{
public:
    static const int PKT_SIZE = 20;

    static bool check(const Packet& p);

    static void setSensorData(Packet& p, const SensorData& d);
    static void setRawSensorData(Packet& p, const RawSensorData& d);

    static Cell::Data getData(const Packet& p);
    static SensorData getSensorData(const Packet& p);
    static RawSensorData getRawSensorData(const Packet& p);

private:
    static int getTemperature(const Packet& p, int index);
    static int getAcceleration(const Packet& p, int index);
    static unsigned int getProximity(const Packet& p, int index);
    static unsigned int getForce(const Packet& p, int index);

    static int int8_to_int(unsigned int val_int8);
    static int int10_to_int(unsigned int val_int10);
    static int int14_to_int(unsigned int val_int14);

public:
    SensorDataPacket();
    SensorDataPacket(const QVector<Endpoint>& dest);

    bool check() const;
    Cell::Data getData() const;

private:
    void init();

};

}}}}}

#endif // SENSORDATAPACKETV2_H
