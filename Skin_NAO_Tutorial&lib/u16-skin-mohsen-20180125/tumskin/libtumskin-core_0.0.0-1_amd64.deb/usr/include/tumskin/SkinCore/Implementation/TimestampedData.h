/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINIMPL_TIMESTAMPED_DATA_H
#define SKINIMPL_TIMESTAMPED_DATA_H

#include <QByteArray>
#include <QVector>
#include <QString>
#include <QTextStream>

#include "Endpoint.h"

namespace Skin{
namespace Implementation{

class TimestampedData : public QByteArray
{
protected:
    qint64              m_ts;       // timestamp ns

public:
    TimestampedData(qint64 ts =-1, const QByteArray& d = QByteArray());
    TimestampedData(const TimestampedData& d);

    bool operator== (const TimestampedData& other) const;
    bool operator!= (const TimestampedData& other) const;

    qint64 ts() const;

    QString toString() const;
};

}
}

QTextStream& operator << (QTextStream& s, const Skin::Implementation::TimestampedData& d);
QTextStream& operator >> (QTextStream& s, Skin::Implementation::TimestampedData& d);


#endif // SKINIMPL_TIMESTAMPED_DATA_H
