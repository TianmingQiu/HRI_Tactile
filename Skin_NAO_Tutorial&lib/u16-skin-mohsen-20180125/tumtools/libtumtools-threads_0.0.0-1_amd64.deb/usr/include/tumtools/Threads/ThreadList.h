#ifndef THREADS_THREADLIST_H
#define THREADS_THREADLIST_H

#include <QString>
#include <QMap>
#include <QList>
#include <QVector>
#include <QTextStream>

#include <Threads/ThreadInfo.h>

namespace Threads{

class ThreadList
{
public:
    static ThreadList load(const QString& filePath = "./ThreadList.txt");

private:
    static QString defaultStr;

private:
    QList<ThreadInfo> m_threads;
    int m_pid;

    QMap<QString,int> m_nameMap;    // map: name -> thread ind
    QMap<int,int> m_tidMap;         // map: tid -> thread ind

public:
    ThreadList(int pid = -1, const QList<ThreadInfo>& til = QList<ThreadInfo>());
    ThreadList(const QList<ThreadInfo>& til);
    ThreadList(const QString& filePath);

    ThreadList(const ThreadList& tl);
    ~ThreadList();

    bool save(const QString& filePath = "./ThreadList.txt");

    // returns -1 on error
    int index(const QString& threadName) const;
    int index(int tid) const;

    int tid(int ind) const;
    const QString& name(int ind) const;

    int pid() const;
    const QList<ThreadInfo>& threads() const;

    QVector<int> tids() const;

    QString toString() const;

private:

};

}

QTextStream& operator << (QTextStream& s, const Threads::ThreadList& til);
QTextStream& operator >> (QTextStream& s, Threads::ThreadList& til);


#endif  // THREADS_THREADLIST_H
