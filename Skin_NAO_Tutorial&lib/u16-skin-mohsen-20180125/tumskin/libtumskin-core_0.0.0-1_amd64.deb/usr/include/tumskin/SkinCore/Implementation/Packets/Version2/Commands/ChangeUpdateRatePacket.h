/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINIMPLPKTS_CHANGEUPDATERATEPACKETV2_H
#define SKINIMPLPKTS_CHANGEUPDATERATEPACKETV2_H

#include <SkinCore/Implementation/Packet.h>
#include <SkinCore/Implementation/Packets/Version2/PacketDefinitions.h>

namespace Skin{
namespace Implementation{
namespace Packets {
namespace Version2{
namespace Commands{

class ChangeUpdateRatePacket : public Packet
{

public:
    enum UpdateRate
    {
        Rate0Hz      = 0,
        Rate63Hz     = 1,
        Rate125Hz    = 2,
        Rate250Hz    = 3
    };

public:
    static const int PKT_SIZE = 20;
    static Packet& setId(Packet& p, int id);
    static void setUpdateRate(Packet& p, UpdateRate udr);

public:
    ChangeUpdateRatePacket(UpdateRate udr=Rate250Hz,
                           int id=ID_ALL,
                           const QVector<Endpoint>& dest=QVector<Endpoint>());

    void setId(int id);
    void setUpdateRate(UpdateRate udr=Rate250Hz);

private:
    void init(int id=0,UpdateRate udr=Rate250Hz);

};

}}}}}

#endif // SKINIMPLPKTS_CHANGEUPDATERATEPACKETV2_H
