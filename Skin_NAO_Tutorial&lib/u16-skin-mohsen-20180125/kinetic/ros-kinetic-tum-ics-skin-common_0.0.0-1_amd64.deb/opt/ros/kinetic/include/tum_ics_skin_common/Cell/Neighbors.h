#ifndef TUM_ICS_SKIN_CELL_NEIGHBORS_H
#define TUM_ICS_SKIN_CELL_NEIGHBORS_H

#include <ros/ros.h>
#include <tum_ics_skin_msgs/SkinCellNeighbors.h>

#include <SkinCore/Cell/Neighbors.h>

#include <QString>
#include <QVector>

namespace tum_ics_skin_common{
namespace Cell{

class Neighbors :
        public ::Skin::Cell::Neighbors
{
private:
    typedef tum_ics_skin_msgs::SkinCellNeighbors NeighborsMsg;

public:
    static Neighbors fromMsg(const NeighborsMsg& msg);
    static NeighborsMsg toMsg(const ::Skin::Cell::Neighbors& n);
    static NeighborsMsg& toMsg(NeighborsMsg& m, const ::Skin::Cell::Neighbors& n);
private:

public:
    Neighbors();
    Neighbors(int id, int nId1, int nId2, int nId3, int nId4);
    Neighbors(int id, const QVector<int>& neighs);
    Neighbors(const ::Skin::Cell::Neighbors& n);
    Neighbors(const NeighborsMsg& m);
    Neighbors(const Neighbors& n);
    ~Neighbors();

    operator NeighborsMsg() const;

    NeighborsMsg msg() const;
    NeighborsMsg& msg(NeighborsMsg&) const;
};


}}

#endif // TUM_ICS_SKIN_CELL_NEIGHBORS_H
