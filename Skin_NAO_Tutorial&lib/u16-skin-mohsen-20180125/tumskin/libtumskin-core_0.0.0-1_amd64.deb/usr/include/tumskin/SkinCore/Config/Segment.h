/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKIN_SEGMENT_H
#define SKIN_SEGMENT_H

#include <QVector>
#include <QMetaType>

#include <Eigen/Eigen>

#include "Patch.h"
#include <SkinCore/Cell/Neighbors.h>
#include <SkinCore/Cell/Organization.h>


namespace Skin{

class Segment
{
public:
    static const Segment Undefined; // undefined segment (std constructor)

    static QVector<Segment> getSegments(const QVector<Patch>& patches);
    static QVector<Segment> getSegments(const QVector<Cell::Organization>& cells);

    static QVector<Patch> getPatches(QVector<Segment> segments);
    static int numberOfPatches(QVector<Segment> segments);

    static QVector<Cell::Organization> getCells(QVector<Segment> segments);
    static int numberOfCells(const QVector<Segment>& segments);



    // check: check segment id
    static bool check(const Skin::Segment& s, const Skin::Cell::Organization& c);
    static bool check(const Skin::Segment& s, const Skin::Patch& p);

    // check if all cells are on the same segment
    static bool check(const QVector<Skin::Cell::Organization>& cells);

private:
    int m_segmentId;                // the id of this segment

    QMap<int,int> m_cellIdMap;      // map: cell id -> cell ind
    QMap<int,int> m_patchIdMap;     // map: patch id -> patch ind

    QVector<Skin::Patch> m_patches;
    QVector<Cell::Organization> m_cells;

public:
    Segment();  // undefined
    Segment(const Segment& s);

    Segment(int segmentId);

    // uses the cell to init segment, creates patch and appends cell to patch
    Segment(const Skin::Cell::Organization& c);

    // uses the patch to init segment, appends patch to segment
    Segment(const Skin::Patch& p);

    // takes first patch to init segment
    //  then only addes patches which belong to segment
    Segment(const QVector<Skin::Patch>& patches);

    // first cell inits segment
    //  then only adds cells which belong to segment
    Segment(const QVector<Skin::Cell::Organization>& cells);

    // gets all cells which belong to given segment
    //  -> is undefined if no cells have been found
    //  -> the first cell which matches the given id fully init the segment
    //  -> every first cell of a patch fully init the patch
    Segment(int segmentId, const QVector<Skin::Cell::Organization>& cells);

    ~Segment();

    bool operator== (const Segment& other) const;
    bool operator!= (const Segment& other) const;

    // appends patch to segment
    //  -> patch has to belong to segment, otherwise it is ignored
    //  -> undefined patches are ignored
    //  -> if patch is alread in list then it is ignored
    //  -> does NOT check if cells in patch are already in list
    bool appendPatch(const Skin::Patch& p);

    // appends cell to patch
    //  - if the patch is not in list yet,
    //      then the patch is created and the cell appended to that patch
    //  - if the cell doesn't fit to the patch then
    //      append fails and the cell is ignored
    //  - the append also fails if the cell is already in the list
    //  - undefined cells are ignored
    bool appendCell(const Skin::Cell::Organization& c);

    // ignored if patch with given id is not present
    bool changeRootCellPos(int patchId, const Eigen::Vector3d& pos);
    bool changeRootCellRot(int patchId, const Eigen::Matrix3d& rot);

    bool check(const Skin::Cell::Organization& c) const;
    bool check(const Skin::Patch& p) const;

    // get index of patch id
    //  returns -1 if not existent
    int index(int patchId) const;
    int indexOfCell(int cellId) const;

    bool hasCell(int cellId) const;
    bool hasPatch(int patchId) const;

    bool isUndefined() const;

    // returns reference to Undefined cell if not existent
    const Skin::Cell::Organization& cell(int cellId) const;
    const Skin::Cell::Organization& cell(int patchInd, int cellInd) const;

    const Skin::Patch& patch(int patchId) const;

    int numberOfCells() const;
    int numberOfPatches() const;

    int id() const;

    const QVector<Skin::Patch>& patches() const;
    const QVector<Skin::Cell::Organization>& cells() const;

};

}

Q_DECLARE_METATYPE(Skin::Segment)
Q_DECLARE_METATYPE(QVector<Skin::Segment>)

#endif // SKIN_SEGMENT_H
