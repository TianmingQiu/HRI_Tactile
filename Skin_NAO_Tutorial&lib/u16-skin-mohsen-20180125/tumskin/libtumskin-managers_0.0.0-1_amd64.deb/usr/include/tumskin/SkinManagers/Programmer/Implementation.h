#ifndef SKINMANAGERS_PROGRAMMER_IMPLEMENTATION_H
#define SKINMANAGERS_PROGRAMMER_IMPLEMENTATION_H

#include <QObject>
#include <SkinCore/Implementation/Interface.h>
#include <SkinCore/Implementation/Programmers/Version2/StdProgrammer.h>

namespace Skin{
namespace Managers{
namespace Programmer{

typedef Skin::Implementation::Interface IntfBase;
typedef Skin::Implementation::Programmers::Version2::StdProgrammer ProgBase;

// test if type T is derived from type B
template<class T, class B> struct Derived_from {
    static void constraints(T* p) { B* pb = p; }
    Derived_from() { void(*p)(T*) = constraints; }
};

template<class Prog, class Intf>
class Implementation : public Prog
{

public:
    static Prog* create()
    {
        Prog* p = new Implementation();
        return p;
    }

private:
    Intf* m_intf;

public:
    Implementation(QObject* parent = 0) : Prog(parent)
    {
        Derived_from<Intf,IntfBase>();
        Derived_from<Prog,ProgBase>();

        m_intf = new Intf(this);

        Prog::setInterface(m_intf);

        QString name = Prog::name();
        Prog::setName(m_intf->name() + ", " + name);

        QObject::connect(m_intf,SIGNAL(error(Skin::Implementation::Interface::InterfaceError)),
                         this,SLOT(handleInterfaceError(Skin::Implementation::Interface::InterfaceError)));

        QObject::connect(this,SIGNAL(error(Skin::Implementation::Programmer::ProgrammerError)),
                         this,SLOT(handleProgrammerError(Skin::Implementation::Programmer::ProgrammerError)));
    }

    ~Implementation(){}
};



}}}





#endif // SKINMANAGERS_APPLICATION_IMPLEMENTATION_H
