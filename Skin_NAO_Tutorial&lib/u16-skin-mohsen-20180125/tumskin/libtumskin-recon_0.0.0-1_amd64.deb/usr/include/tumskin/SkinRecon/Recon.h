/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINRECON_RECON_H
#define SKINRECON_RECON_H

#include <QObject>
#include <QVector>
#include <QMap>
#include <QElapsedTimer>

#include <Eigen/Eigen>

#include <SkinCore/Config/Config.h>
#include <SkinCore/Config/SegmentMap.h>
#include <SkinCore/Implementation/Packets/Version2/PacketDefinitions.h>

//#include <Skin/Cell/Data.h>
#include <SkinRecon/AccDataSampler/Data.h>

// because of moc bug in combination with boost in qt4
#ifndef Q_MOC_RUN
#include <SkinRecon/SkinGraph/Graph.h>
#endif


namespace Skin{
namespace Reconstruction{

using namespace Cell;
using namespace AccDataSampler;
using namespace SkinGraph;

class Recon : public QObject
{
    Q_OBJECT

public:
    static void registerMetaTypes();

private:
    static const QVector<Eigen::Vector3d> defaultPos;
    static const QVector<Eigen::Vector3d> defaultRollAxis;
    static const QVector<Eigen::Vector3d> defaultPitchAxis;
    static const QVector<Eigen::Vector3d> defaultYawAxis;

    static Eigen::Vector3d getRPY(const Eigen::Matrix3d& r);
    static Eigen::Matrix3d rotRPY(const Eigen::Vector3d& rpy);
    static QString matrixToString(const Eigen::MatrixXd& m);

private:
    int m_numOfCells;
    QVector<Neighbors> m_neigbors;
    QMap<int,int> m_segMap;             // map cell id to seg id
    Data m_samples;

    QVector<Cell::Organization> m_cells;
    QMap<int,int> m_cellIdMap;          // map cell id to index

    Graph m_graph;

    bool m_started;
    int m_idMax;

public:
    Recon(int idMax = Implementation::Packets::Version2::ID_MAX,
          QObject* parent=0);
    ~Recon();


private:
    void initCellList();
    void initGraph();

    void findPatches();
    void calcRotationMatrices();
    void findPatchRootCells();
    void setRootCellPoses();
    void updatePatchCellPoses();


public slots:
    void newNeighborList(QVector<Skin::Cell::Neighbors> nl);

    // id to segment map
    void newSegmentAssignment(Skin::SegmentMap segMap);

    // if config is valid then trigger reconstruction
    void newSampledData(Skin::Reconstruction::AccDataSampler::Data d);

signals:
    void newSkinConfig(Skin::Config skin);
    void finished();
    void failed();

};



}
}



#endif // SKINRECON_RECON_H
