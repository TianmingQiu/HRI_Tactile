#ifndef SKINMANAGERS_APPLICATION_STANDARD_APPLICATION_H
#define SKINMANAGERS_APPLICATION_STANDARD_APPLICATION_H


#include <QObject>


#include <SkinManagers/Application/Type.h>
#include <SkinManagers/Application/Base/Application.h>

namespace Skin {
namespace Managers{
namespace Application{
namespace Standard{

class Application : public Skin::Managers::Application::Base::Application
{
    Q_OBJECT

private:

public:
    static const Type SingleIntfTsu;
    static const Type SingleIntfTsuV2;
    static const Type MultiIntfTsu;

    static const Type SingleIntfFtdi;
    static const Type SingleIntfFtdiV2;
    static const Type MultiIntfFtdi;

    static const Type SimpleDNodeIntf;
    static const Type SimpleDNodeIntfV2;

    static const Type CompleteDNodeIntf;
    static const Type CompleteDNodeIntfV2;

    static const Type SingleIntfTsu32;
    static const Type SingleIntfTsu32V2;

    typedef Skin::Implementation::IntfNode IntfNode;

private:

public:
    explicit Application(bool bare=false, QObject *parent = 0);

private:

private slots:

public slots:
    void exploreMasterPorts(bool explore);

signals:

};

}}}}




#endif // SKINMANAGERS_APPLICATION_STANDARD_APPLICATION_H
