/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINIMPLPKTS_MASTERPORT_COMMANDPACKETV2_H
#define SKINIMPLPKTS_MASTERPORT_COMMANDPACKETV2_H

#include <SkinCore/Implementation/Packet.h>
#include <SkinCore/Implementation/Packets/Version2/PacketDefinitions.h>

namespace Skin{
namespace Implementation{
namespace Packets {
namespace Version2{
namespace MasterPort{

class CommandPacket : public Packet
{

public:
    enum Command
    {
        CurrentMasterPort    = 0,
        StoredMasterPort     = 1,
    };

    static const int PKT_SIZE = 20;
    static Packet& setId(Packet& p, int id);
    static void setCommand(Packet& p, Command cmd);


public:
    CommandPacket(Command cmd=CurrentMasterPort,
                  int id=ID_ALL,
                  const QVector<Endpoint>& dest=QVector<Endpoint>());

    void setId(int id);
    void setCommand(Command cmd);

private:
    void init(Command mode=CurrentMasterPort,int id=ID_ALL);

};

}}}}}

#endif // SKINIMPLPKTS_MASTERPORT_COMMANDPACKETV2_H
