/*********************************************************************
* Compiler:         Qt Creator V2.4.1                                 
*                   Qt 4.8.0 (64 bit)                                 
*                                                                     
* Company:          Institute for Cognitive Systems                   
*                   Technical University of Munich                    
*                                                                     
* Author:           Florian Bergner                                   
*                                                                     
* Compatibility:                                                      
*                                                                     
* Software Version: V1.0                                              
*                                                                     
* Created:          26.05.2014                                        
* Changed:                                                            
*                                                                     
* Comment:                                                            
*                                                                     
*                                                                     
*********************************************************************/
#ifndef SKINEVENTS_PACKETSV2_EVENTS_THRESHDATAPACKETV2_H
#define SKINEVENTS_PACKETSV2_EVENTS_THRESHDATAPACKETV2_H

#include <SkinCore/Implementation/Packet.h>
#include <SkinCore/Implementation/Packets/Version2/PacketDefinitions.h>
#include <SkinEvents/Implementation/Packets/Version2/Events/AbsDiffDataPacket.h>
#include <SkinEvents/Implementation/Packets/Version2/Events/AbsDiffData.h>
#include <SkinEvents/Implementation/Packets/Version2/Events/RawAbsDiffData.h>
#include <SkinCore/Cell/Events/Thresholds.h>

namespace Skin{
namespace Implementation{
namespace Packets {
namespace Version2{
namespace Events{

class ThreshDataPacket : public AbsDiffDataPacket
{

public:
    static const int PKT_SIZE = 20;

    static bool check(const Packet& p);
private:

public:
    ThreshDataPacket(const RawAbsDiffData& t,
                     int id=ID_ALL,
                     const QVector<Endpoint>& dest=QVector<Endpoint>());

    ThreshDataPacket(const AbsDiffData& t,
                     int id=ID_ALL,
                     const QVector<Endpoint>& dest=QVector<Endpoint>());

    ThreshDataPacket(const Skin::Cell::Events::Thresholds& t,
                     int id=ID_ALL,
                     const QVector<Endpoint>& dest=QVector<Endpoint>());

    void setId(int id);

private:
    void init();

};

}}}}}

#endif // SKINEVENTS_PACKETSV2_EVENTS_THRESHDATAPACKETV2_H
